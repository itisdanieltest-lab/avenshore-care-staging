"""Avenshore V3 public visitor chat test: genuine Worker + local SQLite, via Chromium bridge.
Test identities are fictional; user content must never be processed here.
"""
from pathlib import Path
import base64, json, os, tempfile, time, subprocess
import httpx
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'docs/qa/premium-audit-v3'; OUT.mkdir(parents=True,exist_ok=True)
PORT=8832;BASE=f'http://127.0.0.1:{PORT}'; SETUP='OnlyForLocalTest_AdministratorToken_239487';
root_temp=tempfile.mkdtemp(prefix='avenshore-v3-test-')
res=[]
def record(desc, condition):
 res.append({'test':desc,'pass':bool(condition)});print(('PASS' if condition else 'FAIL'),desc,flush=True)
 if not condition:raise AssertionError(desc)

def html_source():
 pub=ROOT/'public';raw=(pub/'index.html').read_text()
 mark='data:image/svg+xml;base64,'+base64.b64encode((pub/'assets/mark.svg').read_bytes()).decode()
 raw=raw.replace('/assets/mark.svg',mark)
 for f in ('styles.css','motion.css','refinement.css','chat-premium.css','alignment.css','design-system-v2.css','homepage-refresh.css'):
  raw=raw.replace(f'<link rel="stylesheet" href="/{f}">','<style>'+ (pub/f).read_text()+'</style>')
 raw=raw.replace('<script defer src="/app.js"></script>','')
 prefix='''<script>
 window.fetch=async function(url,opts={}){
  const r=await window.qaBridge({path:String(url),method:opts.method||'GET',headers:opts.headers||{},body:opts.body??null});
  return new Response(r.text,{status:r.status,headers:{'content-type':'application/json'}});
 }
 </script>'''
 return raw.replace('</body>',prefix+'<script>'+(pub/'app.js').read_text().replace('/assets/mark.svg',mark)+'</script></body>')

serverlog=open(OUT/'local-server.log','w');env={**os.environ,'AVENSHORE_TEST_DATA':root_temp,'PORT':str(PORT),'AVENSHORE_ADMIN_SETUP_TOKEN':SETUP};p=subprocess.Popen(['node','--no-warnings','--experimental-loader','./tests/local/loader.mjs','./tests/local/real-worker-server.mjs'],cwd=ROOT,env=env,stdout=serverlog,stderr=subprocess.STDOUT)
try:
 for i in range(50):
  try:
   if httpx.get(BASE+'/api/status',timeout=.6).status_code==200:break
  except Exception:pass
  time.sleep(.2)
 else:raise RuntimeError('Worker did not start')
 visitor=httpx.Client(timeout=10)
 admin=httpx.Client(timeout=10)
 setup=admin.post(BASE+'/api/setup/admin',headers={'origin':BASE,'x-admin-setup-token':SETUP},json={'name':'Fictional Administrator','email':'admin-review@example.test','password':'DemoOnlyTestingPassword-2026!!'})
 record('real admin account created',setup.status_code==201)
 def bridge(a):
  try:
   h=dict(a.get('headers') or {});m=a.get('method','GET')
   if m not in ('GET','HEAD'):h['origin']=BASE
   r=visitor.request(m,BASE+a['path'],content=a.get('body'),headers=h)
   return {'status':r.status_code,'text':r.text}
  except Exception as ex:return {'status':503,'text':json.dumps({'error':'Local test connection unavailable'})}
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for width,height in [(390,844),(1440,900)]:
   ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
   pg=ctx.new_page();pg.expose_function('qaBridge',bridge);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
   pg.set_content(html_source(),wait_until='domcontentloaded')
   pg.wait_for_selector('body.booted',timeout=20000);pg.wait_for_selector('#boot-screen',state='detached',timeout=10000)
   if width==390:
    record('public landing has immediate support launcher',pg.get_by_role('button',name='Chat with website support before signing up').count()==1)
    record('plain-language primary CTA',pg.get_by_role('button',name='Get started').count()>=1)
    record('public footer has no internal legal development note','Working brand pending' not in pg.locator('body').inner_text())
   pg.screenshot(path=str(OUT/f'public-home-{width}.png'),full_page=(width==390),animations='disabled')
   if width==390:
    pg.get_by_role('button',name='Chat with website support before signing up').click()
    pg.wait_for_function("S.actor?.role === 'visitor' && S.conversations.length>0",timeout=18000)
    record('guest session authenticated through local backend',pg.evaluate("S.actor.role==='visitor' && S.conversations[0]?.kind==='site-help'"))
    record('guest interface does not show call controls',pg.locator('button.thread-call,button.context-call').count()==0)
    record('guest chat has no patient navigation',pg.locator('nav.bottom-nav').count()==0)
    pg.locator('#messageText').wait_for(state='visible',timeout=12000)
    pg.locator('#messageText').fill('Hello, I need help creating an account.')
    print('DEBUG_SEND',pg.locator('.composer').count(),pg.locator('.composer-send').count(),pg.locator('.composer').inner_text() if pg.locator('.composer').count() else '',pg.evaluate('({state:S.view,open:S.mobileThreadOpen,actor:S.actor?.role,selected:S.selected})'),flush=True)
    pg.locator('.composer-send').click(timeout=4000)
    pg.wait_for_function("S.messages.some(m=>m.content==='Hello, I need help creating an account.')",timeout=14000)
    record('visitor message written to real database',len(visitor.get(BASE+f"/api/conversations/{pg.evaluate('S.selected')}/messages").json().get('messages',[]))==1)
    pg.screenshot(path=str(OUT/'visitor-chat-390.png'),full_page=False,animations='disabled')
    # Separate authenticated administrator browser, real DB-backed message round trip.
    admin_ctx=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
    admin_pg=admin_ctx.new_page()
    def admin_bridge(a):
     h=dict(a.get('headers') or {});m=a.get('method','GET')
     if m not in ('GET','HEAD'):h['origin']=BASE
     rr=admin.request(m,BASE+a['path'],content=a.get('body'),headers=h)
     return {'status':rr.status_code,'text':rr.text}
    admin_pg.expose_function('qaBridge',admin_bridge)
    admin_pg.set_content(html_source(),wait_until='domcontentloaded')
    admin_pg.wait_for_selector('body.booted',timeout=18000)
    admin_pg.locator('.public-header [data-view="login"]').first.click()
    admin_pg.locator('input[name="email"]').fill('admin-review@example.test')
    admin_pg.locator('input[name="password"]').fill('DemoOnlyTestingPassword-2026!!')
    admin_pg.locator('#authForm [type="submit"]').click()
    admin_pg.wait_for_function("S.actor?.role==='admin'",timeout=20000)
    record('real admin browser sign-in',admin_pg.evaluate("S.actor?.role==='admin'"))
    admin_pg.locator('.sidebar [data-view="messages"]').click()
    admin_pg.locator('.conversation-row').first.wait_for(timeout=15000)
    admin_pg.locator('.conversation-row').first.click()
    admin_pg.wait_for_function("S.messages.some(m=>m.content==='Hello, I need help creating an account.')",timeout=14000)
    record('admin reads visitor message from SQLite', 'Hello, I need help creating an account.' in admin_pg.locator('#messageStream').inner_text())
    record('site-support administrator cannot attach photos',admin_pg.locator('#imageUpload').count()==0)
    attach=admin.post(BASE+f'/api/conversations/{pg.evaluate("S.selected")}/attachments',headers={'origin':BASE,'content-type':'image/png'},content=b'not-an-image')
    record('site-support photo upload blocked by backend',attach.status_code==403)
    record('visitor identified correctly in admin thread', 'Website visitor' in admin_pg.locator('.message-sender').all_inner_texts())
    reply='Welcome to Avenshore Care. Select Create your account and follow the steps. If anything is unclear, I can guide you.'
    admin_pg.locator('#messageText').fill(reply)
    admin_pg.locator('.composer-send').click()
    admin_pg.wait_for_function("S.messages.some(m=>m.content.includes('Welcome to Avenshore Care.'))",timeout=14000)
    record('administrator sends real browser reply',any(m.get('content')==reply for m in admin.get(BASE+f'/api/conversations/{pg.evaluate("S.selected")}/messages').json().get('messages',[])))
    admin_pg.locator('.toast').evaluate_all('(els)=>els.forEach(e=>e.remove())')
    admin_pg.screenshot(path=str(OUT/'admin-guest-support-1440.png'),animations='disabled')
    pg.evaluate('refreshConversations()')
    pg.wait_for_function("S.messages.some(m=>m.content.includes('Welcome to Avenshore Care.'))",timeout=16000)
    record('visitor receives actual administrator reply',reply in pg.locator('#messageStream').inner_text())
    record('visitor cannot attach clinical photos',pg.locator('#imageUpload').count()==0)
    record('guest help composer label has no patient-only promise','Website help only' in pg.locator('.composer-helper').inner_text())
    pg.locator('.toast').evaluate_all('(els)=>els.forEach(e=>e.remove())')
    pg.screenshot(path=str(OUT/'visitor-chat-replied-390.png'),animations='disabled')
    admin_ctx.close()
    pg.get_by_role('button',name='Sign in').click()
    record('visitor can reach sign-in page',pg.locator('#authForm[data-mode="login"]').count()==1)
    pg.screenshot(path=str(OUT/'sign-in-390.png'),full_page=True,animations='disabled')
    pg.get_by_role('button',name='Return to website support chat').click()
    record('visitor can return to saved conversation',pg.evaluate("S.view==='messages' && S.actor?.role==='visitor'"))
    pg.get_by_role('button',name='End support chat').click()
    pg.wait_for_function('S.actor===null',timeout=10000)
    record('ending visitor chat clears credentials',visitor.get(BASE+'/api/me').json()['actor'] is None)
    record('no uncaught browser errors',not errors)
   else:
    pg.get_by_role('button',name='Chat with website support before signing up').click()
    pg.wait_for_function("S.actor?.role==='visitor' && S.conversations.length>0",timeout=15000)
    pg.screenshot(path=str(OUT/'visitor-chat-1440.png'),animations='disabled')
    record('desktop guest chat accessible',pg.locator('.chat-layout').count()==1)
    record('desktop no overflow',pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   ctx.close()
  browser.close()
 # Confirm the administrator's real database account sees guest support conversations.
 conv=admin.get(BASE+'/api/conversations').json()['conversations']
 record('visitor support conversation appears in staff inbox',any(c['kind']=='site-help' for c in conv))
 # Legal release blocker check remains in docs, not public interface.
 (OUT/'results.json').write_text(json.dumps({'test_environment':'Original Cloudflare Worker handlers via local SQLite test shim; original browser app; no production Cloudflare','tests':res},indent=2))
 print('COMPLETE',sum(r['pass'] for r in res),'/',len(res),flush=True)
finally:
 p.terminate();p.wait(timeout=5);visitor.close();admin.close();serverlog.close()
