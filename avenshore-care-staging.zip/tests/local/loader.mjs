// Makes the original Cloudflare Worker/Durable Object module importable in Node tests.
export async function resolve(specifier,context,nextResolve){
 if(specifier==='cloudflare:workers')return {url:new URL('./cloudflare-shim.mjs',import.meta.url).href,shortCircuit:true};
 return nextResolve(specifier,context);
}
