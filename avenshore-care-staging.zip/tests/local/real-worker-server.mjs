/**
 * LOCAL COMPATIBILITY HARNESS ONLY.
 * Runs the project's ORIGINAL Worker API handler + ORIGINAL RealtimeHub with a REAL
 * SQLite database on disk, an R2-compatible private file store, and real RFC6455
 * sockets. This is NOT the Cloudflare runtime and NOT a production deployment.
 */
import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import cryptoNode from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import worker, {RealtimeHub} from '../../worker/index.js';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const DATA_DIR=process.env.AVENSHORE_TEST_DATA||path.join(ROOT,'.local-qa-data');
fs.mkdirSync(DATA_DIR,{recursive:true});
const dbFile=path.join(DATA_DIR,'clinic.sqlite');
const database=new DatabaseSync(dbFile);
database.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');
database.exec(fs.readFileSync(path.join(ROOT,'migrations/0001_init.sql'),'utf8'));
const toPlain=r=>r==null?null:Object.fromEntries(Object.entries(r));
const DB = {
 prepare(sql) {
  const stmt=database.prepare(sql);
  const withArgs=(args=[])=>({
   bind:(...values)=>withArgs(values),
   first:async()=>toPlain(stmt.get(...args)),
   all:async()=>({results:stmt.all(...args).map(toPlain)}),
   run:async()=>{const out=stmt.run(...args);return {success:true,changes:Number(out.changes)};}
  });
  return withArgs();
 }
};
const TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.woff2':'font/woff2'};
const ASSETS={async fetch(request){
 let name=decodeURIComponent(new URL(request.url).pathname);
 if(name==='/'||name==='')name='/index.html';
 const full=path.resolve(ROOT,'public',name.replace(/^\//,''));
 if(!full.startsWith(path.resolve(ROOT,'public')+path.sep))return new Response('Not found',{status:404});
 try{const content=await fsp.readFile(full);return new Response(content,{status:200,headers:{'content-type':TYPES[path.extname(full)]||'application/octet-stream'}});}catch{return new Response('Not found',{status:404});}
}};
const UPLOADS={async put(key,buffer){const file=path.join(DATA_DIR,'r2',key);await fsp.mkdir(path.dirname(file),{recursive:true});await fsp.writeFile(file,new Uint8Array(buffer));},async get(key){try{const body=await fsp.readFile(path.join(DATA_DIR,'r2',key));return {body};}catch{return null;}}};
const durableStorage=new Map();
const durableSockets=new Set();
let locked=Promise.resolve();
const context={
 storage:{async get(key){return durableStorage.get(key)},async put(key,val){durableStorage.set(key,structuredClone(val));await fsp.writeFile(path.join(DATA_DIR,'call_state.json'),JSON.stringify(val));}},
 async blockConcurrencyWhile(fn){const prior=locked;let release;locked=new Promise(resolve=>release=resolve);await prior;try{return await fn();}finally{release();}},
 acceptWebSocket(ws){durableSockets.add(ws);},getWebSockets(){return [...durableSockets].filter(ws=>!ws.isClosed)}
};
try{durableStorage.set('callState',JSON.parse(fs.readFileSync(path.join(DATA_DIR,'call_state.json'),'utf8')));}catch{}

// Adapt Cloudflare WebSocketPair and upgrade Response solely for local E2E tests.
const StandardResponse=globalThis.Response;
class TestResponse extends StandardResponse{
 constructor(body,options={}){if(options.status===101){super(null,{status:200});this.upgraded=true;this.webSocket=options.webSocket;Object.defineProperty(this,'status',{value:101});}else super(body,options);}
}
globalThis.Response=TestResponse;
function frame(payload,op=1){const input=Buffer.isBuffer(payload)?payload:Buffer.from(payload);const n=input.length;let header;
 if(n<126){header=Buffer.from([0x80|op,n]);}else if(n<65536){header=Buffer.alloc(4);header[0]=0x80|op;header[1]=126;header.writeUInt16BE(n,2);}else{header=Buffer.alloc(10);header[0]=0x80|op;header[1]=127;header.writeBigUInt64BE(BigInt(n),2);}return Buffer.concat([header,input]);}
class LocalPairSocket{
 constructor(){this.attachment={};this.isClosed=false;this.peer=null;this.tcp=null;this.pending=[];this.buffer=Buffer.alloc(0);}
 serializeAttachment(data){this.attachment=data;}
 deserializeAttachment(){return this.attachment;}
 send(message){if(this.isClosed)return;if(this.tcp)this.tcp.write(frame(message));else this.pending.push(message);}
 close(){this.isClosed=true;if(this.tcp)try{this.tcp.end(frame('',8))}catch{}durableSockets.delete(this);}
 bindTCP(tcp){this.tcp=tcp;for(const m of this.pending)this.send(m);this.pending=[];
 tcp.on('data',b=>{this.buffer=Buffer.concat([this.buffer,b]);this.parse();});
 tcp.on('error',()=>this.close());tcp.on('end',()=>{this.isClosed=true;durableSockets.delete(this);});
 }
 parse(){while(this.buffer.length>=2){const b=this.buffer,opcode=b[0]&15;const mask=!!(b[1]&128);let n=b[1]&127,pos=2;
 if(n===126){if(b.length<4)return;n=b.readUInt16BE(2);pos=4;}else if(n===127){if(b.length<10)return;n=Number(b.readBigUInt64BE(2));pos=10;}
 if(n>65536){this.close();return;}if(mask)pos+=4;if(b.length<pos+n)return;
 let payload=Buffer.from(b.subarray(pos,pos+n));if(mask){const key=b.subarray(pos-4,pos);for(let i=0;i<n;i++)payload[i]^=key[i%4];}
 this.buffer=b.subarray(pos+n);if(opcode===8){this.close();return;}if(opcode===9){this.tcp?.write(frame(payload,10));continue;}
 if(opcode===1){void hub.webSocketMessage(this, payload.toString('utf8')).catch(e=>console.error('WS handler',e.message));}
 }}
}
class WebSocketPair {constructor(){const client=new LocalPairSocket(),server=new LocalPairSocket();client.peer=server;server.peer=client;this[0]=client;this[1]=server;}}
globalThis.WebSocketPair=WebSocketPair;
const hub=new RealtimeHub(context,{});
const REALTIME={getByName(){return {fetch:(r,init)=>hub.fetch(typeof r==='string'?new Request(r,init):r)}}};
const env={LOCAL_QA:process.env.AVENSHORE_LOCAL_QA!=='false',DB,UPLOADS,ASSETS,REALTIME,ADMIN_SETUP_TOKEN:process.env.AVENSHORE_ADMIN_SETUP_TOKEN||'',TURNSTILE_SECRET:undefined,TURNSTILE_SITE_KEY:undefined};
const PORT=Number(process.env.PORT||8789);
function headers(req){const result={};for(const [k,v] of Object.entries(req.headers)){if(Array.isArray(v))result[k]=v.join(',');else if(v!=null)result[k]=v;}return result;}
function url(req){return `http://127.0.0.1:${PORT}${req.url}`;}
async function requestFrom(req){const data=[];for await(const chunk of req)data.push(chunk);const body=Buffer.concat(data);return new Request(url(req),{method:req.method,headers:headers(req),body:['GET','HEAD'].includes(req.method)?undefined:body});}
const server=http.createServer(async(req,res)=>{try{
 const response=await worker.fetch(await requestFrom(req),env,{});
 res.statusCode=response.status;response.headers.forEach((v,k)=>res.setHeader(k,v));
 res.end(Buffer.from(await response.arrayBuffer()));
 }catch(e){console.error('HTTP:',e);res.statusCode=500;res.end('Local test harness error');}});
server.on('upgrade',async(req,socket,head)=>{try{
 if(!req.url.startsWith('/api/events')){socket.destroy();return;}
 const response=await worker.fetch(new Request(url(req),{method:'GET',headers:headers(req)}),env,{});
 if(!response.upgraded||!response.webSocket){socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');socket.destroy();return;}
 const key=req.headers['sec-websocket-key'];if(!key){socket.destroy();return;}
 const accept=cryptoNode.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
 response.webSocket.peer.bindTCP(socket);if(head.length)response.webSocket.peer.tcp.emit('data',head);
 }catch(e){console.error('WS upgrade:',e);socket.destroy();}});
server.listen(PORT,'127.0.0.1',()=>console.log(JSON.stringify({ready:true,base:`http://127.0.0.1:${PORT}`,sqlite:dbFile,originalWorker:true,originalDurableObject:true})));
