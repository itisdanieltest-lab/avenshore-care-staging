// Local test adapter for Node. NOT part of the Cloudflare deployment.
export class DurableObject {constructor(ctx,env){this.ctx=ctx;this.env=env;}}
