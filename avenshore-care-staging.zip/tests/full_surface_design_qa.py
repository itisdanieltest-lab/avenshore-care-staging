"""Chromium visual/structural checks of real Avenshore application files.
API is stubbed for repeatable visual fixtures; NOT a substitute for live backend QA.
"""
from pathlib import Path
import base64,json,time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
PUBLIC=ROOT/'public'
OUT=ROOT/'docs'/'qa'/'full-surface-v2'
OUT.mkdir(parents=True,exist_ok=True)
html=(PUBLIC/'index.html').read_text()
mark='data:image/svg+xml;base64,'+base64.b64encode((PUBLIC/'assets'/'mark.svg').read_bytes()).decode()
html=html.replace('/assets/mark.svg',mark)
for f in ('styles.css','motion.css','refinement.css','chat-premium.css','alignment.css','design-system-v2.css'):
  html=html.replace(f'<link rel="stylesheet" href="/{f}">','<style>\n'+(PUBLIC/f).read_text()+'\n</style>')
html=html.replace('<script defer src="/app.js"></script>','')
js=(PUBLIC/'app.js').read_text().replace('/assets/mark.svg',mark)
# Stable fictional patient data, with actual application JS / CSS / HTML.
bootstrap='''<script>
const __conv=[{id:'c1',kind:'care',display_name:'Mara Ellis',last_message:'Thank you, I understand the next steps.'},{id:'c2',kind:'care',display_name:'Noel Carter',last_message:'Can I request a call tomorrow?'},{id:'c3',kind:'site-help',display_name:'Site visitor',last_message:'How do I create an account?'}];
const __messages=[{id:'m1',sender_type:'patient',content:'Good morning. I need help getting in touch with the care team.',created_at:Date.now()-3600000},{id:'m2',sender_type:'admin',content:'Welcome to Avenshore Care. Tell us what kind of support you need today.',created_at:Date.now()-2400000},{id:'m3',sender_type:'patient',content:'I would like to request a voice call, please.',created_at:Date.now()-1200000}];
window.fetch=async function(url){let p=String(url).split('/api/')[1]?.split('?')[0];let data={'me':{actor:{id:'p1',role:'patient',name:'Mara Ellis',email:'mara@example.test'},turnstileSiteKey:null},'conversations':{conversations:__conv},'calls':{active:null,queue:[],position:null},'conversations/c1/messages':{messages:__messages}};return new Response(JSON.stringify(data[p]||{}),{status:200,headers:{'content-type':'application/json'}})}
</script>'''
html=html.replace('</body>',bootstrap+'<script>'+js+'</script></body>')
all_results=[]
actors={'patient':{'id':'p1','role':'patient','name':'Mara Ellis','email':'mara@example.test'},'admin':{'id':'a1','role':'admin','name':'Tara Staff','email':'tara@example.test'}}
roles={'public':['welcome','login','register','help'], 'patient':['home','care','health','messages','calls','account'], 'admin':['admin','messages','calls','account']}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [320,390,768,1024,1440]:
  height=780 if width<=390 else 900
  ctx=browser.new_context(viewport={'width':width,'height':height}, device_scale_factor=1)
  pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(html,wait_until='domcontentloaded',timeout=20000)
  pg.wait_for_selector('body.booted',timeout=12000)
  pg.wait_for_selector('#boot-screen',state='detached',timeout=12000)
  for role,views in roles.items():
   for view in views:
    # Render with the original app's rendering logic using fictional state.
    pg.evaluate('''({actor,view})=>{
      S.actor=actor;S.view=view;S.selected='c1';S.conversations=actor?[...__conv]:[];S.messages=[...__messages];
      S.call={active:null,queue:[],position:null};S.mobileThreadOpen=view==='messages'&&innerWidth<=760;
      render();window.scrollTo(0,0);
    }''', {'actor':actors.get(role),'view':view})
    pg.wait_for_timeout(55)
    geom=pg.evaluate('''()=>({scroll:document.documentElement.scrollWidth, width:innerWidth,
     heading:document.querySelector('h1')?.textContent?.trim(),
     safeBottom:Math.round(document.querySelector('.bottom-nav')?.getBoundingClientRect().top||9999),
     composerBottom:Math.round(document.querySelector('.composer')?.getBoundingClientRect().bottom||0),
     composerTop:Math.round(document.querySelector('.composer')?.getBoundingClientRect().top||0),
     navDisplayed:getComputedStyle(document.querySelector('.bottom-nav')||document.body).display,
     panels:document.querySelectorAll('.panel,.home-content-grid>section,.care-hub-option,.calling-card,.chat-layout').length,
     broken:[...document.querySelectorAll('img')].filter(i=>!i.complete||i.naturalWidth===0).length
    })''')
    failures=[]
    if geom['scroll']>width+1:failures.append('overflow')
    if geom['broken']>0:failures.append('broken images')
    # On mobile the chat composer should remain above the bottom navigation.
    if width<=390 and view=='messages' and role!='public':
      if geom['composerBottom']>geom['safeBottom']+2:failures.append('composer covered by navigation')
    if errors:failures.append('JS errors')
    key=f'{role}-{view}-{width}'
    # Screenshot sample variants for review, plus all screens at 390 and 1440.
    if width in (390,1440) or (width==320 and view in ('messages','home','calls')):
      pg.screenshot(path=str(OUT/(key+'.png')),full_page=(width==390 and view in ('home','health','account','care','calls','welcome','register','help')),timeout=12000,animations='disabled')
    all_results.append({'screen':key,**geom,'passed':not failures,'issues':failures})
    if failures: print('FAIL',key,failures,geom,flush=True)
  print('width done',width,'cases',len(all_results),flush=True)
  ctx.close()
 browser.close()
(OUT/'results.json').write_text(json.dumps(all_results,indent=2))
passed=sum(r['passed'] for r in all_results)
print('TOTAL',len(all_results),'PASSED',passed,'FAILED',len(all_results)-passed,flush=True)
if passed<len(all_results):raise SystemExit(1)
