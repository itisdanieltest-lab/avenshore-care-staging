import test from 'node:test';
import assert from 'node:assert/strict';
import { register } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
register('./local/loader.mjs', import.meta.url);
const { default: worker } = await import('../worker/index.js');
const base = 'https://clinic.example';
function fixture() {
 const db = new DatabaseSync(':memory:');
 db.exec(readFileSync(new URL('../migrations/0001_init.sql', import.meta.url), 'utf8'));
 const env = { REALTIME: {}, DB: { prepare(sql) { const stmt=db.prepare(sql); const bound=(args=[])=>({bind:(...v)=>bound(v),first:async()=>stmt.get(...args)||null,all:async()=>({results:stmt.all(...args)}),run:async()=>stmt.run(...args)});return bound(); } } };
 const call=(path,options={})=>worker.fetch(new Request(base+'/api'+path,options),env,{});
 return {db,env,call};
}
const hash=async value=>Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))).toString('hex');
for (const cookieName of ['__Host-av_session','av_session']) {
 test(`logout revokes ${cookieName} on the server and expires the browser cookie`,async()=>{
  const {db,call}=fixture();
  db.prepare("INSERT INTO users VALUES(?,?,?,?,?,?,?,NULL)").run('patient','fictional@example.invalid','Fictional Patient','salt','hash','patient',Date.now());
  const token='fictional-session-token';
  db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(await hash(token),'patient',Date.now()+60000,Date.now());
  const headers={origin:base,cookie:cookieName+'='+token};
  assert.equal((await (await call('/me',{headers})).json()).actor.id,'patient');
  const response=await call('/auth/logout',{method:'POST',headers});
  assert.equal(response.status,200);assert.match(response.headers.get('set-cookie'),/Max-Age=0/);
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM sessions').get().count,0);
  assert.equal((await (await call('/me',{headers})).json()).actor,null);
  db.close();
 });
}
test('logout is safe to repeat without a session',async()=>{
 const {db,call}=fixture();
 for(let i=0;i<2;i++)assert.equal((await call('/auth/logout',{method:'POST',headers:{origin:base}})).status,200);
 assert.equal((await call('/auth/logout',{method:'POST',headers:{origin:'https://other.example'}})).status,403);db.close();
});
test('administrator setup requires its private token and becomes unavailable after first creation',async()=>{
 const {db,env,call}=fixture();
 assert.equal((await (await call('/me')).json()).adminSetupAvailable,false);
 env.ADMIN_SETUP_TOKEN='fictional-test-bootstrap-token-at-least-32-chars';
 assert.equal((await (await call('/me')).json()).adminSetupAvailable,true);
 const data={name:'Fictional Administrator',email:'admin@example.invalid',password:'Fictional-only-password-123!'};
 const options={method:'POST',headers:{origin:base,'content-type':'application/json','x-admin-setup-token':env.ADMIN_SETUP_TOKEN},body:JSON.stringify(data)};
 assert.equal((await call('/setup/admin',{...options,headers:{origin:base}})).status,403);
 assert.equal((await call('/setup/admin',options)).status,201);
 assert.equal((await (await call('/me')).json()).adminSetupAvailable,false);
 assert.equal((await call('/setup/admin',options)).status,409);
 assert.equal(db.prepare("SELECT COUNT(*) AS count FROM users WHERE role='admin'").get().count,1);db.close();
});
