import test from 'node:test';
import assert from 'node:assert/strict';
import {register} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {cleanProfileJpeg,MAX_PROFILE_BYTES} from '../worker/profile-photos.js';
register('./local/loader.mjs',import.meta.url);
const {default:worker}=await import('../worker/index.js');
const origin='https://clinic.example';
const jpeg=readFileSync(new URL('fixtures/profile-photo.jpg',import.meta.url));
const digest=async s=>Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))).toString('hex');
async function fixture(){
 const db=new DatabaseSync(':memory:');
 for(const migration of ['0001_init.sql','0002_profile_photos.sql'])db.exec(readFileSync(new URL('../migrations/'+migration,import.meta.url),'utf8'));
 const env={REALTIME:{},DB:{prepare(sql){const stmt=db.prepare(sql);const bound=(args=[])=>({bind:(...values)=>bound(values.map(v=>v instanceof ArrayBuffer?new Uint8Array(v):v)),first:async()=>stmt.get(...args)||null,all:async()=>({results:stmt.all(...args)}),run:async()=>stmt.run(...args)});return bound();}}};
 const ids=['p1','p2','staff'];
 for(const id of ids){db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?,?,NULL)').run(id,id+'@example.invalid','Fictional '+id,'salt','hash',id==='staff'?'admin':'patient',Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(await digest(id+'-session'),id,Date.now()+600000,Date.now());}
 db.prepare('INSERT INTO visitors VALUES(?,?,?,?)').run('guest',await digest('guest-session'),Date.now(),Date.now()+60000);
 const call=(id,path,method='GET',body,headers={})=>worker.fetch(new Request(origin+'/api'+path,{method,headers:{origin,cookie:id==='guest'?'__Host-av_guest=guest-session':id?'__Host-av_session='+id+'-session':'','content-type':'image/jpeg',...headers},body}),env,{});
 return {db,call};
}
test('JPEG validator rejects executable, oversized, malformed and over-dimension photos; strips EXIF',()=>{
 assert.throws(()=>cleanProfileJpeg(new TextEncoder().encode('<svg onload="alert(1)"/>')));
 assert.throws(()=>cleanProfileJpeg(new Uint8Array(MAX_PROFILE_BYTES+1)),/too large/);
 assert.throws(()=>cleanProfileJpeg(readFileSync(new URL('fixtures/profile-photo-too-wide.jpg',import.meta.url))),/256/);
 const exif=Buffer.from('Exif\0\0GPS-private');const segment=Buffer.concat([Buffer.from([255,225,0,exif.length+2]),exif]);
 const dirty=Buffer.concat([jpeg.subarray(0,2),segment,jpeg.subarray(2)]);const clean=cleanProfileJpeg(dirty);
 assert.ok(!Buffer.from(clean).includes(Buffer.from('GPS-private')));assert.deepEqual(clean,cleanProfileJpeg(jpeg));
});
test('patient and admin photos persist, replace and remove without optional R2 storage',async()=>{
 const {db,call}=await fixture();
 for(const id of ['p1','staff']){
  const save=await call(id,'/profile/photo','PUT',jpeg);assert.equal(save.status,200);const first=await save.json();assert.match(first.photo_url,/^\/api\/profile-photos\//);
  const me=await (await call(id,'/me')).json();assert.equal(me.actor.photo_url,first.photo_url);
  const get=await call(id,first.photo_url.replace('/api',''));assert.equal(get.status,200);assert.equal(get.headers.get('cache-control'),'private, no-store');assert.equal(get.headers.get('content-type'),'image/jpeg');assert.deepEqual(new Uint8Array(await get.arrayBuffer()),cleanProfileJpeg(jpeg));
  const second=await (await call(id,'/profile/photo','PUT',jpeg)).json();assert.notEqual(second.photo_url,first.photo_url);
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM profile_photos WHERE user_id=?').get(id).count,1);
  assert.equal((await call(id,'/profile/photo','DELETE')).status,200);assert.equal((await (await call(id,'/me')).json()).actor.photo_url,null);
  assert.equal((await call(id,first.photo_url.replace('/api',''))).status,404);
 }
 db.close();
});
test('profile photos enforce patient isolation, staff visibility and signed-in access',async()=>{
 const {db,call}=await fixture();
 await call('p1','/profile/photo','PUT',jpeg);await call('staff','/profile/photo','PUT',jpeg);
 assert.equal((await call('p2','/profile-photos/p1')).status,404);
 assert.equal((await call('staff','/profile-photos/p1')).status,200);
 assert.equal((await call('p1','/profile-photos/staff')).status,200);
 assert.equal((await call(null,'/profile-photos/p1')).status,401);
 assert.equal((await call('guest','/profile-photos/p1')).status,404);
 assert.equal((await call('guest','/profile/photo','PUT',jpeg)).status,403);
 assert.equal((await call('p2','/profile/photo','PUT',jpeg,{origin:'https://other.example'})).status,403);
 assert.equal((await call('p2','/profile/photo','DELETE',undefined,{origin:'https://other.example'})).status,403);
 db.close();
});
test('bad uploads do not overwrite an existing photo',async()=>{
 const {db,call}=await fixture();const original=await (await call('p1','/profile/photo','PUT',jpeg)).json();
 assert.equal((await call('p1','/profile/photo','PUT','<svg/>',{'content-type':'image/svg+xml'})).status,415);
 assert.equal((await call('p1','/profile/photo','PUT','not a JPEG')).status,400);
 assert.equal((await call('p1','/profile/photo','PUT',new Uint8Array(MAX_PROFILE_BYTES+1))).status,413);
 assert.equal((await (await call('p1','/me')).json()).actor.photo_url,original.photo_url);db.close();
});
test('care inbox returns only the correct participant photo and updates after removal',async()=>{
 const {db,call}=await fixture();
 for(const id of ['p1','p2'])db.prepare('INSERT INTO conversations VALUES(?,?,NULL,?,?,?)').run('care-'+id,id,'care',Date.now(),Date.now());
 const patient=await (await call('p1','/profile/photo','PUT',jpeg)).json();const staff=await (await call('staff','/profile/photo','PUT',jpeg)).json();
 const adminInbox=await (await call('staff','/conversations')).json();assert.equal(adminInbox.conversations.find(c=>c.patient_id==='p1').photo_url,patient.photo_url);
 const patientInbox=await (await call('p1','/conversations')).json();assert.equal(patientInbox.conversations.length,1);assert.equal(patientInbox.conversations[0].photo_url,staff.photo_url);
 await call('p1','/profile/photo','DELETE');const updated=await (await call('staff','/conversations')).json();assert.equal(updated.conversations.find(c=>c.patient_id==='p1').photo_url,null);db.close();
});
