import test from 'node:test';
import assert from 'node:assert/strict';
import {register} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {cleanProfileJpeg,MAX_PROFILE_BYTES} from '../worker/profile-photos.js';
register('./local/loader.mjs',import.meta.url);
const {default:worker}=await import('../worker/index.js');
const origin='https://clinic.example';
const jpeg=readFileSync(new URL('fixtures/profile-photo.jpg',import.meta.url));
const digest=async s=>Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))).toString('hex');
async function fixture(){
 const db=new DatabaseSync(':memory:');
 for(const migration of ['0001_init.sql','0002_profile_photos.sql','0003_messaging.sql'])db.exec(readFileSync(new URL('../migrations/'+migration,import.meta.url),'utf8'));
 const env={REALTIME:{},DB:{prepare(sql){const stmt=db.prepare(sql);const bound=(args=[])=>({bind:(...values)=>bound(values.map(v=>v instanceof ArrayBuffer?new Uint8Array(v):v)),first:async()=>stmt.get(...args)||null,all:async()=>({results:stmt.all(...args)}),run:async()=>stmt.run(...args)});return bound();}}};
 const ids=['p1','p2','staff'];
 for(const id of ids){db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?,?,NULL)').run(id,id+'@example.invalid','Fictional '+id,'salt','hash',id==='staff'?'admin':'patient',Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(await digest(id+'-session'),id,Date.now()+600000,Date.now());}
 db.prepare('INSERT INTO visitors VALUES(?,?,?,?)').run('guest',await digest('guest-session'),Date.now(),Date.now()+60000);
 const call=(id,path,method='GET',body,headers={})=>worker.fetch(new Request(origin+'/api'+path,{method,headers:{origin,cookie:id==='guest'?'__Host-av_guest=guest-session':id?'__Host-av_session='+id+'-session':'','content-type':'image/jpeg',...headers},body}),env,{});
 return {db,call,env};
}

async function setup(){const f=await fixture();for(const id of ['p1','p2'])f.db.prepare('INSERT INTO conversations VALUES(?,?,NULL,?,?,?)').run('care-'+id,id,'care',Date.now(),Date.now());f.send=(id,path,data,method='POST')=>f.call(id,path,method,JSON.stringify(data),{'content-type':'application/json'});return f;}
test('text retries are idempotent, replies stay within conversation, and access stays private',async()=>{
 const {db,call,send}=await setup();const path='/conversations/care-p1/messages';const payload={content:'Fictional care message',client_message_id:crypto.randomUUID()};
 const one=await (await send('p1',path,payload)).json();const two=await(await send('p1',path,payload)).json();assert.equal(one.id,two.id);assert.equal(db.prepare('SELECT COUNT(*) AS n FROM messages').get().n,1);
 assert.equal((await call('p2',path)).status,404);assert.equal((await send('p2',path,payload)).status,404);
 const reply=await send('staff',path,{content:'Reply',reply_to:one.id});assert.equal(reply.status,201);
 assert.equal((await send('p2','/conversations/care-p2/messages',{content:'No',reply_to:one.id})).status,404);
 const rows=await(await call('p1',path)).json();assert.equal(rows.messages[1].reply_content,payload.content);db.close();
});
test('only the author can edit; stale edits fail and earlier wording is retained',async()=>{
 const {db,send,call}=await setup();const original=await(await send('p1','/conversations/care-p1/messages',{content:'Original'})).json();
 assert.equal((await send('staff','/messages/'+original.id,{content:'Forbidden',previous_content:'Original'},'PATCH')).status,404);
 assert.equal((await send('p1','/messages/'+original.id,{content:'Corrected',previous_content:'Original'},'PATCH')).status,200);
 assert.equal((await send('p1','/messages/'+original.id,{content:'Stale',previous_content:'Original'},'PATCH')).status,409);
 assert.equal(db.prepare('SELECT previous_content FROM message_edits').get().previous_content,'Original');const m=(await(await call('p1','/conversations/care-p1/messages')).json()).messages[0];assert.equal(m.content,'Corrected');assert.ok(m.edited_at);db.close();
});
test('read receipts require access and history cursor is deterministic for tied timestamps',async()=>{
 const {db,send,call}=await setup();for(let i=0;i<105;i++)db.prepare('INSERT INTO messages(id,conversation_id,sender_type,sender_id,content,created_at) VALUES(?,?,?,?,?,?)').run('msg-'+String(i).padStart(3,'0'),'care-p1','patient','p1','Message '+i,1000);
 const page=await(await call('staff','/conversations/care-p1/messages')).json();assert.equal(page.messages.length,100);assert.equal(page.hasMore,true);
 const older=await(await call('staff','/conversations/care-p1/messages?before='+page.messages[0].id)).json();assert.equal(older.messages.length,5);assert.equal(older.hasMore,false);assert.equal(new Set([...page.messages,...older.messages].map(m=>m.id)).size,105);
 assert.equal((await send('p2','/conversations/care-p1/read',{messageId:'msg-104'})).status,404);
 assert.equal((await send('staff','/conversations/care-p1/read',{messageId:'msg-104'})).status,200);
 const read=await(await call('p1','/conversations/care-p1/messages')).json();assert.equal(read.messages[0].counterpart_read_at,1000);db.close();
});
test('voice attachment endpoint reports unconfigured storage without corrupting text messaging',async()=>{const {db,call,send}=await setup();assert.equal((await call('p1','/conversations/care-p1/attachments','POST',new Uint8Array([26,69,223,163]),{'content-type':'audio/webm'})).status,503);assert.equal((await send('p1','/conversations/care-p1/messages',{content:'Text still works'})).status,201);db.close();});
test('private audio uploads validate format and retry without duplicate messages when storage is connected',async()=>{
 const f=await setup();const objects=new Map();f.env.UPLOADS={put:async(key,data)=>objects.set(key,data),get:async key=>objects.has(key)?{body:objects.get(key)}:null};
 const id=crypto.randomUUID(),path='/conversations/care-p1/attachments',data=new Uint8Array([26,69,223,163,0,0,0,0]),headers={'content-type':'audio/webm','x-upload-id':id};
 assert.equal((await f.call('p1',path,'POST','bad',headers)).status,415);
 assert.equal((await f.call('p1',path,'POST',data,headers)).status,201);assert.equal((await f.call('p1',path,'POST',data,headers)).status,200);
 assert.equal(f.db.prepare('SELECT COUNT(*) AS n FROM messages').get().n,1);assert.equal((await f.call('p2','/attachments/'+id)).status,404);
 const audio=await f.call('staff','/attachments/'+id);assert.equal(audio.status,200);assert.equal(audio.headers.get('content-type'),'audio/webm');assert.equal(audio.headers.get('cache-control'),'private, no-store');f.db.close();
});
