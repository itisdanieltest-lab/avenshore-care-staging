"""Browser smoke checks for Avenshore Care.
Run with: python tests/ui_smoke.py --base http://127.0.0.1:8011
Uses fake data only. Browser must be installed; not part of npm test.
"""
import argparse
from pathlib import Path
from playwright.sync_api import sync_playwright

p=argparse.ArgumentParser();p.add_argument('--base',default='http://127.0.0.1:8011');p.add_argument('--browser',default='/usr/bin/chromium');args=p.parse_args()
out=Path(__file__).parents[1]/'docs/qa';out.mkdir(parents=True,exist_ok=True)

with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=args.browser,headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--proxy-bypass-list=*'])
 def page_for(role='none',size='mobile',reduced=False):
  ctx=browser.new_context(viewport={'width':390,'height':844} if size=='mobile' else {'width':1440,'height':900},is_mobile=(size=='mobile'),device_scale_factor=1,reduced_motion='reduce' if reduced else 'no-preference')
  page=ctx.new_page()
  issues=[]
  page.on('pageerror',lambda err:issues.append(str(err)))
  def mock(route):
   path=route.request.url.split('/api/',1)[-1].split('?',1)[0]
   actor={'id':'p1','role':'patient','name':'Sarah Example','email':'sarah@example.invalid'} if role=='patient' else {'id':'admin1','role':'admin','name':'Taylor Example','email':'staff@example.invalid'} if role=='admin' else None
   response={'me':{'actor':actor,'turnstileSiteKey':None},'conversations':{'conversations':[]},'calls':{'active':None,'queue':[],'position':None,'busy':False},'status':{'status':'ok'}}.get(path,{})
   route.fulfill(status=200,content_type='application/json',body=__import__('json').dumps(response))
  page.route('**/api/**',mock)
  page.goto(args.base,wait_until='domcontentloaded')
  page.wait_for_selector('body.booted',timeout=10000)
  page.wait_for_timeout(600)
  return page,ctx,issues

 page,ctx,issues=page_for('none','mobile')
 assert 'Avenshore Care' in page.title()
 assert page.locator('h1').count()==1
 assert page.locator('#boot-screen').count()==0
 page.screenshot(path=str(out/'public-mobile.png'),full_page=True)
 print('PASS: public mobile, loader finishes and public hero displays')
 assert not issues, issues
 ctx.close()

 page,ctx,issues=page_for('patient','mobile')
 assert 'Sarah' in page.locator('h1').first.inner_text()
 page.screenshot(path=str(out/'patient-mobile.png'),full_page=True)
 page.locator('.bottom-nav [data-view="messages"]').click()
 assert 'Messages' in page.locator('main').inner_text()
 page.screenshot(path=str(out/'messages-mobile.png'),full_page=True)
 page.locator('.bottom-nav [data-view="calls"]').click()
 assert 'Call the Care Team' in page.locator('main').inner_text()
 assert page.locator('button[data-action="request-call"]').count()==1
 page.screenshot(path=str(out/'calls-mobile.png'),full_page=True)
 print('PASS: patient mobile responsive navigation, messages, call UI')
 assert not issues, issues
 ctx.close()

 page,ctx,issues=page_for('admin','desktop')
 assert 'workspace' in page.locator('main').inner_text().lower()
 page.screenshot(path=str(out/'admin-desktop.png'),full_page=True)
 assert not issues, issues
 print('PASS: admin desktop view')
 ctx.close()

 page,ctx,issues=page_for('none','mobile',True)
 value=page.evaluate("getComputedStyle(document.querySelector('.boot-indicator')||document.body).animationName")
 assert value=='none' or value==''
 page.screenshot(path=str(out/'reduced-motion.png'),full_page=True)
 print('PASS: reduced-motion browser preference renders without page errors')
 assert not issues, issues
 ctx.close();browser.close()
