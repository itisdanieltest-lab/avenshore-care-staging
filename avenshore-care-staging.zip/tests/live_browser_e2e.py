"""Local real-backend integration QA. All patients and content are fictional. No production use."""
import json, os, re, secrets, sqlite3, time, traceback
from pathlib import Path
import httpx
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'docs/qa/live';OUT.mkdir(parents=True,exist_ok=True)
BASE=os.environ.get('AVENSHORE_LOCAL_URL','http://127.0.0.1:8789')
ADMIN_EMAIL=os.environ.get('AVENSHORE_QA_ADMIN_EMAIL','admin.qa@example.test')
ADMIN_PASSWORD=os.environ.get('AVENSHORE_QA_ADMIN_PASSWORD','TestAdminPassword!12345678')
PATIENT_PASSWORD='OnlyFictional-Patient-Pass!1234'
headers={'Origin':BASE}
results=[]

def record(name,passed,detail=''):
    results.append({'test':name,'status':'PASS' if passed else 'FAIL','detail':str(detail)[:500]})
    print(('PASS' if passed else 'FAIL'),name,detail,flush=True)
    if not passed:raise AssertionError(f'{name}: {detail}')

def request(client,method,path,**kw):
    kw.setdefault('timeout',22)
    if method in ('POST','PUT','PATCH','DELETE'):kw.setdefault('headers',headers)
    return client.request(method,BASE+path,**kw)

def login_client(email,password):
    client=httpx.Client()
    r=request(client,'POST','/api/auth/login',json={'email':email,'password':password})
    record('API login '+email,r.status_code==200,r.status_code)
    return client

suffix=secrets.token_hex(4)
pa=httpx.Client();pb=httpx.Client()
admin=login_client(ADMIN_EMAIL,ADMIN_PASSWORD)
people=[('Mara Ellis',f'mara-{suffix}@example.test',pa),('Noel Carter',f'noel-{suffix}@example.test',pb)]
for name,email,client in people:
    r=request(client,'POST','/api/auth/register',json={'name':name,'email':email,'password':PATIENT_PASSWORD})
    record('Real patient registration '+name,r.status_code==201,r.status_code)
ca=request(pa,'GET','/api/conversations').json()['conversations'][0]['id']
cb=request(pb,'GET','/api/conversations').json()['conversations'][0]['id']
record('Distinct database conversations',ca!=cb,ca[:8]+' / '+cb[:8])
record('Private conversation read denied',request(pb,'GET',f'/api/conversations/{ca}/messages').status_code==404)
record('Private conversation write denied',request(pb,'POST',f'/api/conversations/{ca}/messages',json={'content':'Not my conversation'}).status_code==404)
record('Missing session denied',request(httpx.Client(),'GET','/api/conversations').status_code==401)
record('Cross-origin write denied',request(pa,'POST',f'/api/conversations/{ca}/messages',headers={'origin':'https://untrusted.invalid'},json={'content':'Unsafe'}).status_code==403)
record('Wrong password rejected',request(httpx.Client(),'POST','/api/auth/login',json={'email':people[0][1],'password':'incorrect'}).status_code==401)

seed='Hello, I would like some help understanding my care plan.'
r=request(pa,'POST',f'/api/conversations/{ca}/messages',json={'content':seed})
record('Patient message stored by Worker',r.status_code==201)
rows=request(admin,'GET',f'/api/conversations/{ca}/messages').json()['messages']
record('Administrator receives patient message',any(m.get('content')==seed for m in rows))

# Exercise the project's attachment authorization and R2-compatible local object storage.
img=OUT/'fictional-attachment.png'
canvas=Image.new('RGB',(600,330),'#E8F0E9');draw=ImageDraw.Draw(canvas)
draw.rounded_rectangle((55,45,545,285),24,fill='#FFFFFF',outline='#AFC9BD',width=3)
draw.text((86,85),'FICTIONAL TEST IMAGE',fill='#0D6058')
draw.text((86,150),'No medical data',fill='#355951')
canvas.save(img)
r=request(pa,'POST',f'/api/conversations/{ca}/attachments',headers={'origin':BASE,'content-type':'image/png'},content=img.read_bytes())
record('Private photo stored and indexed',r.status_code==201,r.status_code)
aid=r.json()['id'] if r.status_code==201 else ''
record('Owner can retrieve image',request(pa,'GET',f'/api/attachments/{aid}').status_code==200)
record('Other patient cannot retrieve image',request(pb,'GET',f'/api/attachments/{aid}').status_code==404)
record('Administrator can retrieve image',request(admin,'GET',f'/api/attachments/{aid}').status_code==200)

# Empty pre-existing queue from prior manual experiments.
for i in range(5):
    state=request(admin,'GET','/api/calls').json()
    if not state.get('active'):break
    request(admin,'POST','/api/calls/end',json={})

# Browser tests authenticate through the actual form and contact the real local server.
errors=[];screens=[];rtc_result={'status':'NOT RUN'}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=[
        '--no-sandbox','--disable-dev-shm-usage','--use-fake-device-for-media-stream',
        '--use-fake-ui-for-media-stream','--autoplay-policy=no-user-gesture-required'])
    ca_ctx=browser.new_context(viewport={'width':1440,'height':900},permissions=['microphone'])
    pa_ctx=browser.new_context(viewport={'width':390,'height':844},permissions=['microphone'],is_mobile=True,has_touch=True)
    pb_ctx=browser.new_context(viewport={'width':390,'height':844},permissions=['microphone'],is_mobile=True,has_touch=True)
    admin_page=ca_ctx.new_page();mara=pa_ctx.new_page();noel=pb_ctx.new_page()
    for page,label in [(admin_page,'admin'),(mara,'Mara'),(noel,'Noel')]:
        page.on('pageerror',lambda e,who=label:errors.append(f'{who}: {e}'))
    def ui_login(page,email,password,selector):
        page.goto(BASE,wait_until='domcontentloaded')
        page.wait_for_selector('body.booted',timeout=18000)
        page.locator('[data-view="login"]').first.click()
        page.locator('#authForm input[name="email"]').fill(email)
        page.locator('#authForm input[name="password"]').fill(password)
        page.locator('#authForm button[type="submit"]').click()
        page.wait_for_selector(selector,timeout=30000)
        page.wait_for_timeout(600)
    ui_login(admin_page,ADMIN_EMAIL,ADMIN_PASSWORD,'.admin-grid')
    record('Real admin browser sign-in', 'Test Administrator' in admin_page.locator('body').inner_text())
    ui_login(mara,people[0][1],PATIENT_PASSWORD,'.quick-grid')
    ui_login(noel,people[1][1],PATIENT_PASSWORD,'.quick-grid')
    record('Two real patient browser sign-ins', 'Mara' in mara.locator('body').inner_text() and 'Noel' in noel.locator('body').inner_text())
    # Confirm real WebSocket, not test fixture polling.
    ws_count=sum(page.evaluate('S.ws?.readyState === WebSocket.OPEN') for page in (admin_page,mara,noel))
    record('Authenticated WebSocket connections',ws_count==3, f'{ws_count}/3')
    # Navigate and select real patient thread (admin).
    admin_page.locator('.nav-button[data-view="messages"]').click()
    admin_page.wait_for_selector('.chat-layout .conversation-row',timeout=15000)
    admin_page.locator('.conversation-row',has_text='Mara Ellis').first.click()
    admin_page.wait_for_selector('.bubble-content',timeout=15000)
    record('Admin can read patient inbox in browser',seed in admin_page.locator('.messages').inner_text())
    def screenshot(page,name):
        page.wait_for_timeout(400)
        page.locator('.toast').evaluate_all('(els)=>els.forEach(el=>el.remove())')
        path=OUT/name
        page.screenshot(path=str(path),full_page=True,animations='disabled')
        screens.append(str(path.relative_to(ROOT)))
        metrics=page.evaluate('''() => ({width:innerWidth,scroll:document.documentElement.scrollWidth})''')
        record('No horizontal overflow: '+name,metrics['scroll']<=metrics['width']+1,str(metrics))
    screenshot(admin_page,'actual-backend-admin-desktop.png')
    mara.locator('.bottom-nav [data-view="messages"]').click()
    mara.wait_for_selector('#messageForm',timeout=15000)
    mara.locator('#messageText').fill('I am sending this from the signed-in patient browser.')
    mara.locator('#messageForm button[type="submit"]').click()
    admin_page.wait_for_function("() => document.querySelector('.messages')?.innerText.includes('signed-in patient browser')",timeout=18000)
    record('Live patient → admin chat via real WebSocket',True)
    reply='Hello Mara, your message reached the care team. We can discuss the next steps.'
    admin_page.locator('#messageText').fill(reply)
    admin_page.locator('#messageForm button[type="submit"]').click()
    mara.wait_for_function("() => document.querySelector('.messages')?.innerText.includes('your message reached')",timeout=18000)
    record('Live admin → patient chat via real WebSocket',True)
    # Attachment was stored through original Worker; browser must retrieve it with same-origin credentials.
    mara.wait_for_selector('.chat-attachment img',timeout=12000)
    record('Actual private attachment displayed in patient browser',mara.locator('.chat-attachment img').first.evaluate('(img)=>img.complete && img.naturalWidth>0'))
    screenshot(mara,'actual-backend-patient-chat-mobile.png')
    screenshot(admin_page,'actual-backend-admin-chat-with-photo.png')
    # Verify reload reads from DB, not JS memory.
    mara.reload(wait_until='domcontentloaded')
    mara.wait_for_selector('body.booted')
    mara.locator('.bottom-nav [data-view="messages"]').click()
    mara.wait_for_function("() => document.querySelector('.messages')?.innerText.includes('your message reached')",timeout=12000)
    record('Chat persists after full browser reload',True)
    # Queue must serialize 2 patients; use real UI actions.
    mara.locator('.bottom-nav [data-view="calls"]').click()
    mara.wait_for_selector('[data-action="request-call"]')
    mara.locator('[data-action="request-call"]').click()
    mara.wait_for_function("() => !!document.querySelector('.calling-card')?.innerText.includes('Your request is next')",timeout=12000)
    noel.locator('.bottom-nav [data-view="calls"]').click()
    noel.wait_for_selector('[data-action="request-call"]')
    noel.locator('[data-action="request-call"]').click()
    noel.wait_for_function("() => document.querySelector('.queue')?.innerText.includes('1')",timeout=12000)
    record("Second patient's real browser joins queued call",True)
    screenshot(noel,'actual-backend-patient-waiting.png')
    admin_page.locator('.nav-button[data-view="calls"]').click()
    admin_page.wait_for_selector('[data-action="accept-call"]',timeout=15000)
    screenshot(admin_page,'actual-backend-admin-incoming-call.png')
    admin_page.locator('[data-action="accept-call"]').click()
    admin_page.wait_for_selector('[data-action="ready-audio"]',timeout=15000)
    mara.wait_for_selector('[data-action="ready-audio"]',timeout=15000)
    screenshot(admin_page,'actual-backend-admin-active-call.png')
    # Two fake microphones and an actual PeerConnection: this test is not a human audio-quality test.
    try:
        mara.locator('[data-action="ready-audio"]').click()
        mara.wait_for_function("() => !!S.rtc",timeout=12000)
        admin_page.wait_for_function("() => !!S.rtc",timeout=12000)
        admin_page.wait_for_function("() => S.rtc?.connectionState === 'connected'",timeout=25000)
        mara.wait_for_function("() => S.rtc?.connectionState === 'connected'",timeout=25000)
        a_state=admin_page.evaluate('''() => ({state:S.rtc.connectionState,remoteTracks:document.querySelector('#remoteAudio')?.srcObject?.getAudioTracks().length||0})''')
        p_state=mara.evaluate('''() => ({state:S.rtc.connectionState,remoteTracks:document.querySelector('#remoteAudio')?.srcObject?.getAudioTracks().length||0})''')
        ok=a_state['state']=='connected' and p_state['state']=='connected' and a_state['remoteTracks']>=1 and p_state['remoteTracks']>=1
        record('WebRTC peer connection with fake microphones',ok,{'admin':a_state,'patient':p_state})
        rtc_result={'status':'PASS' if ok else 'FAIL','admin':a_state,'patient':p_state,'scope':'Synthetic microphones only, not clinical audio quality'}
    except Exception as e:
        rtc_result={'status':'FAIL','detail':str(e)[:500]}
        results.append({'test':'WebRTC peer connection with fake microphones','status':'FAIL','detail':str(e)[:500]})
        print('FAIL WebRTC media connection:',str(e)[:190],flush=True)
    # End call and verify queue promotes next patient.
    admin_page.locator('[data-action="end-call"]').click()
    admin_page.wait_for_selector('[data-action="accept-call"]',timeout=16000)
    noel.wait_for_function("() => document.querySelector('.calling-card')?.innerText.includes('Your request is next')",timeout=15000)
    record('Ending active call promotes next patient automatically',True)
    screenshot(noel,'actual-backend-second-patient-promoted.png')
    # Additional screenshots for 320px in real app.
    narrow=browser.new_context(viewport={'width':320,'height':760},permissions=['microphone'],is_mobile=True)
    screen320=narrow.new_page()
    ui_login(screen320,people[0][1],PATIENT_PASSWORD,'.quick-grid')
    screen320.locator('.bottom-nav [data-view="messages"]').click()
    screen320.wait_for_selector('.bubble-content')
    screenshot(screen320,'actual-backend-patient-chat-320.png')
    narrow.close()
    record('No uncaught browser JS exceptions',len(errors)==0,errors)
    browser.close()

# On-disk, not a fake in-memory fixture.
dbfile=Path(os.environ.get('AVENSHORE_TEST_DATA','/tmp/avenshore-live-qa-2026'))/'clinic.sqlite'
conn=sqlite3.connect(dbfile)
record('Real SQLite records committed to disk',conn.execute('select count(*) from users').fetchone()[0]>=3 and conn.execute('select count(*) from messages').fetchone()[0]>=4)
conn.close()
report={
 'scope':'Original Worker handlers + original Durable Object logic under Node compatibility harness, on-disk SQLite, disk-backed private objects, and browser WebSockets',
 'not_verified':['Deployed Cloudflare D1/R2/Durable Object bindings','Production authentication protections including configured Turnstile/WAF','WebRTC TURN relay and cross-network NAT reliability','Clinical security and privacy compliance'],
 'screenshots':screens,'webRTC':rtc_result,'tests':results,
 'summary':{'passed':sum(r['status']=='PASS' for r in results),'failed':sum(r['status']=='FAIL' for r in results),'screenshots':len(screens)}
}
(OUT/'REAL_BACKEND_QA_RESULTS.json').write_text(json.dumps(report,indent=2))
print('SUMMARY',json.dumps(report['summary']),flush=True)
