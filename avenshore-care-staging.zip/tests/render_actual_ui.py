"""Render screenshots from the actual Avenshore public source files inside headless Chromium.
Local browser navigation is disabled in this runtime, so files are inlined into
an about:blank page; API calls are deliberately mocked with fictional actors.
This is UI verification only, not a backend integration test.
"""
import base64
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
PUB = ROOT / 'public'
OUT = ROOT / 'docs' / 'qa'
OUT.mkdir(parents=True, exist_ok=True)
svg = base64.b64encode((PUB/'assets'/'mark.svg').read_bytes()).decode()
mark = 'data:image/svg+xml;base64,' + svg
html = (PUB/'index.html').read_text()
css = (PUB/'styles.css').read_text()
motion = (PUB/'motion.css').read_text()
refinement = (PUB/'refinement.css').read_text()
chat_styles = (PUB/'chat-premium.css').read_text()
alignment_styles=(PUB/'alignment.css').read_text()
homepage_styles=(PUB/'homepage-refresh.css').read_text()
js = (PUB/'app.js').read_text().replace('/assets/mark.svg',mark)
html = html.replace('/assets/mark.svg',mark)
html = html.replace('<link rel="stylesheet" href="/styles.css">', '<style>'+css+'</style>')
html = html.replace('<link rel="stylesheet" href="/motion.css">','<style>'+motion+'</style>')
html = html.replace('<link rel="stylesheet" href="/refinement.css">','<style>'+refinement+'</style>')
html = html.replace('<link rel="stylesheet" href="/chat-premium.css">','<style>'+chat_styles+'</style>')
html = html.replace('<link rel="stylesheet" href="/alignment.css">','<style>'+alignment_styles+'</style>')
html = html.replace('<link rel="stylesheet" href="/homepage-refresh.css">','<style>'+homepage_styles+'</style>')
html = html.replace('<script defer src="/app.js"></script>','')

shim = '''<script>
window.fetch = async function(url, options) {
 const path = String(url).split('/api/')[1]?.split('?')[0];
 if (!path) throw new Error('Only mock API supported in browser capture');
 const actor = window.__ACTOR__;
 const responses = {
   me: {actor:actor,turnstileSiteKey:null},
   conversations:{conversations:[]},
   calls:{active:null,queue:[],position:null,busy:false},
   status:{status:'ok'}
 };
 const body = JSON.stringify(responses[path]||{});
 return new Response(body,{status:200,headers:{'content-type':'application/json'}});
}
</script>'''
html = html.replace('</body>',shim+'<script>'+js+'</script></body>')

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    def render(role, name, width, height, target, view=None, reduced=False):
        ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,is_mobile=(width<700),reduced_motion='reduce' if reduced else 'no-preference')
        page=ctx.new_page()
        errors=[]
        page.on('pageerror',lambda err:errors.append(str(err)))
        actor={'id':'p1','role':'patient','name':'Sarah Example','email':'sarah@example.invalid'} if role=='patient' else {'id':'admin1','role':'admin','name':'Taylor Example','email':'staff@example.invalid'} if role=='admin' else None
        page.add_init_script('window.__ACTOR__='+json.dumps(actor))
        # set_content does not trigger add_init_script for an about:blank document,
        # so a minimal actor assignment is prepended as a script.
        document=html.replace('<script>\nwindow.fetch', '<script>window.__ACTOR__='+json.dumps(actor)+';</script><script>\nwindow.fetch',1)
        page.set_content(document,wait_until='load',timeout=15000)
        page.wait_for_selector('body.booted',timeout=10000)
        page.wait_for_timeout(550)
        assert not page.locator('.toast').count(), 'Unexpected error notification in UI capture'
        if view:
            selector=('.bottom-nav' if width<700 else '.sidebar') + f' [data-view="{view}"]'
            page.locator(selector).click()
            page.wait_for_timeout(250)
        path=OUT/name
        page.screenshot(path=str(path),full_page=True)
        print(f'{name} | heading={page.locator("h1").first.inner_text() if page.locator("h1").count() else "(none)"} | errors={errors}')
        assert not errors,errors
        ctx.close()
    render(None,'public-mobile.png',390,844,'public-mobile')
    render(None,'public-desktop.png',1440,900,'public-desktop')
    render('patient','patient-mobile.png',390,844,'patient-mobile')
    render('patient','messages-mobile.png',390,844,'messages-mobile',view='messages')
    render('patient','calls-mobile.png',390,844,'calls-mobile',view='calls')
    render('admin','admin-desktop.png',1440,900,'admin-desktop')
    render('patient','reduced-motion.png',390,844,'reduced-motion',reduced=True)
    # Loader capture uses the real source and styles with a delayed fixture response.
    loader_html=html.replace('<script>\nwindow.fetch', '<script>window.__ACTOR__=null;</script><script>\nwindow.fetch',1)
    loader_html=loader_html.replace('const path = String(url).split', 'await new Promise(resolve=>setTimeout(resolve,1700)); const path = String(url).split')
    ctx=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True)
    page=ctx.new_page();page.set_content(loader_html,wait_until='load',timeout=15000)
    page.wait_for_timeout(220)
    assert page.locator('#boot-screen').is_visible(), 'Branded boot loader should be visible while initialization is pending'
    assert page.locator('#boot-screen img').count()==1, 'Approved emblem missing from loader'
    page.screenshot(path=str(OUT/'loading-mobile.png'),full_page=False)
    page.wait_for_selector('body.booted',timeout=7000)
    print('loading-mobile.png | brand loader visible and automatically finishes')
    ctx.close()
    browser.close()
