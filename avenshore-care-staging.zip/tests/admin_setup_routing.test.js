import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../public/app.js',import.meta.url),'utf8').replace(/initialize\(\);\s*$/,'');
const token='fictional-admin-link-token-with-32-chars';
function fixture({status='missing_secret',actor=null,hash='#admin-setup='+token,fail=false}={}){
 const listeners={};const location={hash,pathname:'/',search:''};
 const context=vm.createContext({document:{getElementById:()=>({addEventListener(){}})},window:{addEventListener:(name,fn)=>listeners[name]=fn},location,history:{replaceState(){location.hash='';}},sessionStorage:{getItem:()=>actor?.role==='visitor'?'messages':null},setInterval(){},fetch:async()=>{if(fail)throw new Error('Offline');return {ok:true,json:async()=>({actor,adminSetupStatus:status,adminSetupAvailable:status==='available'})};}});
 vm.runInContext(source,context);
 vm.runInContext("render=()=>{};refreshConversations=async()=>{};refreshCall=async()=>{};connectRealtime=()=>{};",context);
 return {context,listeners,location,run:code=>vm.runInContext(code,context)};
}
for(const [status,title] of [['missing_secret','Setup key is not connected'],['invalid_secret','Setup key configuration is incomplete'],['completed','Administrator already created']]){
 test(`setup link displays ${status} without silently opening Home`,async()=>{
  const f=fixture({status,actor:{id:'visitor',role:'visitor',name:'Website visitor'}});await f.run('initialize()');
  const html=f.run('screen()');assert.match(html,new RegExp(title));assert.doesNotMatch(html,/id="adminSetupForm"/);assert.ok(!html.includes(token));assert.equal(f.run('S.view'),'admin-setup');
 });
}
for(const role of ['visitor','patient']){
 test(`valid setup link opens credential form despite an existing ${role} session`,async()=>{
  const f=fixture({status:'available',actor:{id:role,role,name:'Fictional User'}});await f.run('initialize()');
  assert.match(f.run('screen()'),/id="adminSetupForm"/);assert.equal(f.location.hash,'');assert.equal(f.run('S.adminSetupToken'),token);
 });
}
test('invalid link shows a clear error and cannot open credential setup',async()=>{
 const f=fixture({status:'available',hash:'#admin-setup=too-short'});await f.run('initialize()');assert.match(f.run('screen()'),/Open your complete private setup link/);assert.doesNotMatch(f.run('screen()'),/id="adminSetupForm"/);
});
test('setup link added to an already-open page is handled',async()=>{
 const f=fixture({status:'available',hash:''});await f.run('initialize()');assert.equal(f.run('S.adminSetupRequested'),false);
 f.location.hash='#admin-setup='+token;await f.listeners.hashchange();
 // The event listener starts the async initialization; drain its awaited fetch/json operations.
 await new Promise(resolve=>setImmediate(resolve));
 assert.match(f.run('screen()'),/id="adminSetupForm"/);
});
test('setup retry checks the current binding and opens the form without reopening the URL',async()=>{
 const f=fixture();await f.run('initialize()');
 f.context.fetch=async()=>({ok:true,json:async()=>({adminSetupAvailable:true,adminSetupStatus:'available'})});
 f.run('mutate=async fn=>fn()');await f.run('retryAdminSetup()');assert.match(f.run('screen()'),/id="adminSetupForm"/);
});

test('arthritis support appears on public Home, sign-in and patient Home',()=>{
 const f=fixture({hash:''});f.run("S.actor={id:'fictional',role:'patient',name:'Fictional Patient'}");
 for(const html of [f.run('welcome()'),f.run("authPage('login')"),f.run('home()')])assert.match(html,/Arthritis and joint pain/);
 assert.match(f.run('welcome()'),/elderly-man-portrait\.webp/);assert.doesNotMatch(f.run('welcome()'),/senior-telehealth|Illustrative stock/);
});
test('both patient and administrator accounts expose optional photo preview/save/remove controls',()=>{
 const f=fixture({hash:''});
 for(const role of ['patient','admin']){
  f.run(`S.actor={id:'fictional',role:'${role}',name:'Fictional User',photo_url:'/api/profile-photos/fictional?v=test-version'}`);
  const html=f.run('account()');assert.match(html,/id="profilePhotoInput"/);assert.match(html,/Change photo/);assert.match(html,/Remove photo/);assert.match(f.run('appHeader()'),/profile-photos\/fictional/);
  f.run("S.profileDraft={};S.profilePreview='blob:fictional-preview'");const preview=f.run('account()');assert.match(preview,/Save photo/);assert.match(preview,/Cancel/);assert.match(preview,/Preview only/);
  f.run("S.profileDraft=null;S.profilePreview='';S.actor.photo_url=null");assert.match(f.run('account()'),/Choose photo/);assert.doesNotMatch(f.run('account()'),/data-action="remove-profile-photo"/);
 }
 assert.doesNotMatch(f.run("avatarContent('Example','https://tracker.example/photo.jpg')"),/<img/);
});
test('care conversation photos appear in inbox, thread and message sender; guests keep generic avatars',()=>{
 const f=fixture({hash:''});f.run("S.actor={id:'p1',role:'patient',name:'Fictional Patient',photo_url:null};S.selected='care1';S.conversations=[{id:'care1',kind:'care',photo_url:'/api/profile-photos/staff?v=version-one'}]");
 assert.match(f.run('convList()'),/profile-photos\/staff/);
 assert.match(f.run("bubble({sender_type:'admin',content:'Fictional test'},null)"),/profile-photos\/staff/);
 assert.doesNotMatch(f.run("conversationAvatar({kind:'site-help',photo_url:'/api/profile-photos/staff?v=version-one'})"),/<img/);
});
