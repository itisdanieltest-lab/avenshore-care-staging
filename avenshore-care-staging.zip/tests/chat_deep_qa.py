"""Live Chromium DOM/interaction testing with fictional account and API fixtures.

No real clinic connection. Tests browser sign-in/navigation/search/draft/refresh,
image presentation, click target dimensions, responsive rendering and overflow.
"""
from pathlib import Path
import json, base64, time
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
PUB=ROOT/'public'
OUT=ROOT/'docs'/'qa'
OUT.mkdir(parents=True,exist_ok=True)
mark=base64.b64encode((PUB/'assets'/'mark.svg').read_bytes()).decode()
html=(PUB/'index.html').read_text().replace('/assets/mark.svg',f'data:image/svg+xml;base64,{mark}')
for css in ('styles.css','motion.css','refinement.css','chat-premium.css','alignment.css','homepage-refresh.css'):
  assert (PUB/css).exists(), f'Missing stylesheet: {css}'
  html=html.replace(f'<link rel="stylesheet" href="/{css}">', '<style>'+ (PUB/css).read_text()+'</style>')
html=html.replace('<script defer src="/app.js"></script>', '')
now=int(time.time()*1000)
conversations=[
 {'id':'c-olivia','kind':'care','display_name':'Olivia Bennett','last_message':'Thank you, that is very helpful.','updated_at':now-60000},
 {'id':'c-isaac','kind':'care','display_name':'Isaac Okafor','last_message':'I have a question about the appointment.','updated_at':now-600000},
 {'id':'c-maria','kind':'care','display_name':'Maria Silva','last_message':'Here is the photo you requested.','updated_at':now-900000},
 {'id':'c-guest','kind':'site-help','display_name':'Website visitor','last_message':'How do I finish signing up?','updated_at':now-1100000},
]
msg={'c-olivia':[
 {'id':'o1','sender_type':'patient','content':'Good morning. I need some guidance about my next care appointment.','created_at':now-3600000},
 {'id':'o2','sender_type':'admin','content':'Good morning, Olivia. I can help you find the right next step. Are you comfortable telling me what you need assistance with?','created_at':now-3300000},
 {'id':'o3','sender_type':'patient','content':'Yes, I have the appointment card and a few questions.','created_at':now-2900000},
 {'id':'o4','sender_type':'patient','content':None,'attachment_id':'sample-image','created_at':now-2400000},
 {'id':'o5','sender_type':'admin','content':'Thank you for sharing that. I’ll pass your question to the appropriate care professional. Please avoid sending anything unrelated to your care.','created_at':now-1800000},
 {'id':'o6','sender_type':'patient','content':'Thank you, that is very helpful.','created_at':now-900000},
 ],
 'c-isaac':[{'id':'i1','sender_type':'patient','content':'Hello. I have a question about my next appointment.','created_at':now-1000000}],
 'c-maria':[{'id':'m1','sender_type':'patient','content':'Here is the photo you requested.','created_at':now-1200000}],
 'c-guest':[{'id':'g1','sender_type':'visitor','content':'How do I finish signing up?','created_at':now-1100000}],
}
fixture=f'''
<script>
window.__qa={{actor:null, conversations:{json.dumps(conversations)}, messages:{json.dumps(msg)}, loginCalls:0, messageCalls:0, attachmentCalls:0, failSend:false, pickerOpened:false}};
window.fetch=async (input,options={{}})=>{{
  const raw=String(input), path=raw.split('/api/')[1]?.split('?')[0]||'';
  const method=options.method||'GET';
  let body={{}}, status=200;
  if(path==='me')body={{actor:window.__qa.actor,turnstileSiteKey:null}};
  else if(path==='auth/login' && method==='POST'){{
    let info={{}};try{{info=JSON.parse(options.body)}}catch{{}}
    window.__qa.loginCalls++;
    window.__qa.actor=info.email.startsWith('patient')?{{id:'patient-qa',role:'patient',name:'Olivia Example',email:info.email}}:{{id:'admin-qa',role:'admin',name:'Taylor Example',email:info.email}};
    body={{ok:true}};
  }}
  else if(path==='conversations')body={{conversations:window.__qa.actor?.role==='patient'?window.__qa.conversations.filter(c=>c.id==='c-olivia'):window.__qa.conversations}};
  else if(path.startsWith('conversations/')&&path.endsWith('/messages')){{
    const id=path.split('/')[1];
    if(method==='POST'){{
      if(window.__qa.failSend){{body={{error:'The connection was interrupted. Please try again.'}};status=503;}}
      else{{
        let sent=JSON.parse(options.body);window.__qa.messageCalls++;
        window.__qa.messages[id].push({{id:'sent-'+window.__qa.messageCalls,sender_type:'admin',content:sent.content,created_at:Date.now()}});
        window.__qa.conversations.find(c=>c.id===id).last_message=sent.content;
        body={{ok:true}};
      }}
    }}else body={{messages:window.__qa.messages[id]||[]}};
  }}
  else if(path.startsWith('conversations/')&&path.endsWith('/attachments')&&method==='POST'){{ window.__qa.attachmentCalls++;body={{ok:true}}; }}
  else if(path==='calls')body={{active:null,queue:[],position:null,busy:false}};
  else body={{ok:true}};
  return new Response(JSON.stringify(body),{{status,headers:{{'content-type':'application/json'}}}});
}};
</script>
'''
html=html.replace('</body>',fixture+'<script>'+ (PUB/'app.js').read_text().replace('/assets/mark.svg',f'data:image/svg+xml;base64,{mark}')+'</script></body>')
# The fixture photo is a neutral illustration, not medical or patient data.
photo_svg='<svg xmlns="http://www.w3.org/2000/svg" width="520" height="330" viewBox="0 0 520 330"><rect width="520" height="330" rx="26" fill="#e8eee7"/><rect x="110" y="40" width="300" height="250" rx="16" fill="#fff" stroke="#d7e2db" stroke-width="3"/><rect x="142" y="75" width="230" height="16" rx="8" fill="#b6d2c4"/><rect x="142" y="115" width="184" height="12" rx="6" fill="#dce8de"/><rect x="142" y="145" width="202" height="12" rx="6" fill="#dce8de"/><rect x="142" y="175" width="174" height="12" rx="6" fill="#dce8de"/><rect x="142" y="220" width="124" height="34" rx="10" fill="#c9e6d8"/><path d="M164 237h72" stroke="#327a64" stroke-width="5" stroke-linecap="round"/></svg>'
photo='data:image/svg+xml;base64,'+base64.b64encode(photo_svg.encode()).decode()

def decorate(page):
  page.evaluate('(src)=>document.querySelectorAll(".chat-attachment img").forEach(i=>i.src=src)',photo)

results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (320,390,768,1024,1440):
  context=browser.new_context(viewport={'width':width,'height':900 if width>=768 else 844},device_scale_factor=1,is_mobile=width<760)
  page=context.new_page();errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load')
  page.wait_for_selector('body.booted')
  page.wait_for_selector('#boot-screen',state='detached')
  # Real browser uses the actual login form and events; authentication response is mocked.
  page.locator('[data-view="login"]').first.click()
  page.locator('input[name="email"]').fill('staff@example.invalid')
  page.locator('input[name="password"]').fill('test-password-only')
  page.locator('#authForm [type="submit"]').click()
  page.wait_for_selector('.admin-grid .chat-list',timeout=7000)
  page.locator('.nav-button[data-view="messages"]' if width>=761 else '.bottom-nav [data-view="messages"]').click()
  page.wait_for_selector('.chat-layout .chat-list .conversation-row',timeout=7000)
  if width<761:page.locator('.chat-list .conversation-row[data-select="c-olivia"]').click()
  page.wait_for_selector('.message-group')
  decorate(page)
  page.wait_for_timeout(750) # Allow view transition; avoid faded intermediate frame.
  page.locator('.toast').evaluate_all('(els)=>els.forEach(el=>el.remove())')
  page.screenshot(path=str(OUT/f'chat-admin-{width}.png'),full_page=True)
  numbers=page.evaluate('''() => ({width:innerWidth, scroll:document.documentElement.scrollWidth,
    inbox:Math.round(document.querySelector('.chat-list').getBoundingClientRect().width),
    thread:Math.round(document.querySelector('.conversation').getBoundingClientRect().width),
    bubbleFont:getComputedStyle(document.querySelector('.bubble')).fontSize,
    attachment:!!document.querySelector('.chat-attachment img')})''')
  assert numbers['scroll']<=width+1,(width,numbers)
  if width<761:
   bounds=page.evaluate('''() => ({composer:document.querySelector('.composer').getBoundingClientRect().bottom,nav:document.querySelector('.bottom-nav').getBoundingClientRect().top})''')
   assert bounds['composer'] <= bounds['nav']-4, ('Composer hidden under mobile nav',width,bounds)
  assert not errors,(width,errors)
  results.append({'viewport':width,'outcome':'PASS','bubble_font':numbers['bubbleFont'],'overflow':numbers['scroll']-width})
  if width==1440:
   page.locator('#messageText').fill('My unsent draft must survive polling and thread switches.')
   page.evaluate('refreshConversations()')
   page.wait_for_timeout(100)
   assert page.locator('#messageText').input_value()=='My unsent draft must survive polling and thread switches.'
   assert page.locator('#messageText').evaluate('(el)=>document.activeElement===el'), 'Focus was stolen during refresh'
   page.locator('.chat-list .conversation-row[data-select="c-isaac"]').click()
   page.locator('.chat-list .conversation-row[data-select="c-olivia"]').click()
   page.wait_for_selector('.bubble-content')
   assert page.locator('#messageText').input_value()=='My unsent draft must survive polling and thread switches.'
   # New messages must not appear after a failed send; draft should be retained.
   page.evaluate('window.__qa.failSend=true')
   page.locator('#messageForm [type="submit"]').click()
   page.wait_for_timeout(100)
   assert page.locator('#messageText').input_value()=='My unsent draft must survive polling and thread switches.'
   assert page.evaluate('window.__qa.messageCalls')==0
   page.evaluate('window.__qa.failSend=false')
   page.locator('#messageForm [type="submit"]').click()
   page.wait_for_timeout(100)
   assert page.evaluate('window.__qa.messageCalls')==1
   assert page.locator('#messageText').input_value()==''
   assert page.locator('.bubble-content').last.inner_text()=='My unsent draft must survive polling and thread switches.'
   # Search should keep the cursor, then support filtering the list.
   page.locator('#conversationSearch').fill('Isaac')
   assert page.locator('.conversation-row').count()==1
   assert page.locator('#conversationSearch').evaluate('(el)=>document.activeElement===el')
   page.locator('#conversationSearch').fill('')
   # A hidden input alone is inaccessible to keyboard users; use our visible button.
   page.evaluate('''() => {document.querySelector('#imageUpload').click=()=>window.__qa.pickerOpened=true;}''')
   page.locator('[data-action="pick-image"]').focus()
   page.keyboard.press('Enter')
   assert page.evaluate('window.__qa.pickerOpened'), 'Keyboard cannot activate the photo picker'
   results.append({'interaction':'photo picker keyboard activation','outcome':'PASS'})
   page.screenshot(path=str(OUT/'chat-admin-search-desktop.png'),full_page=False)
   results.append({'interaction':'draft across refresh/switch, send failure/retry, search focus','outcome':'PASS'})
  if width==390:
   page.locator('#messageText').fill('A patient can compose while the inbox changes.')
   page.evaluate('refreshConversations()')
   assert page.locator('#messageText').input_value()=='A patient can compose while the inbox changes.'
   results.append({'interaction':'mobile draft survives refresh','outcome':'PASS'})
   page.locator('.bottom-nav [data-view="admin"]').click()
   page.locator('.admin-grid [data-select="c-isaac"]').click()
   assert page.locator('.chat-layout.mobile-thread-open').count()==1
   assert 'Isaac' in page.locator('.conversation-head').inner_text()
   results.append({'interaction':'admin mobile dashboard conversation opens inbox thread','outcome':'PASS'})
  context.close()
 # Separately sign into patient workspace using the same visible form.
 for width in (390,1440):
  ctx=browser.new_context(viewport={'width':width,'height':844 if width==390 else 900},device_scale_factor=1,is_mobile=(width==390))
  page=ctx.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content(html,wait_until='load');page.wait_for_selector('body.booted');page.wait_for_selector('#boot-screen',state='detached')
  page.locator('[data-view="login"]').first.click()
  page.locator('input[name="email"]').fill('patient@example.invalid')
  page.locator('input[name="password"]').fill('test-password-only')
  page.locator('#authForm [type="submit"]').click()
  page.wait_for_selector('.quick-grid')
  page.locator('.bottom-nav [data-view="messages"]' if width==390 else '.nav-button[data-view="messages"]').click()
  page.wait_for_selector('.message-group')
  decorate(page)
  page.wait_for_timeout(750)
  page.locator('.toast').evaluate_all('(els)=>els.forEach(el=>el.remove())')
  assert page.locator('.conversation-row').count()==1, 'Patient must not see other conversations in mock account view'
  assert not errs,errs
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  page.screenshot(path=str(OUT/f'chat-patient-{width}.png'),full_page=True)
  results.append({'viewport':width,'interaction':'patient signed-in chat rendering','outcome':'PASS'})
  ctx.close()
 # Reduced motion: no animated chat effects.
 context=browser.new_context(viewport={'width':390,'height':844},reduced_motion='reduce')
 page=context.new_page();page.set_content(html);page.wait_for_selector('body.booted');page.wait_for_selector('#boot-screen',state='detached')
 assert page.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches")
 context.close();browser.close()
(OUT/'CHAT_DEEP_QA_RESULTS.json').write_text(json.dumps(results,indent=2))
print('PASS: browser sign-in (mock API), conversations, read/search/send and '+str(len(results))+' checks across five widths.')
print('Screenshots:',*[str(OUT/f'chat-admin-{w}.png') for w in (320,390,768,1024,1440)],sep='\n  ')
