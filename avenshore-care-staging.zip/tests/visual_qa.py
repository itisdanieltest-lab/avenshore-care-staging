"""UI audit in real Chromium with actual project HTML, CSS & JavaScript.
The API and account fixtures are fictional. No real patient or network backend.
The execution environment blocks local server navigation, so asset URLs are
inlined; layout and UI interactions run in Chromium, not in an image generator.
"""
import base64, json
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];P=R/'public';OUT=R/'docs'/'qa'
OUT.mkdir(exist_ok=True,parents=True)
svg=base64.b64encode((P/'assets/mark.svg').read_bytes()).decode()
html=(P/'index.html').read_text()
html=html.replace('/assets/mark.svg','data:image/svg+xml;base64,'+svg)
for fn in ['styles.css','motion.css','refinement.css','chat-premium.css']:
 html=html.replace(f'<link rel="stylesheet" href="/{fn}">','<style>'+ (P/fn).read_text()+'</style>')
html=html.replace('<script defer src="/app.js"></script>','')
script='''
<script>
window.fetch=async url => {
const path=String(url).split('/api/')[1]?.split('?')[0];
const responses={me:{actor:window.__TEST_ACTOR__,turnstileSiteKey:null},conversations:{conversations:[]},calls:{active:null,queue:[],position:null,busy:false},status:{status:'ok'}};
return new Response(JSON.stringify(responses[path]||{}),{status:200,headers:{'content-type':'application/json'}});
};
</script>
'''
html=html.replace('</body>',script+'<script>'+(P/'app.js').read_text().replace('/assets/mark.svg','data:image/svg+xml;base64,'+svg)+'</script></body>')
roles={
 'public':None,
 'patient':{'id':'demo-p1','role':'patient','name':'Sarah Example','email':'sarah@example.invalid'},
 'admin':{'id':'demo-a1','role':'admin','name':'Taylor Example','email':'taylor@example.invalid'}
}
checks=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for role in roles:
  for width in (320,375,390,768,1024,1440):
   ctx=b.new_context(viewport={'width':width,'height':850},device_scale_factor=1,is_mobile=(width<760),reduced_motion='no-preference')
   page=ctx.new_page(); errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   content=html.replace('<script>\nwindow.fetch',f'<script>window.__TEST_ACTOR__={json.dumps(roles[role])};</script><script>\nwindow.fetch',1)
   page.set_content(content,wait_until='load',timeout=15000)
   page.wait_for_selector('body.booted',timeout=12000)
   page.wait_for_selector('#boot-screen',state='detached',timeout=5000)
   page.wait_for_timeout(180)
   metrics=page.evaluate('''() => ({inner:innerWidth,scroll:document.documentElement.scrollWidth,body:document.body.scrollWidth,heading:getComputedStyle(document.querySelector('h1')).fontSize,nav:document.querySelector('.bottom-nav button')?getComputedStyle(document.querySelector('.bottom-nav button')).fontSize:null})''')
   overflow=metrics['scroll']-metrics['inner']
   checks.append({'role':role,'viewport':width,'overflow_px':overflow,'h1_font':metrics['heading'],'nav_font':metrics['nav'],'js_errors':len(errors)})
   assert overflow<=1,(role,width,'Horizontal overflow',metrics)
   assert not errors,(role,width,errors)
   if width==320 and role=='public':page.screenshot(path=str(OUT/'public-320.png'),full_page=True)
   if width==390 and role=='public':
    page.locator('.public-copy [data-view="register"]').click()
    assert 'Create your account' in page.locator('main').inner_text()
    assert page.locator('#authForm').count()==1
    page.wait_for_timeout(350)
    page.screenshot(path=str(OUT/'register-mobile.png'),full_page=True)
   if width==390 and role=='admin':page.screenshot(path=str(OUT/'admin-mobile.png'),full_page=True)
   if width==1440 and role=='patient':page.screenshot(path=str(OUT/'patient-desktop.png'),full_page=True)
   if width==1440 and role=='public':
    page.locator('.public-nav [data-view="login"]').click()
    assert page.locator('#authForm').count()==1
    page.wait_for_timeout(350)
    page.screenshot(path=str(OUT/'login-desktop.png'),full_page=True)
   ctx.close()
 b.close()
report=OUT/'VISUAL_QA_RESULTS.md'
lines=['# Avenshore browser layout quality checks','', 'Tested in real Chromium with inlined production HTML/CSS/JS, fictional account/API fixtures. These are not HTTP deployment or backend security tests.','','| Role | Width | Horizontal overflow | H1 size | Mobile nav size | JS errors |','|---|---:|---:|---|---|---:|']
for c in checks:lines.append(f"| {c['role']} | {c['viewport']}px | {c['overflow_px']}px | {c['h1_font']} | {c['nav_font'] or '—'} | {c['js_errors']} |")
lines.extend(['','**Outcome:** Passed horizontal-overflow and JavaScript-error checks at six widths for three user states. Public-to-register and sign-in navigation exercised.','**Not tested:** live Cloudflare backend, physical device, third-party font availability, real calling/media, deployment security or 200% text resize.'])
report.write_text('\n'.join(lines)+'\n')
print(f'PASS: {len(checks)} Chromium viewport/role checks, no horizontal scrolling or JS errors. Report: {report}')
