"""Real backend integration + browser UI verification where Chromium local navigation is blocked.

Browser HTML/CSS/JS are the ORIGINAL project files. Browser fetch calls are bridged
through isolated httpx sessions to the ORIGINAL Worker handlers running against
real on-disk SQLite, a private local file store, Durable Object call queue and
WebSockets. This is not a full browser network/WebRTC test or Cloudflare deploy.
"""
import base64, json, os, socket, sqlite3, subprocess, time, uuid, tempfile
from pathlib import Path
import httpx, websocket
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs'/'qa'/'real-integration';OUT.mkdir(parents=True,exist_ok=True)
PORT=8795
BASE=f'http://127.0.0.1:{PORT}'
DIR=Path(tempfile.mkdtemp(prefix='avenshore-v3-fullsuite-'))
DIR.mkdir(parents=True,exist_ok=True)
SETUP='LocalDevelopmentSetupToken_Only_For_QA_93427'
PASS='PatientFictionalPassword-2026!'
APASS='AdminFictionalPassword-2026!!'
LOG=OUT/'results.json'
results=[]

def record(name,ok,detail=''):
 r={'test':name,'pass':bool(ok),'detail':str(detail)[:270]}
 results.append(r);print(('PASS' if ok else 'FAIL'),name,detail,flush=True)
 if not ok:raise AssertionError(name+' '+str(detail))

def req(client,method,url,**kwargs):
 if method not in ('GET','HEAD'):
  hh=kwargs.pop('headers',{})
  kwargs['headers']={'Origin':BASE,**hh}
 return client.request(method,BASE+url,timeout=15,**kwargs)

def html_source():
 pub=ROOT/'public'
 raw=(pub/'index.html').read_text()
 mark='data:image/svg+xml;base64,'+base64.b64encode((pub/'assets'/'mark.svg').read_bytes()).decode()
 raw=raw.replace('/assets/mark.svg',mark)
 for fname in ('styles.css','motion.css','refinement.css','chat-premium.css','alignment.css','design-system-v2.css','homepage-refresh.css'):
  needle=f'<link rel="stylesheet" href="/{fname}">'
  assert needle in raw,f'missing linked CSS {fname}'
  raw=raw.replace(needle,'<style>'+ (pub/fname).read_text()+'</style>')
 raw=raw.replace('<script defer src="/app.js"></script>','')
 prefix='''<script>
 window.fetch=async function(url,opts={}){
   const h=opts.headers||{};
   const body=(typeof opts.body==='string')?opts.body:null;
   const r=await window.qaBridge({path:String(url),method:opts.method||'GET',headers:h,body});
   return new Response(r.text,{status:r.status,headers:{'content-type':'application/json'}});
 }
 </script>'''
 script='<script>'+ (pub/'app.js').read_text().replace('/assets/mark.svg',mark)+'</script>'
 return raw.replace('</body>',prefix+script+'</body>')

def bridge(client):
 def handler(arg):
  path=arg.get('path','')
  if not path.startswith('/api/'):
   return {'status':400,'text':json.dumps({'error':'Only same-origin project API calls allowed'})}
  try:
   headers=dict(arg.get('headers') or {})
   if arg['method'] not in ('GET','HEAD'):headers['Origin']=BASE
   r=client.request(arg.get('method','GET'),BASE+path,headers=headers,content=arg.get('body'),timeout=17)
   return {'status':r.status_code,'text':r.text}
  except Exception as e:
   return {'status':503,'text':json.dumps({'error':'Local bridge unavailable'})}
 return handler

html=html_source()
env=os.environ.copy()
env.update({'PORT':str(PORT),'AVENSHORE_TEST_DATA':str(DIR),'AVENSHORE_ADMIN_SETUP_TOKEN':SETUP})
server_log=open(OUT/'server.log','w')
server=subprocess.Popen(['node','--no-warnings','--experimental-loader','./tests/local/loader.mjs','./tests/local/real-worker-server.mjs'],cwd=ROOT,env=env,stdout=server_log,stderr=subprocess.STDOUT)
try:
 for _ in range(50):
  try:
   if httpx.get(BASE+'/api/status',timeout=1).status_code==200:break
  except Exception:pass
  time.sleep(.15)
 else:raise RuntimeError('Local original Worker did not start')
 print('Original Worker backend ready (SQLite on disk)',flush=True)
 base_client=httpx.Client()
 r=req(base_client,'POST','/api/setup/admin',headers={'x-admin-setup-token':SETUP},json={'name':'Test Administrator','email':'admin.qa@example.test','password':APASS})
 record('Single admin created in SQLite',r.status_code==201,r.status_code)
 users=[]
 for name,short in [('Mara Ellis','mara'),('Noel Carter','noel')]:
  email=f'{short}-{uuid.uuid4().hex[:9]}@example.test'
  client=httpx.Client()
  rr=req(client,'POST','/api/auth/register',json={'name':name,'email':email,'password':PASS})
  record('Patient registration '+name,rr.status_code==201,rr.status_code)
  conv=req(client,'GET','/api/conversations').json()['conversations'][0]['id']
  users.append({'name':name,'email':email,'client':client,'conv':conv})
 mara,noel=users
 record('Distinct conversations',mara['conv']!=noel['conv'])
 record('Patient isolation',req(noel['client'],'GET',f"/api/conversations/{mara['conv']}/messages").status_code==404)
 record('Cross-origin POST blocked',req(mara['client'],'POST',f"/api/conversations/{mara['conv']}/messages",headers={'Origin':'https://other.invalid'},json={'content':'Blocked'}).status_code==403)
 record('Wrong password blocked',req(base_client,'POST','/api/auth/login',json={'email':mara['email'],'password':'IncorrectPassword'}).status_code==401)
 # Seed real message for populated administrator inbox.
 seed='Good morning. I have a question about my care plan.'
 record('Persist original API message',req(mara['client'],'POST',f"/api/conversations/{mara['conv']}/messages",json={'content':seed}).status_code==201)
 # Test a real private image: disk-backed R2 compatible attachment store.
 imagefile=OUT/'fictional-photo.png'
 im=Image.new('RGB',(600,320),'#E8F4EE');p=ImageDraw.Draw(im)
 p.rounded_rectangle((60,43,538,281),radius=24,fill='#FFFFFF',outline='#A0CBB6',width=4)
 p.text((92,104),'FICTIONAL TEST FILE',fill='#1A6455')
 p.text((92,153),'No patient information',fill='#315F57')
 im.save(imagefile)
 rr=req(mara['client'],'POST',f"/api/conversations/{mara['conv']}/attachments",headers={'content-type':'image/png'},content=imagefile.read_bytes())
 record('Private image saved',rr.status_code==201,rr.status_code)
 attachment_id=rr.json().get('id') if rr.status_code==201 else None
 record('Patient photo retrieval',req(mara['client'],'GET',f'/api/attachments/{attachment_id}').status_code==200)
 record('Other patient photo denied',req(noel['client'],'GET',f'/api/attachments/{attachment_id}').status_code==404)

 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  contexts=[];errors=[]
  def page_actor(name,width,height):
   client=httpx.Client()
   ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,is_mobile=width<760,has_touch=width<760)
   contexts.append(ctx);page=ctx.new_page();page.set_default_timeout(10000)
   page.on('pageerror',lambda error,n=name:errors.append((n,str(error))))
   page.expose_function('qaBridge',bridge(client))
   page.set_content(html,wait_until='domcontentloaded',timeout=20000)
   page.wait_for_selector('body.booted',timeout=16000)
   page.wait_for_selector('#boot-screen',state='detached',timeout=10000)
   return page,client
  def login(page,email,password,role):
   page.locator('.public-header [data-view="login"]').first.click()
   page.locator('input[name="email"]').fill(email)
   page.locator('input[name="password"]').fill(password)
   page.locator('#authForm [type="submit"]').click()
   page.wait_for_selector('.admin-grid' if role=='admin' else '.home-greeting',timeout=20000)
   return True
  def shot(page,name):
   page.locator('.toast').evaluate_all('(els)=>els.forEach(e=>e.remove())')
   page.screenshot(path=str(OUT/name),full_page=False,animations='disabled',timeout=15000)
   metrics=page.evaluate('''() => ({viewport:innerWidth,scroll:document.documentElement.scrollWidth})''')
   record('Viewport without overflow '+name,metrics['scroll']<=metrics['viewport']+1,metrics)

  admin,a_client=page_actor('admin',1440,900)
  login(admin,'admin.qa@example.test',APASS,'admin')
  record('Actual UI admin sign-in', admin.evaluate("S.actor?.role==='admin'"))
  patient,p_client=page_actor('Mara',390,844)
  login(patient,mara['email'],PASS,'patient')
  record('Actual UI patient sign-in', 'Mara' in patient.locator('.home-greeting').inner_text())
  expected=['Home','Get care','Health info','Messages','Account']
  labels=patient.locator('.bottom-nav button span').all_inner_texts()
  record('Five-tab patient navigation aligns with requirements',labels==expected,labels)
  record('Branded header and care entry present',patient.locator('.topbar-brand img').count()==1 and patient.locator('.topbar .header-care-cta').count()==1)
  record('Patient starts at top after login',patient.evaluate('window.scrollY')==0,patient.evaluate('window.scrollY'))
  shot(patient,'patient-home-390-real-db.png')
  desktop_patient,desktop_client=page_actor('Mara desktop',1440,900)
  login(desktop_patient,mara['email'],PASS,'patient')
  record('Desktop patient sidebar has five destinations',desktop_patient.locator('.sidebar .nav-button').count()==5)
  shot(desktop_patient,'patient-home-1440-real-db.png')
  patient.locator('.header-care-cta').click()
  record('Get-care destination offers chat and voice',patient.locator('.care-hub-option').count()==2)
  shot(patient,'patient-get-care-390-real-db.png')
  patient.locator('.bottom-nav [data-view="health"]').click()
  record('Health-info tab accessible',patient.locator('h1').first.inner_text().startswith('Health information'))
  shot(patient,'patient-health-390-real-db.png')
  patient.locator('.bottom-nav [data-view="messages"]').click()
  patient.wait_for_selector('#messageForm')
  # Admin enters original live inbox and selects actual patient conversation.
  admin.locator('.sidebar [data-view="messages"]').click()
  admin.wait_for_selector('.conversation-row')
  admin.locator('.conversation-row',has_text='Mara Ellis').first.click()
  admin.wait_for_selector('.bubble-content')
  record('Admin sees persisted original patient message', seed in admin.locator('#messageStream').inner_text())
  # Real local backend is contacted from the browser JS via Playwright binding.
  msg='I am sending this from the actual browser UI through the Worker backend.'
  patient.locator('#messageText').fill(msg)
  patient.locator('#messageForm button[type="submit"]').click()
  patient.wait_for_function('''() => document.querySelector('#messageStream')?.innerText.includes('actual browser UI')''',timeout=15000)
  admin.evaluate('refreshConversations()')
  admin.wait_for_function('''() => document.querySelector('#messageStream')?.innerText.includes('actual browser UI')''',timeout=15000)
  record('Browser patient to admin through actual Worker API',True)
  reply='Thank you Mara. We have received your message.'
  admin.locator('#messageText').fill(reply)
  admin.locator('#messageForm button[type="submit"]').click()
  admin.wait_for_function('''() => document.querySelector('#messageStream')?.innerText.includes('received your message')''',timeout=15000)
  patient.evaluate('refreshConversations()')
  patient.wait_for_function('''() => document.querySelector('#messageStream')?.innerText.includes('received your message')''',timeout=15000)
  record('Browser administrator reply reaches patient',True)
  # The img src is retrieved and checked through real backend. When rendering from
  # about:blank, replace inaccessible local network img URL with bytes just fetched.
  b=req(mara['client'],'GET',f'/api/attachments/{attachment_id}').content
  imgdata='data:image/png;base64,'+base64.b64encode(b).decode()
  for page in (admin,patient):
   page.evaluate('(src)=>document.querySelectorAll(".chat-attachment img").forEach(img=>img.src=src)',imgdata)
  shot(patient,'patient-chat-390-real-db.png')
  shot(admin,'admin-chat-1440-real-db.png')

  noel_page,n_client=page_actor('Noel',390,844)
  login(noel_page,noel['email'],PASS,'patient')
  noel_page.locator('.bottom-nav [data-view="messages"]').click()
  record('Another patient cannot read Mara conversation in browser',msg not in noel_page.locator('#messageStream').inner_text())

  # WebSocket event from the live Durable Object, consumed by an independent client.
  cookie=a_client.cookies.get('av_session')
  sock=websocket.create_connection(f'ws://127.0.0.1:{PORT}/api/events',header=[f'Cookie: av_session={cookie}'],timeout=6,origin=BASE)
  firstmsg=json.loads(sock.recv())
  record('Live authenticated WebSocket handshake',firstmsg.get('type')=='connected')
  rr=req(mara['client'],'POST',f"/api/conversations/{mara['conv']}/messages",json={'content':'Server side event to authenticated admin WebSocket'})
  ev=json.loads(sock.recv())
  record('Actual Worker event delivered to admin over WebSocket',rr.status_code==201 and ev.get('type')=='message',ev.get('type'))
  sock.close()

  # Call concurrency and queue through the browser; user A must precede user B.
  patient.locator('.bottom-nav [data-view="care"]').click()
  patient.locator('.care-hub-option[data-view="calls"]').click()
  patient.locator('[data-action="request-call"]').click()
  patient.wait_for_function('''() => document.querySelector('.calling-card')?.innerText.includes('Your request is next')''',timeout=15000)
  noel_page.locator('.bottom-nav [data-view="care"]').click()
  noel_page.locator('.care-hub-option[data-view="calls"]').click()
  noel_page.locator('[data-action="request-call"]').click()
  noel_page.wait_for_function('''() => document.querySelector('.queue')?.innerText.includes('1')''',timeout=15000)
  record('Single-call queue accepts second patient',True)
  shot(noel_page,'patient-waiting-390-real-db.png')
  admin.locator('.sidebar [data-view="calls"]').click()
  admin.wait_for_selector('[data-action="accept-call"]')
  shot(admin,'admin-incoming-call-1440-real-db.png')
  record('Admin is allowed to accept only one active call',req(a_client,'POST','/api/calls/accept').status_code==200)
  record('Duplicate accept denied',req(a_client,'POST','/api/calls/accept').status_code==409)
  record('Call completed and second request promoted',req(a_client,'POST','/api/calls/end').status_code==200)
  queued=req(noel['client'],'GET','/api/calls').json()
  record('Second patient promoted',queued.get('active',{}).get('patientId') is not None)
  noel_page.evaluate('refreshCall()')
  shot(noel_page,'patient-promoted-390-real-db.png')
  record('No uncaught JavaScript errors',len(errors)==0,errors)
  # Browser 320px narrow: same original source and live data, no viewport overflow.
  narrow,narrowclient=page_actor('Mara narrow',320,760)
  login(narrow,mara['email'],PASS,'patient')
  shot(narrow,'patient-home-320-real-db.png')
  for c in contexts:c.close()
  browser.close()
 conn=sqlite3.connect(DIR/'clinic.sqlite')
 cnt={t:conn.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in ('users','sessions','conversations','messages','attachments')}
 conn.close()
 record('Data truly persisted in on-disk SQLite',cnt['users']==3 and cnt['messages']>=5 and cnt['attachments']>=1,cnt)
finally:
 server.terminate()
 try:server.wait(timeout=4)
 except Exception:server.kill()
 server_log.close()
 result={'scope':'Original Cloudflare Worker code executed via Node-compatible local HTTP/WebSocket server, SQLite on disk, local private object storage, real authenticated browser UI fetch via bridge because browser direct navigation is restricted.',
         'disclaimer':'Browser page is about:blank with original app HTML/CSS/JS and backend fetch bridged to localhost. No in-browser native WebSocket or microphone-to-microphone audio test; WebSocket tested separately with authenticated client. Not a Cloudflare production test.',
         'remaining':['Cloudflare D1/R2/Durable Object deploy test','Native browser microphone-to-microphone WebRTC + TURN tests','Penetration, privacy/compliance, real device and clinician acceptance tests'],
         'results':results,'summary':{'passed':sum(r['pass'] for r in results),'failed':sum(not r['pass'] for r in results)}}
 LOG.write_text(json.dumps(result,indent=2))
 print('SUMMARY',result['summary'],' REPORT',LOG,flush=True)
