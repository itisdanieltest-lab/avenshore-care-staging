import test from 'node:test';
import assert from 'node:assert/strict';
import {register} from 'node:module';
import {callIceConfig} from '../worker/call-ice.js';
register('./local/loader.mjs',import.meta.url);
const {RealtimeHub}=await import('../worker/realtime.js');
function fixture(){let state,alarm;const sockets=[];const ctx={storage:{get:async()=>structuredClone(state),put:async(k,v)=>state=structuredClone(v),setAlarm:async t=>alarm=t,deleteAlarm:async()=>alarm=null},getWebSockets:()=>sockets,blockConcurrencyWhile:fn=>fn()};const hub=new RealtimeHub(ctx,{});const call=async(role,id,action,body={})=>hub.fetch(new Request('https://internal/calls'+(action?'/'+action:''),{method:action?'POST':'GET',headers:{'x-actor-id':id,'x-actor-role':role,'content-type':'application/json'},...(action?{body:JSON.stringify(body)}:{})}));return{hub,call,sockets,state:()=>state,alarm:()=>alarm,setState:s=>state=s};}
test('inbound calls enforce one active line, queue fairness, privacy, recipient acceptance and stale call protection',async()=>{
 const f=fixture();let r=await(await f.call('patient','p1','request',{patientName:'Fictional One'})).json();const first=r.active.callId;assert.ok(f.alarm());
 await f.call('patient','p2','request',{patientName:'Fictional Two'});await f.call('patient','p2','request');assert.equal(f.state().queue.length,1);
 const privateView=await(await f.call('patient','p2')).json();assert.equal(privateView.active,null);assert.equal(privateView.position,1);assert.equal(privateView.queue,undefined);
 assert.equal((await f.call('admin','staff','dial',{patientId:'p3'})).status,409);assert.equal((await f.call('patient','p1','accept',{callId:first})).status,403);
 assert.equal((await f.call('admin','staff','accept',{callId:first})).status,200);await f.call('patient','p1','ready',{callId:first});await f.call('admin','staff','ready',{callId:first});assert.deepEqual(f.state().active.ready,{patient:true,admin:true});
 await f.call('admin','staff','end',{callId:first});assert.equal(f.state().active.patientId,'p2');assert.equal(f.state().active.state,'ringing');assert.equal((await f.call('admin','staff','end',{callId:first})).status,409);
});
test('admin outbound calls require patient acceptance; alarms expire ringing and disconnected calls',async()=>{
 const f=fixture();assert.equal((await f.call('patient','p1','dial',{patientId:'p2'})).status,403);let r=await(await f.call('admin','staff','dial',{patientId:'p1',patientName:'Fictional One'})).json();const id=r.active.callId;
 assert.equal((await f.call('admin','staff','accept',{callId:id})).status,403);assert.equal((await f.call('patient','p2','accept',{callId:id})).status,403);assert.equal((await f.call('patient','p1','accept',{callId:id})).status,200);
 let st=f.state();st.active.acceptedAt=Date.now()-91000;f.setState(st);await f.hub.alarm();assert.equal(f.state().active,null);assert.equal(f.state().lastCall.reason,'disconnected');
 await f.call('patient','p2','request');st=f.state();st.active.ringExpiresAt=Date.now()-1;f.setState(st);await f.hub.alarm();assert.equal(f.state().lastCall.reason,'unanswered');assert.equal(f.alarm(),null);
});
test('signaling requires ready participants and never reaches an unrelated patient',async()=>{
 const f=fixture();const id=(await(await f.call('patient','p1','request')).json()).active.callId;await f.call('admin','staff','accept',{callId:id});const output=[];
 function socket(role,id){return{deserializeAttachment:()=>({role,id}),send:m=>output.push({role,id,data:JSON.parse(m)})};}const p1=socket('patient','p1');f.sockets.push(p1,socket('patient','p2'),socket('admin','staff'));const offer=JSON.stringify({type:'signal',kind:'offer',data:{type:'offer',sdp:'fictional'},callId:id});await f.hub.webSocketMessage(p1,offer);assert.equal(output.length,0);
 await f.call('patient','p1','ready',{callId:id});await f.call('admin','staff','ready',{callId:id});output.length=0;await f.hub.webSocketMessage(p1,offer);assert.equal(output.length,1);assert.equal(output[0].id,'staff');
});
test('TURN credentials are short-lived, filter blocked port and do not return the API token',async()=>{
 assert.equal((await callIceConfig({})).relayConfigured,false);let request;
 const result=await callIceConfig({CF_TURN_KEY_ID:'key',CF_TURN_API_TOKEN:'private-secret'},async(url,options)=>{request={url,options};return Response.json({iceServers:[{urls:['turn:relay.example:3478?transport=udp','turn:relay.example:53?transport=udp'],username:'temporary',credential:'temporary-credential'}]});});
 assert.equal(JSON.parse(request.options.body).ttl,3600);assert.equal(result.relayConfigured,true);assert.equal(result.iceServers[0].urls.length,1);assert.ok(!JSON.stringify(result).includes('private-secret'));
 await assert.rejects(()=>callIceConfig({CF_TURN_KEY_ID:'key',CF_TURN_API_TOKEN:'secret'},async()=>new Response('upstream secret',{status:500})),/temporarily unavailable/);
});
