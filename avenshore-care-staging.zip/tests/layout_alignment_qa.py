"""Actual Avenshore source, screenshot and geometry check (fixture auth, not live backend)."""
from pathlib import Path
import base64,json
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1]/'public'
O=Path(__file__).resolve().parents[1]/'docs'/'qa'/'layout-audit';O.mkdir(parents=True,exist_ok=True)
html=(P/'index.html').read_text();m='data:image/svg+xml;base64,'+base64.b64encode((P/'assets'/'mark.svg').read_bytes()).decode();html=html.replace('/assets/mark.svg',m)
for f in ('styles.css','motion.css','refinement.css','chat-premium.css','alignment.css','homepage-refresh.css'):
 html=html.replace(f'<link rel="stylesheet" href="/{f}">','<style>'+ (P/f).read_text()+'</style>')
html=html.replace('<script defer src="/app.js"></script>','')
script=(P/'app.js').read_text().replace('/assets/mark.svg',m)
pre='''<script>
window.fetch=async function(url){const path=String(url).split('/api/')[1]?.split('?')[0];const data={me:{actor:{id:'p1',role:'patient',name:'Mara Example',email:'mara@example.test'},turnstileSiteKey:null},conversations:{conversations:[]},calls:{active:null,queue:[],position:null,busy:false},status:{status:'ok'}};return new Response(JSON.stringify(data[path]||{}),{status:200,headers:{'content-type':'application/json'}})}
</script>'''
html=html.replace('</body>',pre+'<script>'+script+'</script></body>')
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in ((390,844),(1440,900),(320,720)):
  ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,is_mobile=width<760)
  pg=ctx.new_page();errs=[];pg.on('pageerror',lambda err:errs.append(str(err)))
  pg.set_content(html,wait_until='domcontentloaded',timeout=13000)
  pg.wait_for_selector('body.booted',timeout=13000)
  pg.wait_for_selector('#boot-screen',state='detached',timeout=10000)
  pg.screenshot(path=str(O/f'patient-home-{width}.png'),full_page=False,timeout=10000)
  geom=pg.evaluate('''() => ({document:document.documentElement.scrollWidth,viewport:window.innerWidth,grid:getComputedStyle(document.querySelector('.home-content-grid')).gridTemplateColumns,sections:[...document.querySelectorAll('.home-content-grid>section')].map(el=>({left:Math.round(el.getBoundingClientRect().left),top:Math.round(el.getBoundingClientRect().top),width:Math.round(el.getBoundingClientRect().width)})),headings:[...document.querySelectorAll('.home-content-grid h2')].map(el=>el.textContent)})''')
  print(width,json.dumps(geom),'errors',errs,flush=True)
  assert geom['document']<=geom['viewport']+1
  assert not errs
  if width==1440:assert abs(geom['sections'][0]['top']-geom['sections'][1]['top'])<=2
  else:assert geom['sections'][0]['top']<geom['sections'][1]['top']
  ctx.close()
 browser.close()
