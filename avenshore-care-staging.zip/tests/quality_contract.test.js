import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { normalizePatientContact, PASSWORD_HASH_ITERATIONS } from '../worker/validation.js';
const root=resolve(import.meta.dirname,'..');
const source=rel=>readFileSync(resolve(root,rel),'utf8');
function contrast(foreground,background){
 const lum=h=>{let rgb=h.slice(1).match(/.{2}/g).map(v=>parseInt(v,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722;};
 const [a,b]=[lum(foreground),lum(background)].sort((x,y)=>y-x);return (a+.05)/(b+.05);
}
test('all local CSS and JS assets referenced by the real webpage exist',()=>{
 const html=source('public/index.html');
 const links=[...html.matchAll(/(?:href|src)="\/(.*?)"/g)].map(match=>match[1]);
 for(const link of links)assert.ok(existsSync(resolve(root,'public',link)),`Missing local asset: ${link}`);
 assert.ok(links.includes('chat-premium.css'),'Chat design system stylesheet must be loaded');
});
test('conversations use a keyboard accessible photo attachment trigger',()=>{
 const js=source('public/app.js');
 assert.match(js,/data-action="pick-image" aria-label="Attach an image"/);
 assert.match(js,/if\(a==='pick-image'\)/);
});
test('inbox avoids redrawing unchanged responses and ignores stale thread replies',()=>{
 const js=source('public/app.js');
 assert.match(js,/if\(S\.selected!==conversationId\)return/);
 assert.match(js,/JSON\.stringify\(incoming\)!==JSON\.stringify\(S\.messages\)/);
 assert.match(js,/S\.drafts\[previousForm\.dataset\.conversationId\]/);
});
test('chat key text colors exceed WCAG AA 4.5:1 in light UI',()=>{
 for(const [fg,bg] of [
  ['#173b36','#ffffff'],['#43695f','#ffffff'],['#4d6e61','#f7faf6'],
  ['#43685b','#e4f1e8'],['#526b63','#ffffff'],['#42685d','#f3f8f4'],
  ['#4e6c62','#ffffff']
 ])assert.ok(contrast(fg,bg)>=4.5,`${fg} on ${bg} was ${contrast(fg,bg).toFixed(2)}:1`);
});
test('patient and visitor conversations include latest-message preview query',()=>{
 const api=source('worker/index.js');
 const sql=api.slice(api.indexOf("else rows=await env.DB.prepare(`SELECT c.*"));
 assert.match(sql,/AS last_message/);
});
test('patient sign-in accepts normalized email or phone contacts',()=>{
 assert.equal(normalizePatientContact('  Patient@Example.invalid '),'patient@example.invalid');
 assert.equal(normalizePatientContact('+234 (803) 123-4567'),'+2348031234567');
 assert.equal(normalizePatientContact('0803 123 4567'),'08031234567');
 assert.equal(normalizePatientContact('not a contact'),null);
});
test('signup form explains no code is sent and staging uses Turnstile test keys',()=>{
 const app=source('public/app.js'),config=source('wrangler.jsonc');
 assert.match(app,/Email or phone number/);
 assert.match(app,/No verification code is sent during signup/);
 assert.match(config,/"TURNSTILE_SITE_KEY": "1x00000000000000000000AA"/);
 assert.match(config,/"TURNSTILE_SECRET": "1x0000000000000000000000000000000AA"/);
});
test('public site clearly states free care and explains the available services',()=>{
 const app=source('public/app.js'),html=source('public/index.html');
 for(const phrase of ['FREE HEALTHCARE FOR OLDER ADULTS','Create your free account','Private messages with your care team','In-app voice calls','Health information in one place','consultations, tests, prescriptions, referrals, and other clinic services'])assert.ok(app.includes(phrase),`Missing clear service detail: ${phrase}`);
 assert.match(app,/feature-link[^`]*data-view="login"[^`]*Sign in to message the care team/s);
 assert.match(html,/Free healthcare for older adults, including diabetes and blood pressure support, consultations, tests, prescriptions, referrals/);
});
test('free-care conditions and covered services are visible at sign-in and after patient login',()=>{
 const app=source('public/app.js');
 assert.match(app,/freeCareSummary\('login'\)/);
 assert.match(app,/freeCareSummary\('patient'\)/);
 for(const phrase of ['Diabetes','High blood pressure','Arthritis and joint pain','Clinic consultations','Tests and screenings','Prescriptions','Referrals','Other Avenshore clinic services'])assert.ok(app.includes(phrase),`Missing free-care detail: ${phrase}`);
 assert.match(app,/aria-labelledby="\$\{context\}-free-care-title"/);
 assert.match(source('public/homepage-refresh.css'),/\.patient-free-care/);
});
test('homepage refresh adds the requested conditions and real responsive stock photos',()=>{
 const app=source('public/app.js'),html=source('public/index.html'),css=source('public/homepage-refresh.css');
 for(const phrase of ['Diabetes','High blood pressure','Arthritis and joint pain','Tests and screenings','Prescription support','Referrals and next steps','Call 911'])assert.ok(app.includes(phrase),`Missing homepage content: ${phrase}`);
 for(const asset of ['elderly-man-portrait.webp','senior-wheelchair-support.webp','us-ambulance-safety.webp'])assert.ok(existsSync(resolve(root,`public/assets/homepage/${asset}`)),`Missing photo asset: ${asset}`);
 assert.match(app,/data-view="login" aria-label="Sign in to access private messages"/);
 assert.match(css,/@media\(max-width:760px\)/);
 assert.match(html,/<link rel="stylesheet" href="\/homepage-refresh.css">/);
});
test('a visitor can return from website support to home and stay there after refresh',()=>{
 const app=source('public/app.js');
 assert.match(app,/const VIEW_STORAGE_KEY='avenshore:last-view:v1'/);
 assert.match(app,/sessionStorage\.setItem\(VIEW_STORAGE_KEY,S\.view\)/);
 assert.match(app,/savedView=sessionStorage\.getItem\(VIEW_STORAGE_KEY\)/);
 assert.match(app,/restoreView\(S\.actor,savedView,S\.adminSetupAvailable,!!S\.adminSetupToken\)/);
 assert.match(app,/actor\?\.role==='visitor'\?\['welcome','help','login','register','guest-verify','messages'\]/);
});
test('one-time administrator setup stays hidden until the secret exists and no admin is present',()=>{
 const app=source('public/app.js'),worker=source('worker/index.js');
 assert.match(worker,/adminSetupAvailable:hasSetupSecret&&!existingAdmin/);
 assert.match(app,/id="adminSetupForm"/);
 assert.match(app,/location\.hash\.match\(\/\^#admin-setup=\(\[A-Za-z0-9_-\]\{32,256\}\)\$\/\)/);
 assert.match(app,/history\.replaceState\(null,'',location\.pathname\+location\.search\)/);
 assert.match(app,/'x-admin-setup-token':S\.adminSetupToken/);
 assert.match(app,/function screen\(\)\{if\(S\.view==='admin-setup'&&S\.adminSetupAvailable&&S\.adminSetupToken\)return adminSetupPage\(\)/);
 assert.match(app,/S\.view=S\.adminSetupToken&&S\.adminSetupAvailable\?'admin-setup'/);
 assert.doesNotMatch(app,/name="setupToken"/);
 assert.match(app,/S\.adminSetupToken=''\;S\.view='login'/);
 assert.match(app,/minlength="16" maxlength="128" placeholder="At least 16 characters"/);
});
test('patient contact form does not show example values in the field',()=>{
 const app=source('public/app.js');
 assert.match(app,/<label class="form-field">Email or phone number<input name="email" type="text" inputmode="text" autocomplete="username" required maxlength="254" aria-describedby="contactHint">/);
});
test('staging deploy applies pending D1 migrations before publishing',()=>{
 const pkg=JSON.parse(source('package.json'));
 assert.match(pkg.scripts['deploy:staging'],/db:staging:migrate.*wrangler deploy --env staging/);
});
test('password hash stays within Cloudflare Workers PBKDF2 iteration limit',()=>{
 assert.equal(PASSWORD_HASH_ITERATIONS,100000);
 assert.match(source('worker/index.js'),/iterations:PASSWORD_HASH_ITERATIONS/);
});
