import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname,'..');
const source=rel=>readFileSync(resolve(root,rel),'utf8');
function contrast(foreground,background){
 const lum=h=>{let rgb=h.slice(1).match(/.{2}/g).map(v=>parseInt(v,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722;};
 const [a,b]=[lum(foreground),lum(background)].sort((x,y)=>y-x);return (a+.05)/(b+.05);
}
test('all local CSS and JS assets referenced by the real webpage exist',()=>{
 const html=source('public/index.html');
 const links=[...html.matchAll(/(?:href|src)="\/(.*?)"/g)].map(match=>match[1]);
 for(const link of links)assert.ok(existsSync(resolve(root,'public',link)),`Missing local asset: ${link}`);
 assert.ok(links.includes('chat-premium.css'),'Chat design system stylesheet must be loaded');
});
test('conversations use a keyboard accessible photo attachment trigger',()=>{
 const js=source('public/app.js');
 assert.match(js,/data-action="pick-image" aria-label="Attach an image"/);
 assert.match(js,/if\(a==='pick-image'\)/);
});
test('inbox avoids redrawing unchanged responses and ignores stale thread replies',()=>{
 const js=source('public/app.js');
 assert.match(js,/if\(S\.selected!==conversationId\)return/);
 assert.match(js,/JSON\.stringify\(incoming\)!==JSON\.stringify\(S\.messages\)/);
 assert.match(js,/S\.drafts\[previousForm\.dataset\.conversationId\]/);
});
test('chat key text colors exceed WCAG AA 4.5:1 in light UI',()=>{
 for(const [fg,bg] of [
  ['#173b36','#ffffff'],['#43695f','#ffffff'],['#4d6e61','#f7faf6'],
  ['#43685b','#e4f1e8'],['#526b63','#ffffff'],['#42685d','#f3f8f4'],
  ['#4e6c62','#ffffff']
 ])assert.ok(contrast(fg,bg)>=4.5,`${fg} on ${bg} was ${contrast(fg,bg).toFixed(2)}:1`);
});
test('patient and visitor conversations include latest-message preview query',()=>{
 const api=source('worker/index.js');
 const sql=api.slice(api.indexOf("else rows=await env.DB.prepare(`SELECT c.*"));
 assert.match(sql,/AS last_message/);
});
