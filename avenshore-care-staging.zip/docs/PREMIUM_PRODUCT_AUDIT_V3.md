# Avenshore Care — V3 Product, Copy, and Real-Backend Audit

**Prepared 10 November 2026.** Status: locally tested staging candidate; **not certified for patient or public healthcare use**.

## Scope and methodology

The audit used: (1) the owner's original Teladoc signed-in mobile screenshots (Home, Programs, Messages), (2) publicly available Teladoc Adults and help information, (3) One Medical's published patient-app capabilities, (4) NHS digital service manual component/layout guidance, (5) W3C WCAG 2.2 form and target-size guidance, (6) direct source inspection, and (7) real Chromium sessions connected via a controlled bridge to the project's original Worker request handlers, persistent local SQLite and private test-file store.

**Scope limitation:** Source-level inspection and local integration tests cannot independently verify Teladoc's actual signed-in chat internals, Cloudflare security configuration, live WebRTC audio, healthcare regulatory compliance, or production readiness. The test patient and staff identities are fictional. No patient data was used.

## Benchmarks and lessons, not copied designs

| Reference | Official resource | What it validates | Avenshore response |
| --- | --- | --- | --- |
| Teladoc Health Adults | https://www.teladochealth.com/individuals/adults | Clear care offer, prominent entry actions, coherent brand colors | Keep Avenshore brand distinct, clearer header and care CTA, simple five-area signed-in navigation |
| Teladoc Help Center | https://www.teladochealth.com/start/faq | Explicit account, visit, support language and service boundaries | Differentiate website-access help from private care channels |
| Amazon One Medical | https://health.amazon.com/onemedical/help | Messaging, records, appointment and visit experiences are separate capabilities | Only expose services the clinic has actually approved and implemented |
| NHS component guidance | https://service-manual.nhs.uk/design-system/components/card | Cards group closely related actions, not every paragraph | Grid-based grouped care actions and concise, scannable labels |
| NHS layout guidance | https://service-manual.nhs.uk/design-system/styles/layout | Mobile-first reading order, sensible column widths | One-column mobile, deliberate desktop column system |
| W3C labels and instructions | https://www.w3.org/WAI/WCAG22/Understanding/labels-or-instructions | Inputs must be understandable without guesswork | Plain-language sign-in, message composer and support CTAs |

## Confirmed issues, changes, and retests

1. **Visitor live chat was buried under Help.** Added discoverable, same-origin website-support entry on welcome, login and registration screens. On mobile the floating entry is compact, reducing overlap with the homepage illustration.
2. **Starting guest chat on a phone did not immediately reveal the message composer.** The guest now opens the active conversation thread and the mobile layout fits header, thread and composer inside the viewport.
3. **A guest could see patient-only voice-call actions.** Removed voice-call controls for site-help conversations. The visitor doesn't see patient account navigation either.
4. **Clinical attachment control appeared in a nonclinical chat.** Removed it from both visitor and administrator site-help threads; Worker API now rejects attachments to site-help conversations (403). This is a hard server-side boundary, not a cosmetic hide.
5. **Staff messages used inaccurate sender labels.** A public-site visitor is identified as `Website visitor`, not `Patient`. Staff inbox heading is `Support inbox`, with patient and site-help filters.
6. **Redundant copy.** Reduced repeated welcome/home prompts, dropped the generic `Conversation history` divider, and removed duplicate 'chat started' toast that obstructed the composer.
7. **Production-facing developer notes.** Removed internal trademark-release notes from the public footer, but retained brand clearance, account recovery, and other unfinished requirements in internal release documentation. The patient account page uses clear support instructions instead of internal implementation wording.
8. **Desktop chat composer was below the first screen.** Adjusted conversation panel height for 900px desktop viewports so the message composer is visible without scrolling the whole page.
9. **Healthcare language and icon hierarchy.** Use meaningful labels, coherent icons, high-contrast teal actions and five patient destinations. Avoid unapproved 'Programs' functionality: health content/care options take that space until clinic services are real.

## Actual verification

Run the following within the extracted repository:

```sh
npm run check
python tests/public_support_v3_qa.py
python tests/bridged_real_backend_e2e.py
```

| Check suite | Result | What was exercised |
| --- | --- | --- |
| V3 website-help test | **24/24 passed** | Guest start, persistent message, actual Chromium admin login/reply, guest receipt, legal session-end, no site-help attachments, visit-to-sign-in/return, desktop/mobile checks |
| Registered patient/staff integration | **42/42 passed** | Patient registration, login, conversation isolation, stored photo permissions, admin reply, authenticated WebSocket event, one-call queue, browser flows and viewport checks |
| Node syntax + contract suite | **5/5 passed** | Linked assets, image-picker keyboard access, stale reply avoidance, sampled contrast, inbox previews |

The original Cloudflare Worker handlers were run through a Node-compatible local HTTP server with actual on-disk SQLite and test object storage. Browser UI loaded original HTML/CSS/JS and routed HTTP requests through isolated session bridges because localhost navigation is restricted in the test browser environment. **This is neither a Cloudflare-hosted staging result nor direct browser WebRTC-audio evidence.**

### QA visual artifacts

- `docs/qa/premium-audit-v3/public-home-390.png` — public homepage with visible small Help entry
- `docs/qa/premium-audit-v3/sign-in-390.png` — accessible sign-in and website-help route
- `docs/qa/premium-audit-v3/visitor-chat-replied-390.png` — real visitor/admin database-backed exchange, mobile
- `docs/qa/premium-audit-v3/admin-guest-support-1440.png` — staff reply from signed-in Chromium administrator session
- `docs/qa/real-integration/patient-chat-390-real-db.png` — registered patient chat with real local database
- `docs/qa/real-integration/admin-chat-1440-real-db.png` — staff care inbox with actual local backend test data
- `docs/qa/premium-audit-v3/results.json` and `docs/qa/real-integration/results.json` — machine-readable results

## Non-negotiable release blockers

- **Brand clearance:** confirm Avenshore Care business name, domain and trademark availability, and obtain customer approval. No legal availability finding is implied.
- **Account safety:** build and test email verification, safe password-reset and recovery, account deletion, staff authorization lifecycle and admin multifactor authentication before enrolling real patients.
- **Healthcare/privacy:** obtain professional review of privacy notice, clinical scope/consents, record retention/deletion, audit trails, staff identity and credentials, Nigeria NDPA/local medical requirements and emergency escalation.
- **Bot and abuse controls:** configure Turnstile and Cloudflare security layers, rate limits and monitoring. Public registration, login, and visitor-chat creation now fail closed with a service error unless both Turnstile keys are configured. The isolated local QA harness has a local-only bypass; never set `LOCAL_QA` in Cloudflare.
- **Cloudflare staging:** provision real D1, R2, Durable Object bindings, secrets and a staging domain in the client's Cloudflare account. Run migrations and native browser integration tests, including cross-device real-time events and disconnect/reconnect.
- **Voice calls:** WebRTC signaling and call queue are implemented, but actual encrypted microphone-to-microphone audio, TURN fallback, permission failures, dropped-call recovery, and two-network testing are still outstanding.
- **Accessible production:** conduct keyboard/screen-reader, 200%/400% zoom, touch target, color contrast, error handling, low-bandwidth and older-adult usability evaluations.
- **Clinical readiness:** never promise 24/7 staffed medical consultation unless staffing and escalation are contractually and operationally confirmed.

**Recommended next step for ChatGPT Work:** deploy this updated V3 to an isolated Cloudflare staging environment with only synthetic records, capture browser videos/screenshots of both independently authenticated sides, repair functional/security gaps, and obtain owner sign-off before any real patient enrollment.
