# Messaging and live call release — 11 November 2026

## Implemented in this update

| Area | Correction |
|---|---|
| Text sending | Visible sending state, failed/uncertain state, manual Retry and Discard. 15-second request timeout. Server client-message IDs prevent duplicate text on retry. Limit 3,000 characters; bounded pending queue. |
| Drafts | Per-account, per-conversation drafts and pending text survive refresh in this browser tab through session storage. Logout clears this account's saved drafts. Text typed after a send starts is preserved. |
| Editing | Author-only inline editing; server authorization, optimistic conflict check, Edited label, earlier wording retained in an internal care-record audit table. |
| Copy | Copy text button, with manual-selection guidance if clipboard permission is unavailable. |
| Replies | Reply preview, cancel reply, quoted original text; server rejects references to other conversations. |
| History | Load earlier messages beyond 100; timestamp and ID cursor prevents gaps when timestamps tie. |
| Search | Search text in loaded messages. Load earlier history to include older messages. Inbox search/filter remains available. |
| Read status | Sent means server accepted; Read means the other participant opened the visible thread at its bottom. No invented Delivered status. Unread counts in the inbox. |
| Attachments | Private image access remains; added same-ID upload retry and 20-second timeout with Retry/Discard. Maximum 5 MB. Attachment bytes stay in memory for retry, not browser storage. |
| Voice messages | Record, Stop, automatic stop after two minutes, playback preview, Send and Discard; microphone stopped on completion/logout. WebM/Opus, Ogg/Opus or MP4 selected according to browser support. Private authenticated playback. Storage errors leave retryable attachment state. |
| Patient calls | Request, one active line, FIFO waiting queue, cancel queued request, connect audio, mute/unmute, reconnect and end. |
| Admin calls | Choose an existing patient, place outbound call, patient Accept/Decline; inbound admin Accept/Decline. Cannot bypass a waiting queue with a new outbound call. |
| Call signaling | Readiness handshake, fixed patient offerer, current call ID validation, early ICE buffering and flush, reconnect signaling and socket-open offer resend. Only the two authenticated participants receive signaling. |
| Call lifecycle | Incoming/current call banner across signed-in pages, polling fallback, 90-second unanswered and unconnected expiry, 60-second lost-heartbeat expiry and queue promotion. Stale controls cannot end a replacement call. |
| Relay | Server-generated one-hour TURN credentials; refresh during long calls; long-term relay API token never returned to the browser. STUN fallback clearly reports missing relay. |

## Required service connections

### Private attachment storage (R2)

R2 is object storage; D1 remains the database for accounts and message metadata. No billing action has been performed. Voice recording/UI and upload/playback API are implemented, but persistent images and voice messages cannot be sent until the `UPLOADS` R2 binding is connected to the **deployed staging Worker**.

When the bucket exists, add the following to `env.staging` in `wrangler.jsonc`, with the actual bucket name, before the next GitHub deployment:

```json
"r2_buckets": [{"binding":"UPLOADS","bucket_name":"ACTUAL_PRIVATE_BUCKET_NAME"}]
```

Use a private bucket; do not enable public bucket URLs. Runtime errors explain the missing connection while text messaging remains available. Do not add a non-existent bucket to the active deployment configuration, since that would break deployments.

### Live call relay

Calls do not require R2. For reliable connectivity across mobile networks and restrictive Wi-Fi, create a Cloudflare Realtime TURN key and set these **runtime** secrets for this Worker:

- `CF_TURN_KEY_ID`
- `CF_TURN_API_TOKEN`

These are separate from the already-working `ADMIN_SETUP_TOKEN`. Do not rotate or recreate the administrator setup secret for calls. Do not place relay secrets only in Build variables, commit them, or send them in chat.

Credential endpoint used: `https://rtc.live.cloudflare.com/v1/turn/keys/{key_id}/credentials/generate-ice-servers`, TTL 3,600 seconds. Browser-incompatible port 53 URLs are excluded. Official reference: https://developers.cloudflare.com/realtime/turn/generate-credentials/

Without this relay connection, direct browser-to-browser audio may work, but reliable mobile-network calling is not established. Both participants must keep the website open and grant microphone permission. Browser audio controls offer Play if automatic playback is blocked.

## Verification and limits

47 automated checks passed before packaging: existing admin routing/auth/logout/photo/design checks, real Worker/SQLite messaging tests, Durable Object queue/auth/timeout/signaling tests, TURN response filtering, frontend draft recovery/retry preservation and early ICE handling. Private audio tests use a mock object store, not the user's R2 bucket.

The shared browser could not reach the local preview (`ERR_CONNECTION_REFUSED`). Prior automated requests to live staging were blocked by Cloudflare 1010; no bot controls were bypassed. Two physical devices, microphone permission, real R2 playback, real TURN credentials and mobile-to-Wi-Fi audio are still required for end-to-end acceptance. This is implemented staging code, not a claim of verified clinical production readiness.

## Remaining messaging gaps and deliberate limits

- No background push notifications or native incoming-call ringing when the browser is closed. In-page banner and polling require an open page.
- No group chat, forwarding, reactions, typing/online indicators, pinning, starred messages, or cross-device draft synchronization.
- No delete-for-everyone: care messages and original edited wording remain in the care record. Discard removes an unsent local attempt only; if a timed-out request already reached the server, its accepted message remains.
- Search covers loaded history; no full server search index yet.
- No delivery acknowledgment distinct from Sent and Read. Read status is based on opening visible content, not proof a person understood it.
- Recordings and pending binary uploads are not retained after page reload. Text drafts are tab-scoped, not durable offline storage; clear them by signing out on a shared device.
- No end-to-end message encryption, media antivirus scanning, transcription, recording of live calls, or offline service-worker queue. Existing authenticated private server access remains.
- Recording duration is capped by the browser's recorder; server enforces the 5 MB size and allowed container signatures, not decoded duration. Storage quotas per patient/plan are not yet implemented.
- Call recovery offers an explicit Reconnect control. A failed browser audio connection is not a completed clinical contact.

## Earlier corrections preserved

Approved homepage layout, older-man image and source credits, diabetes/high blood pressure/arthritis listings on public/sign-in/patient views, removed illustrative photo captions, administrator setup routing and runtime-secret explanation, single-admin creation protection, server session logout correction, optional patient/admin profile photo preview/save/change/remove, counterpart photos and initials fallback, private profile photo access and metadata stripping.
