# Avenshore Care — staging security and verification review

**Date:** 10 November 2026  
**Status:** Local development only. No Cloudflare resources were created and no deployment was published.

## Changes made

- Public registration, sign-in, and visitor support now fail closed if either Turnstile key is missing. The local test harness bypass applies only when its explicit `LOCAL_QA` flag is set; do not set that flag in Cloudflare.
- Turnstile rendering is connected to patient sign-in and registration forms. Public website support now presents its own verification step before creating a visitor session.
- Updated `.dev.vars.example` and the V3 audit so deployment setup reflects the fail-closed behavior.

## Verification performed in this environment

- `npm run check`: **5/5** Node contracts passed.
- Fictional-data API smoke against the original Worker + on-disk SQLite: **19/19** passed, covering administrator setup/login, patient registration, patient/staff messaging, visitor support, site-help upload denial, call queue order/promotion, and visitor call denial.
- Turnstile fail-closed configuration check with deployed-mode settings: **3/3** passed for login, registration, and visitor support returning 503 when the keys are absent.
- The original `tests/bridged_real_backend_e2e.py` passed **11 API checks** before its browser phase failed because this environment denies Chromium's required socket operation (`Operation not permitted`).
- `tests/public_support_v3_qa.py`: the local Worker started and created its fictional administrator, but its browser phase could not run for the same Chromium sandbox restriction.
- Included screenshots are prior Chromium captures generated from this source revision; the current test run did not regenerate them.
- No Cloudflare D1, R2, or Durable Object staging deployment was tested. Real microphone-to-microphone calling was not tested.
- Wrangler's staging configuration now passes a local `--dry-run` build with the separate `avenshore-care-staging` bindings. It is not deployed; the staging D1 ID and Turnstile keys still need account setup.

## Remaining release blockers

- Cloudflare signup/login returned HTTP 403 in the shared browser. Do not keep retrying until Cloudflare resolves the account/access block.
- WebRTC currently configures Google STUN only. TURN fallback, real microphone audio between two authenticated browsers, permission denial, reconnect, and network interruption are unverified.
- Add and review email verification, account recovery, patient account deletion, administrator MFA and staff lifecycle, audit logging, retention/deletion controls, attachment malware scanning and metadata stripping, and applicable Nigeria privacy/healthcare policies.
- Conduct independent security testing and manual accessibility testing, including keyboard-only use, screen readers, zoom/reflow, touch targets, and representative older-adult usability.

## Data handling

All test identities and images are fictional. Do not enter real patient details in local or Cloudflare staging environments.
