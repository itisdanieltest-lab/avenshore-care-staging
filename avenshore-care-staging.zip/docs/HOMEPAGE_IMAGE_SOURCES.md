# Homepage preview photo sources

These are real stock photographs downloaded from their original photo pages. The images are included locally in `public/assets/homepage/` so the preview does not depend on external hotlink availability. The photos are illustrative and do not depict Avenshore patients, clinicians, or vehicles.

| Local file | Source and photographer | Source-page details |
| --- | --- | --- |
| `elderly-man-portrait.webp` | [Pexels photo 6667746](https://www.pexels.com/photo/portrait-of-an-elderly-man-smiling-6667746/) — Kampus Production | Pexels marks the photo free; original dimensions 4016 × 6016. Replaces the former tablet/bed photo. Exact age is not claimed. |
| `senior-wheelchair-support.webp` | [Pexels photo 7446778](https://www.pexels.com/photo/adult-children-taking-care-of-their-mother-on-a-wheelchair-7446778/) — Gustavo Fring | Pexels marks the photo free to use; original listed dimensions 5760 × 3840. |
| `us-ambulance-safety.webp` | [Pexels photo 16576291](https://www.pexels.com/photo/red-ambulance-on-a-street-16576291/) — Terrance Barksdale | Pexels identifies this as a Dallas Fire Rescue ambulance photographed in Texas and marks it free to use. |

The photos are resized WebP versions for page speed. The ambulance is used only beside the emergency-safety message; the surrounding copy states that Avenshore does not provide emergency response or ambulance dispatch. Photo source details are retained here rather than overlaid on the images.

Before production, retain each source URL and recheck the source-page terms and the image rights. Stock images should not be presented as endorsements or as photos of Avenshore patients, providers, or services.
