# Homepage preview photo sources

These are real stock photographs downloaded from their original photo pages. The images are included locally in `public/assets/homepage/` so the preview does not depend on external hotlink availability. The photos are illustrative and do not depict Avenshore patients, clinicians, or vehicles.

| Local file | Source and photographer | Source-page details |
| --- | --- | --- |
| `senior-telehealth.webp` | [Pexels photo 8376249](https://www.pexels.com/photo/a-woman-sitting-on-the-bed-8376249/) — Tima Miroshnichenko | Pexels marks the photo free to use; original listed dimensions 5457 × 3638. |
| `senior-wheelchair-support.webp` | [Pexels photo 7446778](https://www.pexels.com/photo/adult-children-taking-care-of-their-mother-on-a-wheelchair-7446778/) — Gustavo Fring | Pexels marks the photo free to use; original listed dimensions 5760 × 3840. |
| `us-ambulance-safety.webp` | [Pexels photo 16576291](https://www.pexels.com/photo/red-ambulance-on-a-street-16576291/) — Terrance Barksdale | Pexels identifies this as a Dallas Fire Rescue ambulance photographed in Texas and marks it free to use. |

The photos are resized WebP versions for page speed. The ambulance is used only beside the emergency-safety message; the copy states that it is not an Avenshore vehicle and that Avenshore does not provide emergency response or ambulance dispatch.

Before production, retain each source URL and recheck the source-page terms and the image rights. Stock images should not be presented as endorsements or as photos of Avenshore patients, providers, or services.
