# Avenshore Care — Deep UI & Chat Interaction Review

**Status:** Refined frontend candidate for client review; **not approved for real-patient production use**.

## Design decision

The approved Avenshore emblem, ivory backgrounds and teal/gold palette remain. The conversation experience is task-focused rather than decorative: a clearly separated patient list, generous message column, contextual details on wider desktops, compact yet readable mobile thread, visible composer, restrained motion and explicit patient privacy cues.

The W3C WCAG 2.2 requirements guide focus visibility, minimum touch targets, contrast, and accessible operations. NHS service-manual typography guidance encourages readable body sizes and restraint in tiny captions. Primary references:

- https://www.w3.org/TR/WCAG22/
- https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/
- https://service-manual.nhs.uk/design-system/styles/typography

These are general design standards—not proof of usability with older adults until moderated, real-device user testing is completed.

## Verified changes, not assumptions

| Problem identified by reviewing actual files/screens | Fix made | Test evidence |
|---|---|---|
| HTML referenced `chat-premium.css`, which did not exist | Implemented the actual responsive chat design stylesheet | Asset integrity test checks each referenced stylesheet |
| Inbox polling redrew the editor even when no content had changed | Only re-render on changed conversation/messages/call state | Chromium draft preservation and cursor focus tests |
| A delayed response could update a now-different selected conversation | Drop responses if selected conversation changed | Code contract + browser switch test |
| On phones, bottom navigation covered the message composer | Resized chat panel against viewport and persistent nav | Composer-bottom vs nav-top browser assertion at 320/390px |
| The photo attachment control was not keyboard-operable | Use accessible labelled button to open file picker | Chromium Enter-key activation test |
| A mobile dashboard conversation selection did not open a visible thread | Route selection into the Inbox view | Chromium simulated administrator click-through |
| Patient/visitor conversation SQL lacked last-message preview | Add per-conversation last-message SQL selection | Source contract check |
| Narrow grey captions were low contrast | Darken functional labels and metadata | Key pair 4.5:1 contrast tests |
| Desktop lacked an information-rich care context | Three-column desktop inbox at 1440px, two columns for smaller desktops | 1440px Chromium screenshot |

## Real-browser, fictional-data proof

`python tests/chat_deep_qa.py` renders actual project HTML, CSS, JavaScript and SVG in local headless Chromium. It drives the visible login form and the message UI using a **mocked** API containing fictional patient names, conversations and attachment illustration. There is **no real D1, R2, Cloudflare Worker, Twilio, TURN service or clinical data connection** in these screenshots.

The following source-derived screenshots are in `docs/qa/`:

- `chat-admin-1440.png`: rich desktop inbox, selected fictional patient, conversation, shared attachment and care context.
- `chat-admin-1024.png`: compact two-column desktop workspace.
- `chat-admin-768.png`: smaller tablet/desktop.
- `chat-admin-390.png`: mobile administrator conversation with a composer safely above bottom navigation.
- `chat-admin-320.png`: narrow-screen fallback.
- `chat-patient-390.png` and `chat-patient-1440.png`: signed-in patient experience using a fictional account and API responses.
- `chat-admin-search-desktop.png`: search and filtering behavior.

Results:

- Browser checks over **320, 390, 768, 1024, 1440 px** for administrator inbox, plus patient 390 and 1440.
- No JavaScript page errors or document horizontal overflow in these scenarios.
- Draft survived an inbox refresh and conversation switches.
- A failed send retained the draft; retry sent exactly one message in the mock API.
- Conversation search retained focus and filtered the list.
- Photo-picker button could be activated with the Enter key.
- Admin mobile overview correctly opens a chosen conversation.
- Existing wider public/patient/admin 18-viewport tests were also rerun.

These are **UI integration checks, not real backend end-to-end tests**. Sign-in responses are mocked; the admin account used here does not exist in a production database.

## Additional deep risks discovered and not yet certified

1. **Call continuity:** Single-active-call queue logic exists, but abandoned/never-answered calls need timeouts, reconnection rules and missed-call handling. WebRTC currently uses STUN only; TURN credentials and two-device cross-network testing are needed before reliable voice calling can be claimed.
2. **Real healthcare security:** Run a configured Worker/D1/R2/Durable Object deployment with independent permission, session, file authorization, CSRF, rate limiting, and WebSocket isolation tests. Ensure observability and a response plan, medical-data retention and consent policies, plus email verification/recovery and account deletion.
3. **Photo safety:** Filename/MIME checks alone are not a full scanning or image-sanitization pipeline. Evaluate malware handling, EXIF metadata stripping and retention restrictions before real patient uploads.
4. **Accessibility:** Automated viewport and selected color contrast checks do not establish WCAG conformance. Add keyboard-only complete-flow, screen reader, zoom/reflow, large text, and moderated testing with representative older adults.
5. **Admin coverage:** An always-available website is not the same as a staff member available 24/7. Availability and call responses must reflect real operations.
6. **Brand/legal:** Avenshore remains a **working name** until trademark/domain clearance is complete. The approved brand-board's ™ rendering must not be treated as a legal registration claim.
7. **Reliability:** Add staging integration tests with actual Worker bindings, image uploads, queue transition tests, client reconnect tests, and network interruption/retry measurements before production approval.

## Recommended ChatGPT Work continuation

1. Unzip project and read `README.md`, `docs/CHAT_INBOX_DEEP_REVIEW.md`, `docs/TYPOGRAPHY_AUDIT.md` and `docs/qa/VISUAL_QA_RESULTS.md`.
2. Run `npm run check`, `python tests/visual_qa.py`, and `python tests/chat_deep_qa.py` in a supported environment with Chromium and Playwright. Inspect actual screenshots instead of accepting a numeric pass as visual approval.
3. Create a **test-only** Cloudflare environment using Wrangler, with separate D1, R2 and Durable Object bindings and fictional test accounts. Do not store real patient health information.
4. Verify production-grade auth/session flow and live browser interactions. Test call queue across at least two browser identities and real microphone/media devices; add TURN if necessary.
5. Conduct security, privacy, accessibility and clinical operations reviews. Obtain explicit owner approval before exposing the service to actual patients.
