# Avenshore Care — correction report, 11 November 2026

## Corrections carried forward

1. Recovered the approved homepage source and photos from the original work; retained brand mark, typography, free-care wording and navigation.
2. Added diabetes/high blood pressure and no-cost consultations, tests/screenings, prescriptions, referrals and other clinic services to public content and the sign-in/patient Home summary.
3. Removed overlaid “Illustrative stock photography” captions from all three photos. Credits and source documentation remain in docs/HOMEPAGE_IMAGE_SOURCES.md. Adjusted the hero care badge position.
4. Corrected the secure session-cookie property lookup which caused logout to return HTTP 500. Worker/SQLite tests verify session revocation and expired cookies, repeat logout and origin checks. Full live sign-out verification remains to be recorded.

## New corrections in this release

5. Added arthritis and joint pain to hero condition badges, public condition cards, sign-in and patient Home. Descriptive copy invites discussion of pain, stiffness, mobility and next steps; no treatment outcome is promised.
6. Replaced the former woman-with-tablet hero photo with a smiling elderly man, Pexels photo 6667746 by Kampus Production. Removed the former asset from this package; new 1200px-wide WebP retains an accessible description. Exact age is not claimed.
7. Rebalanced desktop condition cards into four health-condition cards then three service cards; existing tablet two-column and phone one-column layouts remain.
8. Admin setup links no longer silently fall back to Home when unavailable. Dedicated messages distinguish missing deployed key, invalid configuration, completed first-admin setup and malformed links.
9. Handle a setup fragment added to an already-open page via hashchange.
10. Preserve setup priority over existing visitor and patient sessions. Add “Check setup again” so a corrected runtime binding can be rechecked with the key still in page memory.
11. Keep the token out of rendered markup and status responses. Existing setup authorization, minimum key requirement, password requirement, one-admin database index and same-origin checks stay enforced.
12. Add nine executable frontend routing/content tests and expand the original Worker/SQLite admin-state test.

## Verification and limitations

`npm run check`: 28/28 pass (Worker and app syntax, Node contracts, executable JS routing, real Worker/SQLite authentication tests).
These are not a full browser/device/accessibility audit. No real patient data or credentials were used. GitHub/Cloudflare publication and live checks are reported separately after deployment.

## Outstanding

- The previously probed live setup API returned HTTP 503 before token verification. The new status identifies a missing versus invalid runtime binding; code changes cannot create a Cloudflare runtime secret. Earlier user confirmation that the correct secret was saved and deployed is retained. Current binding access cannot be inspected while Cloudflare account access is unavailable.
- Administrator credential creation and end-to-end administrator sign-in are not yet verified on Cloudflare.
- Photo uploads remain disabled without R2; real microphone audio, cross-network call recovery and queue testing remain outstanding.
- Complete phone/desktop browser regression, keyboard/screen-reader, privacy/security and operational readiness review before real-patient use.
