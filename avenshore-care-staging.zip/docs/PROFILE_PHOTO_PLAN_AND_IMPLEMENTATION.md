# Profile photos — plan and implementation

## User flow
Patient and administrator: Account → Choose/Change photo → square preview → Save or Cancel. Remove photo restores initials. Photos are optional and do not block account creation. JPG/PNG/WebP source files up to 5 MB are converted in the browser to a 256 × 256 JPEG. Transparent areas use a white background. Center crop is shown before save. Navigating away or signing out discards unsaved previews. Broken image loads expose initials.

## Display and visibility
Saved photos appear in the account card, header avatar, care inbox rows, conversation header and message sender. Patients can retrieve their own photo and the administrator's photo; clinic staff can retrieve patient photos. Other patients, visitors and unauthenticated users cannot retrieve patient thumbnails. Visitor-support rows retain generic icons.

## Storage and API
Migration `0002_profile_photos.sql` creates one private BLOB row per user in existing D1; this does not require R2. Each JPEG is capped at 96 KiB with a 256-pixel dimension limit. Replacement uses an atomic upsert, changes the versioned URL, and keeps only one row. Removal deletes that row. Server strips JPEG application metadata (including EXIF/GPS) and comments. MIME, signature, segment boundaries, size and dimensions are checked; invalid input cannot overwrite the existing image.

- PUT /api/profile/photo — replace own thumbnail only
- DELETE /api/profile/photo — remove own thumbnail only
- GET /api/profile-photos/:userId — authenticated and role-authorized read
- /api/me returns only the actor's own versioned photo URL
- /api/conversations returns the permitted counterpart's photo URL

Responses use private/no-store, nosniff and restricted image content policy. Mutation routes enforce same origin and rate limits. No secret, image content or patient record is placed in public assets. Existing care-inbox polling picks up changed counterpart photo URLs without redrawing unchanged drafts. D1 queries are bounded rather than one photo query per patient.

## Validation
35 Node checks cover real Worker/SQLite persistence, replacement, removal, authentication, patient isolation, staff access, visitor rejection, cross-origin mutations, invalid and oversized files, EXIF removal, photo URL propagation, frontend controls and existing signup/setup/logout/content regressions.

Cloudflare native deployment and live API verification are reported separately after publication. Full physical-device and screen-reader QA remains outstanding. Chat image attachments remain dependent on optional R2; voice messages are deferred as requested.
