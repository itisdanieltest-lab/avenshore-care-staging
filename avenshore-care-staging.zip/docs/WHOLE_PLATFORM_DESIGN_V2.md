# Avenshore Care — Whole-platform design correction, v2

**Date:** 10 November 2026  
**Status:** Visual system and local integration reviewed; NOT cleared for real medical data or production use.  
**Working brand:** Avenshore Care — brand registration and trademark clearance pending.

## Design objective and evidence

The client reference is Teladoc Health's public adults page (https://www.teladochealth.com/individuals/adults), plus the user's screenshots of its logged-in portal. Those screenshots showed a strikingly light background, strong contrast, prominent care entry point, distinct header branding, and five stable bottom navigation destinations. We must not copy Teladoc's proprietary branding or styles. Instead, Avenshore keeps its approved teal-and-gold A mark and adopts a clearer, brighter, more consistent information hierarchy.

The user also identified important shortcomings in Avenshore: sections appeared as unrelated text rather than aligned groups, muted colors flattened the visual hierarchy, abbreviations created ambiguity, and messaging had previously received more polish than other screens. This revision addresses those issues as a system, not as isolated screen patches.

## Scope and implemented changes

| Surface | Implementation | Primary verification |
|---|---|---|
| Public landing | White base, stronger type hierarchy, clear feature-card grid, teal primary actions and high-contrast promotional labels | Browser: public welcome desktop/mobile |
| Login and registration | Same type, button, input, card, and spacing system; usable narrow screens | Browser: public login/register, 320–1440px |
| Website help | Consistent panel design; explicit warning against sharing health information before registration | Browser: public help |
| Patient homepage | Brand/care header, five nav destinations, aligned cards for next steps and care options, vivid accents and restrained backgrounds | Browser + local database-backed patient sign-in |
| Get care | Two clearly labeled channel cards, informational next-step panel | Browser + database-backed navigation |
| Health information | Related information grouped into two cards; no invented clinical program availability | Browser + database-backed navigation |
| Private messaging | Legible thread header, active inbox states, high-contrast bubbles, distinct composer, readable privacy strip | Browser + actual Worker/SQLite message exchange |
| Admin inbox | Same chat system, three-column desktop layout, conversation search, patient details, and call action | Browser + actual Worker/SQLite admin sign-in |
| Voice calls | Card grouping, consistent controls, queue states and plain-language descriptions | Browser + Worker/Durable Object compatible local queue tests |
| Account | Profile card, full-text account type, separate privacy explanation and sign out | Browser screenshots across roles |
| Staff overview | Dashboard metrics grouped in a proper three-column grid, full inbox below | Browser 320–1440px |
| Navigation and accessibility | Consistent contrast, focus indicators, large controls, mobile bottom nav, reduced-motion compatibility | Browser layout matrix, Node contracts, local integration |

## Typography and wording

- Use a high-legibility sans-serif first for actionable UI; use expressive editorial type sparingly.
- Clear full-length labels: **Medical history**, **Health information**, **Send a message**, **Request a voice call**, **Account**, **Website help**. The two-word **Health info** is retained *only* in narrow bottom navigation.
- Heading sizes and card boundaries are chosen from one design layer (`public/design-system-v2.css`) to override older conflicting styles.
- The public headline deliberately retains expressive editorial styling without carrying it into forms, chat messages, or medical information.
- No unsupported service promises or claims of 24/7 staffed attention have been added.

## Actual test evidence

1. **Browser layout matrix:** `tests/full_surface_design_qa.py` tested 14 screen/role combinations at widths 320, 390, 768, 1024, 1440 = **70 / 70** passed. Checked horizontal scroll, broken images, page JavaScript errors, and the mobile chat composer position.
2. **Worker-backed integration:** `tests/bridged_real_backend_e2e.py` used the original Worker request handlers with a real on-disk SQLite database and separate browser sessions. **42 / 42** tests passed, including authentic register/login, admin/patient messaging, private image permissions, call-queue order, promotion, and a separate authenticated WebSocket client.
3. **Node contracts:** `npm run check`: **5 / 5** tests passed and JavaScript syntax was validated.
4. **Screen evidence:** `docs/qa/full-surface-v2/` includes browser captures of public, patient, and admin screens. `docs/qa/real-integration/` contains screenshots captured after real local backend interactions. Images are from the original source files, not generative artwork.

### Important limits

- The full-surface matrix uses fictional in-browser responses for repeatable styling tests; it is **not** independent server proof.
- The separate integration suite calls real local Worker code and SQLite through an API bridge because the browser cannot navigate localhost directly in this environment. WebSockets were independently authenticated and tested, but native microphone-to-microphone WebRTC audio was **not** tested.
- Local integration is **not** a Cloudflare D1/R2/Durable Object production deployment. Real-data use requires complete security review, proper privacy/consent, staff verification, breach response, rate-limit testing, accessibility audit, native device tests and Cloudflare environment checks.
- Current portal does not include medical history editing, approved care programs, appointments, password recovery or email verification; labels must not suggest these exist.

## Acceptance gates for ChatGPT Work

- Deploy to an isolated staging Cloudflare account via Wrangler, using non-real patient data only.
- Verify D1 migrations, session cookies and CSRF/Origin behavior, account separation, private attachment access, upload scanning and retention, and single-admin queue fairness.
- Verify WebRTC microphone-to-microphone calling with TURN fallback across two browsers and disconnections.
- Test keyboard-only and assistive technology navigation, focus restoration, 200% zoom, small Android phones, tablets, desktop and `prefers-reduced-motion`.
- Conduct professional healthcare privacy/security review before making the system public for real patients.
