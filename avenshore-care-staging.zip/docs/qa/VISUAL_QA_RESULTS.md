# Avenshore browser layout quality checks

Tested in real Chromium with inlined production HTML/CSS/JS, fictional account/API fixtures. These are not HTTP deployment or backend security tests.

| Role | Width | Horizontal overflow | H1 size | Mobile nav size | JS errors |
|---|---:|---:|---|---|---:|
| public | 320px | 0px | 46px | — | 0 |
| public | 375px | 0px | 46px | — | 0 |
| public | 390px | 0px | 47px | — | 0 |
| public | 768px | 0px | 62px | — | 0 |
| public | 1024px | 0px | 62px | — | 0 |
| public | 1440px | 0px | 80.64px | — | 0 |
| patient | 320px | 0px | 35px | 13px | 0 |
| patient | 375px | 0px | 35px | 13px | 0 |
| patient | 390px | 0px | 35px | 13px | 0 |
| patient | 768px | 0px | 34px | 16px | 0 |
| patient | 1024px | 0px | 34px | 16px | 0 |
| patient | 1440px | 0px | 46.08px | 16px | 0 |
| admin | 320px | 0px | 32px | 13px | 0 |
| admin | 375px | 0px | 32px | 13px | 0 |
| admin | 390px | 0px | 32px | 13px | 0 |
| admin | 768px | 0px | 32px | 16px | 0 |
| admin | 1024px | 0px | 32px | 16px | 0 |
| admin | 1440px | 0px | 43.2px | 16px | 0 |

**Outcome:** Passed horizontal-overflow and JavaScript-error checks at six widths for three user states. Public-to-register and sign-in navigation exercised.
**Not tested:** live Cloudflare backend, physical device, third-party font availability, real calling/media, deployment security or 200% text resize.
