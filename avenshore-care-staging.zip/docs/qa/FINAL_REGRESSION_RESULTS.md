# Homepage refresh regression results

**Scope:** approved public homepage refresh, free-care summary on sign-in and patient home, existing patient/admin flows, and local Worker backend.

## Results

- `npm run check`: **15/15 passed** (JavaScript syntax and Node contract checks).
- `tests/bridged_real_backend_e2e.py`: **11/11 API/SQLite checks passed** for fictional accounts, conversation isolation, CSRF protection, password rejection, message persistence, and private image access control. The script then stopped at browser setup because Chromium could not start in this executor (`socket() failed: Operation not permitted`).
- `tests/public_support_v3_qa.py`: local administrator setup succeeded; the browser-driven cases could not start for the same Chromium restriction.
- Python syntax checks cover the updated visual test harnesses. Their CSS inlining now includes `homepage-refresh.css` so future browser runs exercise the refreshed public and patient screens.

## Limits

The browser-driven layout, responsive screenshots, visitor-support flows, and patient UI integration have **not** been verified in this executor. This is an environment restriction, not a passing browser result. Cloudflare build/deploy is also separate and must be checked from the Cloudflare build log after GitHub updates.

All test identities and care messages are fictional. The refresh is intended for the US site. Emergency guidance directs users to call 911; the Avenshore app is not an emergency response or ambulance dispatch service.
