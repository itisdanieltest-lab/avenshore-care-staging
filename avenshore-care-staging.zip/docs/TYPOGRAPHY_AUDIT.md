# Avenshore Care — typography and visual-hierarchy audit

**Status:** NOT approved for production release. **Basis:** `public/styles.css`, `public/app.js`, `public/index.html`, and real Chromium screenshots in `docs/qa/` captured from actual UI with fictional actors/mocked API. No live-backend or deployment testing is implied.

## Executive verdict
The approved Avenshore brand identity is stronger than the current product UI. Typography lacks a distinct brand type system, active small labels are undersized and often low contrast, and the public marketing page has significant missing CSS. Fixing only the font choice will not be enough.

## Verified findings
1. **No defined premium font pairing** — `styles.css` root uses `ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif`. The wordmark in `app.js` is live text using global styles, not the approved brand-board wordmark.
2. **Small text** — the mobile bottom navigation is `10px`; mobile quick-action headings are `13px`; dashboard help text and timestamps are 10–13px in multiple rules. These are particularly hard to scan for older people.
3. **Contrast defects** — `#8b9a95` against `#fff` calculates to about **2.94:1**; `#80948b` against `#fff` to **3.22:1**; muted footer `#85968f` against `#f5f7f4` to **2.89:1**. These are below the 4.5:1 WCAG AA requirement for normal-size text where applicable. Not all decorative/disabled text has the same requirement; audit each actual instance.
4. **Weak weight hierarchy** — navigation, buttons, small labels and headings overuse 700–900 weights. A premium typographic system should rely on more intentional contrast of size, line-height, weight and space.
5. **Public page styling gap (critical)** — `app.js` renders `.public-header`, `.public-nav`, `.public-hero`, `.feature-grid` but the `styles.css` file contains **no selectors** for those classes. Current `docs/qa/public-mobile.png` and `public-desktop.png` visibly show native buttons, broken header alignment and an uncomposed page. This is not production-ready UI.
6. **Admin identity wraps awkwardly** — `docs/qa/admin-desktop.png` shows the brand wordmark/tagline colliding/wrapping inside the sidebar brand control.

## Reference standards
- W3C WCAG 2.2: https://www.w3.org/TR/WCAG22/ (1.4.3 normal text >=4.5:1, 1.4.4 text resize to 200%, 1.4.12 text spacing must not lose content)
- NHS digital service manual — typography: https://service-manual.nhs.uk/design-system/styles/typography (standard paragraph 16px smaller screens / 19px larger screens; small copy sparingly)

## Proposed typography system for review
- Main UI/brand-supporting font: **Manrope** (if licensing/deployment checks permit, self-hosted), fallback system sans. A modern, legible typeface matching the geometric logo direction.
- Editorial accent only for major public-site headlines and tagline: **Newsreader**. Keep all patient workflows, navigation, labels, forms and messages in the clean sans.
- Body: 17–18px mobile; 18–19px desktop, line-height 1.5–1.65. Use 16px minimum for forms and primary actions.
- Page title: 32–36px mobile / 42–52px desktop. Section titles: 24–30px. Cards: 18–20px; supporting text 15–16px. Reserve 14px for optional metadata, not essential content.
- Mobile navigation labels: 13–14px, with clear icons and accessible tap targets. Avoid compressed or uppercase long labels.
- Define reusable `--font-display`, `--font-ui`, `--text-*`, `--leading-*`, `--tracking-*` tokens, not unrelated one-off sizes.
- Use weights mainly 400, 500, 600, 700; 800 sparingly. Tight tracking only on large display headings, never small labels.
- Update muted tokens to pass ≥4.5:1 for normal text on their actual background. Validate all visited/active/hover/focus states.
- Maintain responsive 320, 375/390, 768, 1024, 1440px reviews; 200% zoom; large OS text; keyboard navigation; high contrast; and reduced motion. Verify **public, registration, patient, chat, call, admin** screens.

## Priority and acceptance checks
P0. Implement missing public page styles and fix header/logo wrapping; capture both desktop and mobile screenshots.
P0. Pass contrast audit for all active labels, body copy, placeholder text where essential and error messages.
P1. Implement approved typography tokens/font usage with reliable fallbacks, and optimize font loading. Test slow/mobile networks.
P1. Enlarge chat timestamps, bottom navigation and quick actions; ensure no clipping at 200% zoom.
P1. Re-shoot screenshots from actual source files and visually compare side by side with brand board. Then perform interactive screen-by-screen QA.

**Audit does not claim that fixes have already been implemented.**
