# Cloudflare staging deployment

This project has a separate Wrangler `staging` environment using a distinct Worker name and D1 database. R2 is optional for the initial deployment; without it, photo uploads return a clear unavailable response. Staging must use fictional records only. Do not put patient information in it.

## Before provisioning

1. Review the exact resource names below and approve their creation in your Cloudflare account.
2. Create an account-scoped Cloudflare API token with only the permissions needed for the chosen method. To create all resources from Wrangler, the intended account needs Workers Admin (the staging Worker is new), D1 Write, and Workers R2 Storage Edit. If resources are created separately in the dashboard, the token can omit R2 write access; deploying a Worker with existing D1/R2 bindings needs Worker Editor access. Keep the token out of chat, source files, and logs. Pass it to Wrangler as `CLOUDFLARE_API_TOKEN`; set `CLOUDFLARE_ACCOUNT_ID` for the intended account.
3. Create a staging Turnstile widget for the eventual `workers.dev` hostname. The app intentionally rejects registration, login, and visitor-support sessions if the Turnstile site key or secret is missing.
4. Use fresh staging credentials and synthetic test accounts. Do not reuse any production password.

## Staging resources

| Resource | Name in this project |
| --- | --- |
| Worker | `avenshore-care-staging` |
| D1 database | `avenshore-care-staging-db` |
| R2 bucket (private, optional) | `avenshore-private-uploads-staging` (not configured yet; photo uploads stay disabled) |
| Durable Object | `RealtimeHub` bound as `REALTIME` |

The staging D1 database has been created and its ID is set in `wrangler.jsonc`. The main/default environment retains a separate placeholder; never copy a production ID into staging. The staging Turnstile site key starts blank and must be set to a key for the deployed staging hostname before enabling sign-up. R2 can be enabled later by creating the private bucket and adding its binding under `env.staging.r2_buckets`; until then, photo upload and retrieval are unavailable.

## Provision and deploy (only after approval)

Run from the project root in a shell where the token and account ID are securely supplied as environment variables. Do not put token values in a command line, checked-in file, or chat transcript.

```sh
npx wrangler d1 create avenshore-care-staging-db
```

R2 setup is optional for the first staging deploy. To enable photo uploads later, create the private `avenshore-private-uploads-staging` bucket and add its `UPLOADS` binding under `env.staging.r2_buckets` before deploying again.

Copy the D1 UUID returned by Wrangler into `env.staging.d1_databases[0].database_id`, then apply the schema and deploy the staging Worker:

```sh
npm run db:staging:migrate
npx wrangler secret put TURNSTILE_SECRET --env staging
npx wrangler deploy --env staging
```

Set `TURNSTILE_SECRET` by entering it into Wrangler's hidden prompt. The public site key is a Worker variable in the staging config. If the Turnstile hostname requires the deployed Worker URL, deploy with the site key blank; registration, login, and guest-session creation will stay fail-closed. Then create the widget for the exact staging hostname, set the public site key and matching secret, and redeploy.

Use an `ADMIN_SETUP_TOKEN` only for the initial administrator bootstrap, and set it as a Worker secret through Wrangler's hidden prompt. Use a randomly generated value of at least 32 characters. After creating the fictional staging administrator, remove the bootstrap secret:

```sh
npx wrangler secret delete ADMIN_SETUP_TOKEN --env staging
```

Then verify registration, login, role authorization, chat and photo ownership, visitor support, call queue behavior, and audio calling with two separate test identities. Audio verification needs real microphones and a configured TURN service; do not mark it verified based on local API tests.

## Do not publish production

This procedure is for staging only. No production deployment is authorized by this guide. Production requires a separate security, privacy, accessibility, and live-calling review and the owner's explicit authorization.
