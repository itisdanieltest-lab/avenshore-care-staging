const app=document.getElementById('app');
const S={actor:null,siteKey:null,view:'welcome',conversations:[],selected:null,messages:[],call:null,ws:null,rtc:null,stream:null,signalQueue:[],localAccepted:false,loading:false,toastTimer:null,drafts:{},conversationSearch:'',conversationFilter:'all',mobileThreadOpen:false};
const icon=(name,size=21)=>{
 const paths={
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
 message:'<path d="M21 11.5a8 8 0 0 1-8 8H6l-4 3v-7a8 8 0 1 1 19-4z"/>',
 phone:'<path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.5 19.5 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7l.5 3a2 2 0 0 1-.6 1.8L7.2 10a16 16 0 0 0 6.8 6.8l1.5-1.8a2 2 0 0 1 1.8-.6l3 .5a2 2 0 0 1 1.7 2z"/>',
 user:'<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
 shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
 clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
 send:'<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
 clip:'<path d="m21 11.5-9 9a5 5 0 0 1-7-7l10-10a3.5 3.5 0 0 1 5 5l-10 10a2 2 0 0 1-3-3l9-9"/>',
 arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
 back:'<path d="M19 12H5m6-6-6 6 6 6"/>',
 logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
 check:'<path d="m4 12 5 5L20 6"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7h.01"/>',
 close:'<path d="M18 6 6 18M6 6l12 12"/>',
 mail:'<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 6 10 7 10-7"/>',
 mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5m-4 0h8"/>',
 menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',
 lock:'<rect x="4" y="10" width="16" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
 activity:'<path d="M22 12h-5l-3 9-4-18-3 9H2"/>',
 users:'<circle cx="9" cy="7" r="4"/><path d="M2 21v-2a7 7 0 0 1 14 0v2M17 3a4 4 0 0 1 0 8m2 4a6 6 0 0 1 3 5"/>',
 bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
 spark:'<path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z"/>'
 };
 return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||paths.heart}</svg>`;
};
const esc=t=>String(t??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const date=t=>t?new Date(Number(t)).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):'';
const first=n=>String(n||'Friend').trim().split(/\s+/)[0];
const notice=(m)=>{let e=document.querySelector('.toast');if(e)e.remove();e=document.createElement('div');e.className='toast';e.setAttribute('role','status');e.textContent=m;document.body.append(e);clearTimeout(S.toastTimer);S.toastTimer=setTimeout(()=>e.remove(),5000);};
async function api(path,options={}){
 const res=await fetch('/api'+path,{credentials:'same-origin',...options});
 const data=await res.json().catch(()=>({error:'Unexpected response'}));
 if(!res.ok)throw new Error(data.error||'Unable to complete request');return data;
}
const post=(path,data={})=>api(path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});
function brand(){return `<span class="brand-logo"><img src="/assets/mark.svg" alt="" width="44" height="44" /></span><span><span class="brand-name">Avenshore<span class="brand-care"> Care</span></span><span class="brand-slogan">CARE THAT STAYS CLOSE.</span></span>`;}
function publicHeader(){return `<header class="public-header"><div class="public-header-inner"><button class="brand brand-plain" data-view="welcome" aria-label="Avenshore Care home">${brand()}</button><nav class="public-nav" aria-label="Main navigation"><button data-view="welcome">Our approach</button><button data-view="help">Website help</button><button class="btn btn-outline" data-view="login">Sign in</button><button class="btn btn-primary" data-view="register">Get started ${icon('arrow',18)}</button></nav></div></header>`;}
function publicHelpLauncher(){return `<div class="guest-help-launcher"><button type="button" class="guest-help-button" data-action="${S.actor?.role==='visitor'?'return-guest':'start-guest'}" aria-label="${S.actor?.role==='visitor'?'Return to website support chat':'Chat with website support before signing up'}">${icon('message',21)}<span>${S.actor?.role==='visitor'?'Return to support':'Need help? Chat with us'}</span></button><p>Website and sign-up assistance only</p></div>`;}
function mainNav(){
 const role=S.actor?.role, admin=role==='admin';
 const tabs=admin?[['admin','home','Dashboard'],['messages','message','Inbox'],['calls','phone','Calls'],['account','user','Account']]:[['home','home','Home'],['care','heart','Get care'],['health','activity','Health info'],['messages','message','Messages'],['account','user','Account']];
 return `<aside class="sidebar"><button class="brand brand-plain" data-view="${admin?'admin':'home'}">${brand()}</button><div class="nav-set"><p class="nav-caption">${admin?'STAFF WORKSPACE':'YOUR CARE SPACE'}</p>${tabs.map(([id,ic,label])=>`<button class="nav-button ${S.view===id?'active':''}" data-view="${id}" ${S.view===id?'aria-current="page"':''}>${icon(ic)} ${label}</button>`).join('')}</div><div class="sidebar-bottom">${icon('shield',25)}<div class="help-title">Privacy matters</div><p class="small-muted">Your conversations are only available to you and authorized clinic staff.</p><button class="mini-link" data-view="help">Help and safety</button></div></aside>
 <nav class="bottom-nav" aria-label="Main navigation">${tabs.map(([id,ic,label])=>`<button class="${S.view===id?'active':''}" data-view="${id}" ${S.view===id?'aria-current="page"':''}>${icon(ic)}<span>${label}</span></button>`).join('')}</nav>`;
}
function appHeader(){const admin=S.actor?.role==='admin';return `<header class="topbar"><div class="topbar-loc"><span class="topbar-text">${icon('heart',18)} <span>${admin?'Staff care workspace':'Care that stays close'}</span></span><button class="topbar-brand" data-view="${admin?'admin':'home'}" aria-label="Avenshore Care home"><img src="/assets/mark.svg" alt="" width="43" height="43"><span>Avenshore <strong>Care</strong></span></button></div><div class="top-actions">${!admin?`<button class="header-care-cta" data-view="care">Get care ${icon('arrow',16)}</button>`:`<span class="status-pill">${icon('shield',15)} Staff workspace</span>`}<button class="avatar avatar-action" data-view="account" aria-label="Open account settings">${esc(first(S.actor?.name)[0]?.toUpperCase())}</button></div></header>`;}
function safety(){return `<div class="safety" role="note"><strong>For emergencies:</strong> This service is not an emergency response line. Contact your local emergency services or go to the nearest emergency department.</div>`;}
function welcome(){return `${publicHeader()}<main class="public-main"><section class="public-hero"><div class="public-copy"><span class="eyebrow eyebrow-gold">WELCOME TO AVENSHORE CARE</span><h1>Compassionate care, <em>always within reach.</em></h1><p>Thoughtful, straightforward support for older adults. Message your care team, request a phone conversation, and stay connected from the comfort of your phone.</p><div class="card-actions"><button class="btn btn-gold" data-view="register">Get started ${icon('arrow',18)}</button><button class="btn btn-translucent" data-view="help">Need help signing up?</button></div><div class="hero-foot">${icon('shield',18)} A private and accessible patient experience</div></div><div class="public-graphic" aria-hidden="true"><div class="orb orb-a"></div><div class="orb orb-b"></div><div class="graphic-card"><div class="graphic-symbol"><img src="/assets/mark.svg" width="76" height="76" alt=""></div><p>Here for your next step.</p><span>Care That Stays Close.</span><div class="graphic-action">${icon('heart',22)} Talk with our team</div></div></div></section>
 <section class="feature-section"><p class="eyebrow">DESIGNED AROUND YOU</p><h2>Healthcare support should feel simple.</h2><div class="feature-grid">${[["message","Message with confidence","Send questions privately and keep the conversation in one place."],["phone","Talk with your care team","Request a secure voice call and see your place in line."],["heart","A more personal experience","Easy-to-use pages created with older adults in mind."]].map(([ic,h,t])=>`<article class="feature"><div class="feature-icon">${icon(ic,26)}</div><h3>${h}</h3><p>${t}</p></article>`).join('')}</div></section><section class="public-cta"><div><p class="eyebrow eyebrow-gold">READY TO BEGIN?</p><h2>Care that feels closer.</h2><p>Create your account to message our care team and request a call.</p></div><button class="btn btn-gold" data-view="register">Create your account ${icon('arrow',19)}</button></section>${safety()}</main><footer class="public-footer">© ${new Date().getFullYear()} Avenshore Care · ${esc('Care That Stays Close.')}</footer>`;}
function authPage(kind){const register=kind==='register';return `${publicHeader()}<main class="auth-wrap"><section class="auth-intro"><p class="eyebrow eyebrow-gold">CARE THAT STAYS CLOSE</p><h1>${register?'Your journey to simpler care starts here.':'Good to have you back.'}</h1><p>${register?'Create your own personal account to securely communicate with our care team.':'Sign in to your private patient or administrator workspace.'}</p><div class="intro-proof">${icon('shield',21)} Private messages and secure account access</div></section><section class="auth-card"><div class="auth-card-mark"><img src="/assets/mark.svg" width="65" height="65" alt=""></div><h2>${register?'Create your account':'Welcome back'}</h2><p>${register?'A few details are all you need to begin.':'Use your registered email and password.'}</p><form id="authForm" data-mode="${register?'register':'login'}">
 ${register?'<label class="form-field">Full name<input name="name" autocomplete="name" required minlength="2" maxlength="90" placeholder="Your full name"></label>':''}
 <label class="form-field">Email address<input name="email" type="email" autocomplete="email" required maxlength="254" placeholder="you@example.com"></label>
 <label class="form-field">Password<input name="password" type="password" autocomplete="${register?'new-password':'current-password'}" required minlength="${register?'12':'1'}" maxlength="128" placeholder="${register?'At least 12 characters':'Your password'}"></label>
 ${register?'<p class="hint">Please register only for yourself. Do not enter medical information into this form.</p>':''}
 <div id="turnstileSlot"></div><button type="submit" class="btn btn-primary full">${register?'Create account':'Sign in'} ${icon('arrow',18)}</button></form><p class="auth-swap">${register?'Already registered?':'New to Avenshore Care?'} <button data-view="${register?'login':'register'}">${register?'Sign in':'Create an account'}</button></p><p class="auth-assistance">Having trouble signing in? <button type="button" data-view="help">Contact website support</button>.</p></section></main>${safety()}`;}
function help(){return `${publicHeader()}<main class="help-wrap"><section class="help-content"><p class="eyebrow">WE'RE HERE TO HELP</p><h1>Need help getting started?</h1><p>Ask our team a question about using the website. You don't need a patient account to ask for help signing up.</p><div class="panel"><h2>Before you chat</h2><p class="small-muted">This public support channel is for website and registration assistance only. Please don't share medical details, images, or sensitive personal information here.</p><button class="btn btn-primary" data-action="start-guest">Chat with website support ${icon('message',18)}</button></div>${safety()}</section></main>`;}
function guestVerification(){return `${publicHeader()}<main class="auth-wrap"><section class="auth-intro"><p class="eyebrow eyebrow-gold">WEBSITE SUPPORT</p><h1>One quick security check.</h1><p>Complete the check to start a website and sign-up support conversation.</p><div class="intro-proof">${icon('shield',21)} Please don't share medical details or photos here</div></section><section class="auth-card"><div class="auth-card-mark"><img src="/assets/mark.svg" width="65" height="65" alt=""></div><h2>Verify to continue</h2><p>Website help is separate from your private care account.</p><div id="guestTurnstileSlot" aria-label="Security verification"></div><button class="btn btn-primary full" type="button" data-action="confirm-guest">Start website support ${icon('message',18)}</button><button class="mini-link" type="button" data-view="welcome">Return to website</button></section></main>${safety()}`;}
function quick(ic,h,sub,view){return `<button class="quick" data-view="${view}"><span class="quick-icon">${icon(ic,25)}</span><strong>${h}</strong><span>${sub}</span></button>`;}
function home(){const latest=S.conversations.find(c=>c.kind==='care'&&c.last_message);return `<div class="max patient-home"><div class="home-greeting"><p class="eyebrow">YOUR PERSONAL CARE SPACE</p><h1>Welcome back, ${esc(first(S.actor.name))}<span class="heading-period">.</span></h1><p>Your care updates and ways to reach us are below.</p></div><section class="home-care-focus"><div class="focus-copy"><span class="eyebrow">CARE THAT STAYS CLOSE</span><h2>Need to talk with your care team?</h2><p>Send a private message or request an in-app voice call.</p><button class="btn btn-primary focus-action" data-view="care">Get care ${icon('arrow',19)}</button></div><div class="focus-emblem" aria-hidden="true"><img src="/assets/mark.svg" width="120" height="120" alt=""></div></section><div class="home-content-grid"><section class="home-next" aria-labelledby="next-step-heading"><div class="section-head home-section-title"><h2 id="next-step-heading">Recent activity</h2></div><div class="home-next-card"><div class="next-step-icon">${icon('message',26)}</div><div class="next-step-copy"><strong>${latest?'New activity in your messages':'No new updates yet'}</strong><p>${latest?'Read the latest message from your care team.':'Replies and care updates will appear here.'}</p></div><button class="next-step-button" data-view="messages" aria-label="Open messages">${icon('arrow',22)}</button></div></section><section class="home-care-options" aria-labelledby="care-options-heading"><div class="section-head home-section-title"><h2 id="care-options-heading">Care options</h2><button class="mini-link" data-view="care">Explore care options ${icon('arrow',16)}</button></div><div class="home-option-grid"><button class="home-option" data-view="messages"><span class="option-icon">${icon('message',25)}</span><span><strong>Send a message</strong><small>Ask the care team a question</small></span>${icon('arrow',17)}</button><button class="home-option" data-view="calls"><span class="option-icon option-phone">${icon('phone',25)}</span><span><strong>Request a voice call</strong><small>See whether the line is available</small></span>${icon('arrow',17)}</button><button class="home-option" data-view="health"><span class="option-icon option-health">${icon('activity',25)}</span><span><strong>Health information</strong><small>Learn what is available in your portal</small></span>${icon('arrow',17)}</button></div></section></div><section class="home-peace"><div class="home-peace-icon">${icon('shield',22)}</div><div><strong>Personal support. Private by design.</strong><p>Your messages are for you and authorized clinic staff. This website is not an emergency service.</p></div></section>${safety()}</div>`;}
function careHub(){return `<div class="max care-hub">${intro('Get care','Choose how you would like to reach your care team.')}<div class="care-hub-options"><button class="care-hub-option" data-view="messages"><span class="care-hub-icon">${icon('message',32)}</span><span><strong>Send a private message</strong><small>Write to the team and attach a photo when needed.</small></span>${icon('arrow',21)}</button><button class="care-hub-option" data-view="calls"><span class="care-hub-icon care-hub-phone">${icon('phone',32)}</span><span><strong>Request a voice call</strong><small>Call securely in your browser; if the line is busy, join the queue.</small></span>${icon('arrow',21)}</button></div><section class="care-hub-note"><h2>What happens next?</h2><p>You can keep messaging while waiting for your call. Only one patient can be on a call with the care team at a time.</p><button class="btn btn-outline" data-view="health">Explore health information ${icon('arrow',17)}</button></section>${safety()}</div>`;}
function intro(title,subtitle){return `<div class="page-heading"><p class="eyebrow">AVENSHORE CARE</p><h1 class="page-title">${title}</h1><p class="page-intro">${subtitle}</p></div>`;}
function conversationTitle(c){return c.kind==='site-help'?'Website visitor':(S.actor.role==='admin'?c.display_name||'Patient':'Care Team');}
function convList(){
 const admin=S.actor.role==='admin';
 const filtered=S.conversations.filter(c=>(S.conversationFilter==='all'||(S.conversationFilter==='care'&&c.kind==='care')||(S.conversationFilter==='site-help'&&c.kind==='site-help'))&&`${conversationTitle(c)} ${c.last_message||''}`.toLowerCase().includes(S.conversationSearch.toLowerCase()));
 const filters=admin?`<div class="inbox-filters" aria-label="Filter conversations"><button type="button" data-filter="all" class="${S.conversationFilter==='all'?'is-active':''}" aria-pressed="${S.conversationFilter==='all'}">All</button><button type="button" data-filter="care" class="${S.conversationFilter==='care'?'is-active':''}" aria-pressed="${S.conversationFilter==='care'}">Patients</button><button type="button" data-filter="site-help" class="${S.conversationFilter==='site-help'?'is-active':''}" aria-pressed="${S.conversationFilter==='site-help'}">Site help</button></div>`:'';
 return `<section class="chat-list" aria-label="Conversation inbox"><div class="inbox-heading"><div><span class="inbox-label">YOUR INBOX</span><h2>Conversations <span class="inbox-count">${S.conversations.length}</span></h2></div><span class="inbox-heading-icon">${icon('message',23)}</span></div><div class="inbox-controls"><label class="inbox-search" for="conversationSearch">${icon('message',18)}<span class="vhide">Search conversations</span><input id="conversationSearch" type="search" value="${esc(S.conversationSearch)}" placeholder="Search conversations" autocomplete="off"></label>${filters}</div><div class="conversation-list-body" id="conversationListBody">${filtered.length?filtered.map(c=>`<button class="conversation-row ${S.selected===c.id?'selected':''}" data-select="${esc(c.id)}" aria-pressed="${S.selected===c.id}" type="button"><span class="avatar ${c.kind==='site-help'?'purple':'blue'}">${c.kind==='site-help'?icon('info',20):esc(first(conversationTitle(c))[0]?.toUpperCase())}</span><span class="conv-text"><strong>${esc(conversationTitle(c))}</strong><small>${esc(c.last_message|| (c.kind==='site-help'?'Help with the website':'Start a private conversation'))}</small><span class="conv-category">${c.kind==='site-help'?'WEBSITE SUPPORT':'PATIENT CARE'}</span></span><span class="conv-arrow">${icon('arrow',16)}</span></button>`).join(''):`<div class="inbox-empty"><span class="empty-emblem">${icon('message',27)}</span><strong>${S.conversations.length?'No matches found':'A quiet moment'}</strong><p>${S.conversations.length?'Try another search or filter.':admin?'Patient conversations will appear here when someone gets in touch.':'Your care conversation will appear here.'}</p></div>`}</div><div class="inbox-foot">${icon('shield',16)} Private messages · Only authorized access</div></section>`;
}
function bubble(m,previous){
 const mine=m.sender_type===S.actor.role;
 const label=mine?'You':m.sender_type==='admin'?'Care Team':m.sender_type==='visitor'?'Website visitor':m.sender_type==='patient'?'Patient':'Care Team';
 const attachment=m.attachment_id?`<a class="chat-attachment" href="/api/attachments/${esc(m.attachment_id)}" target="_blank" rel="noopener noreferrer" aria-label="View attached image in a new tab"><img loading="lazy" src="/api/attachments/${esc(m.attachment_id)}" alt="Photo shared in this conversation"><span>${icon('clip',15)} View attached photo</span></a>`:'';
 return `<div class="message-group ${mine?'is-mine':'is-theirs'} ${previous?.sender_type===m.sender_type?'followup':''}"><div class="message-sender">${esc(label)}</div><div class="bubble ${mine?'mine':''}">${m.content?`<div class="bubble-content">${esc(m.content)}</div>`:''}${attachment}<div class="bubble-meta"><time>${esc(date(m.created_at))}</time>${mine?icon('check',14):''}</div></div></div>`;
}
function chatContext(c){if(!c)return '';
 const admin=S.actor.role==='admin',guest=c.kind==='site-help';
 return `<aside class="chat-context" aria-label="Conversation information"><div class="context-head"><span class="inbox-label">CONVERSATION DETAILS</span><div class="context-emblem">${icon(guest?'info':'heart',28)}</div><h3>${esc(conversationTitle(c))}</h3><p>${guest?'Help with website access and registration':'One-to-one patient support'}</p></div><div class="context-section"><span class="context-caption">CHANNEL</span><strong>${guest?'Website assistance':'Private care messaging'}</strong><p>${guest?'Please keep clinical details and images out of this support channel.':'Messages and images are available to authorized participants.'}</p></div>${guest?'':`<div class="context-section"><span class="context-caption">VOICE SUPPORT</span><button type="button" class="context-call" data-view="calls">${icon('phone',19)} ${admin?'Manage call line':'Request a voice call'} ${icon('arrow',15)}</button><p>One active call at a time; additional requests wait in line.</p></div>`}<div class="context-note">${icon('shield',19)}<span>${guest?'Website support is for account and access questions only.':'For your privacy, only share information needed for your care.'}</span></div></aside>`;
}
function conversation(){
 const c=S.conversations.find(x=>x.id===S.selected);
 if(!c)return `<section class="conversation no-thread"><div class="thread-empty"><div class="thread-empty-art">${icon('heart',42)}</div><span class="inbox-label">CARE THAT STAYS CLOSE</span><h2>Your conversations, in one safe place.</h2><p>${S.actor.role==='admin'?'Select a patient conversation to read and reply.':'Choose your care conversation to get started.'}</p></div></section>`;
 const guest=c.kind==='site-help';
 const inputLabel=S.actor.role==='admin'?'Write a reply…':'Write your message…';
 return `<section class="conversation"><header class="conversation-head"><button type="button" class="thread-back" data-action="thread-back" aria-label="Back to conversations">${icon('back',21)}</button><span class="avatar thread-avatar">${icon(guest?'info':'heart',22)}</span><div class="thread-ident"><strong>${esc(guest?'Registration support':conversationTitle(c))}</strong><small>${guest?'Questions about the website only':'Private conversation with the care team'}</small></div>${guest?'':`<button class="thread-call" data-view="calls" type="button" title="Open voice call controls" aria-label="Open voice call controls">${icon('phone',19)}<span>Voice call</span></button>`}</header><div class="thread-trust" role="note">${icon('lock',16)}<span>${guest?'Website support only. Do not share health information here.':'Your messages stay in this private conversation. Not for emergencies.'}</span></div><div class="messages" id="messageStream" role="log" aria-label="Conversation messages" aria-live="polite" aria-relevant="additions text">${S.messages.length?S.messages.map((m,i)=>bubble(m,S.messages[i-1])).join(''):`<div class="thread-start"><span>${icon('message',28)}</span><h3>Start the conversation</h3><p>${guest?'Ask about signing in or using this website.':'Tell the care team how they can help you today.'}</p></div>`}</div><form class="composer" id="messageForm" data-conversation-id="${esc(c.id)}"><div class="composer-bar">${!guest&&S.actor.role!=='visitor'?`<button class="attach-control" type="button" data-action="pick-image" aria-label="Attach an image" title="Attach a photo">${icon('clip',21)}</button><input id="imageUpload" type="file" accept="image/png,image/jpeg,image/webp" hidden>`:''}<label class="vhide" for="messageText">Your message</label><textarea id="messageText" name="content" placeholder="${inputLabel}" rows="2" required maxlength="3000">${esc(S.drafts[c.id]||'')}</textarea><button class="composer-send" type="submit">${icon('send',19)}<span>Send</span></button></div><div class="composer-helper"><span>${icon('shield',14)} ${guest?'Website help only':'Private conversation'}</span><span id="draftCount">${(S.drafts[c.id]||'').length}/3000</span></div></form></section>`;
}
function messages(){
 const guest=S.actor.role==='visitor', admin=S.actor.role==='admin';
 return `<div class="chat-page"><div class="chat-page-top"><div><span class="eyebrow">${guest?'WEBSITE SUPPORT':admin?'STAFF COMMUNICATIONS':'YOUR CARE CONVERSATIONS'}</span><h1>${guest?'Website support':admin?'Support inbox':'Messages'}<span class="heading-period">.</span></h1><p>${guest?'Help with access or sign-up. Please do not share health information.':admin?'Patient care and website enquiries, organized in one place.':'A familiar place to talk with your care team.'}</p></div><div class="chat-top-chip">${icon(admin?'users':'shield',18)} ${guest?'Website assistance':admin?'Single care team inbox':'Private care messaging'}</div></div><div class="chat-layout ${S.mobileThreadOpen?'mobile-thread-open':''} ${admin?'admin-chat':''}">${convList()}${conversation()}${chatContext(S.conversations.find(x=>x.id===S.selected))}</div>${safety()}</div>`;
}
function callPanel(){const st=S.call||{}, isAdmin=S.actor.role==='admin', active=st.active, mine=!!active&&active.patientId===S.actor.id, q=st.queue||[], pos=st.position;
 return `<div class="max call-page">${intro(isAdmin?'Voice call management':'Call the Care Team',isAdmin?'One active voice call at a time. Additional patients wait in the queue.':'Request a one-to-one voice call. You can send messages while you wait.')}<div class="calling-card"><div><span class="eyebrow">${active?'CALL LINE IN USE':'VOICE CALL LINE'}</span><h2>${active?(isAdmin?'A patient is on the call line':mine?(active.state==='active'?'Your call was accepted':'Your request is next'):'The team is helping another patient'):'The call line is ready'}</h2><p>${isAdmin?'Calls must be accepted by the administrator.':''}${mine?' You can cancel or end your request at any time.':pos?' You are waiting for your turn.':' Available staff will respond to your request when possible.'}</p>
 <div class="card-actions">${isAdmin?(active?`${active.state==='ringing'?'<button class="btn btn-primary" data-action="accept-call">Accept call</button>':'<button class="btn btn-primary" data-action="ready-audio">Connect audio</button>'}<button class="btn btn-danger" data-action="end-call">End call</button>`:'<span class="status-pill">No call waiting</span>'):(mine?(active.state==='active'?'<button class="btn btn-primary" data-action="ready-audio">Join voice call</button>':'<span class="status-pill busy">Waiting for administrator</span>'):`${pos?'':`<button class="btn btn-primary" data-action="request-call">${icon('phone',18)} Request voice call</button>`}${pos?`<div class="status-pill busy">Queue position: ${pos}</div>`:''}`)}${!isAdmin&&(mine||pos)?'<button class="btn btn-outline" data-action="cancel-call">Cancel request</button>':''}</div></div><div class="call-visual"><div class="status-big">${icon('phone',43)}</div><p>${active?'One-call privacy protected':'One call at a time'}</p></div></div>
 ${isAdmin?`<section class="queue"><h3>Waiting queue · ${q.length}</h3>${q.length?q.map((x,i)=>`<div class="queue-item"><strong>#${i+1}</strong><span>Patient request</span><span class="row-right small-muted">${esc(date(x.requestedAt))}</span></div>`).join(''):'<p class="small-muted">No patients waiting.</p>'}</section>`:pos?`<section class="queue"><h3>You are in line</h3><div class="big-number">${pos}</div><p class="small-muted">Keep this page open for updates. You may continue messaging.</p></section>`:''}<section class="safety"><strong>Voice-call notice:</strong> Internet calling depends on device microphone permissions and network connectivity. Availability is not a guarantee of immediate clinical attention.</section>${safety()}</div>`;}
function adminHome(){const active=S.call?.active, q=S.call?.queue||[];return `<div class="max staff-dashboard">${intro('Your care workspace','One organized view of patient messages and incoming calls.')}<div class="metric-grid"><div class="metric"><strong>${S.conversations.length}</strong><span>Conversations</span></div><div class="metric"><strong>${active?'1':'0'}</strong><span>Active calls</span></div><div class="metric"><strong>${q.length}</strong><span>Waiting calls</span></div></div><div class="section-head"><h2>Patient inbox</h2><button data-view="messages">Open full inbox ${icon('arrow',16)}</button></div><div class="admin-grid">${convList()}${conversation()}</div><div class="section-head"><h2>Voice call queue</h2><button data-view="calls">Manage calls ${icon('arrow',16)}</button></div><section class="panel"><p class="small-muted">${active?'One incoming or active call.':'No voice call in progress.'} ${q.length} ${q.length===1?'patient':'patients'} waiting.</p><button class="btn btn-primary" data-view="calls">Open call controls ${icon('arrow',17)}</button></section>${safety()}</div>`;}
function account(){const role=S.actor.role==='admin'?'Administrator':S.actor.role==='patient'?'Patient':'Website support visitor';return `<div class="max account-page">${intro('My account','Your personal details and secure account settings.')}<div class="account-layout"><section class="panel"><div class="profile-card"><div class="avatar" style="height:65px;width:65px;font-size:22px">${esc(first(S.actor.name)[0])}</div><div><h2 style="margin:0">${esc(S.actor.name)}</h2><p class="small-muted">${esc(S.actor.email||'Website support session')}</p></div></div><div class="account-stat"><span>Account type</span><strong>${role}</strong></div><button class="btn btn-outline" data-action="logout">${icon('logout',18)} Sign out securely</button></section><aside class="account-note"><h2>About your privacy</h2><p>Only you and authorized clinic staff can access your private care conversations. Sign out after using a shared device.</p><p>Need to update or close your account? Contact the care team for help.</p></aside></div>${safety()}</div>`;}
function health(){return `<div class="max health-page">${intro('Health information','Practical guidance for staying connected with your care team.')}<div class="health-card-grid"><section class="panel"><span class="eyebrow">HOW IT WORKS</span><h2>Contact your care team</h2><p>Ask questions through private messages, share a relevant photo with authorized staff, or request a voice call.</p><div class="health-info-actions"><button class="btn btn-primary" data-view="messages">Send a message ${icon('arrow',18)}</button><button class="btn btn-outline" data-view="calls">Request a voice call ${icon('phone',17)}</button></div></section><section class="panel"><span class="eyebrow">YOUR PRIVACY</span><h2>Share information securely</h2><p>Send care-related messages and photos only in your signed-in conversation. The public website support chat is for account and website questions.</p><button class="btn btn-outline" data-view="messages">Open secure messages ${icon('arrow',17)}</button></section></div>${safety()}</div>`;}
function screen(){if(!S.actor||S.actor.role==='visitor'){
  if(S.actor?.role==='visitor'&&S.view==='messages')return `<div class="visitor-workspace">${publicHeader()}<main class="visitor-main"><div class="visitor-chat-toolbar"><div><strong>Website support</strong><span>Registration and website questions only</span></div><button class="btn btn-outline" type="button" data-action="end-guest">End support chat</button></div>${messages()}</main></div>`;
  const content=['register','login'].includes(S.view)?authPage(S.view):S.view==='help'?help():S.view==='guest-verify'?guestVerification():welcome();
  return content+(S.view==='help'?'':publicHelpLauncher());
 }
 const r=S.view==='messages'?messages():S.view==='calls'?callPanel():S.view==='care'?careHub():S.view==='account'?account():S.view==='health'?health():S.view==='admin'&&S.actor.role==='admin'?adminHome():S.actor.role==='admin'?adminHome():home();
 return `<div class="shell">${mainNav()}<main class="main">${appHeader()}${r}<div class="footer-note">Avenshore Care · Care That Stays Close. · Private healthcare communication</div></main></div>`;
}
function render(){
 const active=document.activeElement;
 const oldStream=document.getElementById('messageStream');
 const oldStreamConversation=document.getElementById('messageForm')?.dataset.conversationId;
 const atBottom=!!oldStream&&(oldStream.scrollHeight-oldStream.scrollTop-oldStream.clientHeight<72);
 const oldScrollTop=oldStream?.scrollTop||0;
 const previousForm=document.getElementById('messageForm');
 const oldEditor=document.getElementById('messageText');
 if(previousForm&&oldEditor)S.drafts[previousForm.dataset.conversationId]=oldEditor.value;
 const focusId=(active?.id==='messageText'||active?.id==='conversationSearch')?active.id:null;
 const caret=focusId&&typeof active.selectionStart==='number'?active.selectionStart:null;
 const anchor=focusId&&typeof active.selectionEnd==='number'?active.selectionEnd:null;
 const editorScroll=focusId==='messageText'?active.scrollTop:0;
 app.innerHTML=screen();
 if(S.siteKey)attachTurnstile();
 if(focusId){const next=document.getElementById(focusId);if(next){next.focus({preventScroll:true});if(caret!=null&&next.setSelectionRange){next.setSelectionRange(Math.min(caret,next.value.length),Math.min(anchor??caret,next.value.length));}if(focusId==='messageText')next.scrollTop=editorScroll;}}
 // Do not keep a loader over the app if the API fails or the connection is slow.
 if(!document.body.classList.contains('booted')){
  document.body.classList.add('booted');
  setTimeout(()=>document.getElementById('boot-screen')?.remove(),500);
 }
 const stream=document.getElementById('messageStream');
 if(stream){if(oldStreamConversation!==S.selected||atBottom)stream.scrollTop=stream.scrollHeight;else stream.scrollTop=oldScrollTop;}
 attachTurnstile();
}
function view(v){
 if(S.view===v)return;
 S.view=v;
 if(v==='messages')S.mobileThreadOpen=S.actor?.role!=='admin';
 app.classList.remove('animate-view');
 render();
 // Navigation transition lasts just 260ms and cannot block interaction.
 app.classList.add('animate-view');
 setTimeout(()=>app.classList.remove('animate-view'),310);
 window.scrollTo({top:0,behavior:'instant'});
 if(v==='calls')refreshCall();
 if(v==='messages'||v==='admin')refreshConversations();
}
async function refreshConversations(){
 if(!S.actor)return;
 try{
  const d=await api('/conversations');
  const incoming=d.conversations||[];
  const changed=JSON.stringify(incoming)!==JSON.stringify(S.conversations);
  const oldSelected=S.selected;
  S.conversations=incoming;
  if(!S.selected||!S.conversations.some(c=>c.id===S.selected))S.selected=S.conversations[0]?.id||null;
  if(oldSelected!==S.selected)S.messages=[];
  if(S.selected)await refreshMessages(false,changed||oldSelected!==S.selected);
  else if(changed||oldSelected!==S.selected)render();
 }catch(e){notice(e.message);}
}
async function refreshMessages(quiet=true,forceRender=false){
 const conversationId=S.selected;if(!conversationId)return;
 try{
  const d=await api(`/conversations/${conversationId}/messages`);
  if(S.selected!==conversationId)return; // Ignore a delayed response for another patient.
  const incoming=d.messages||[];
  const changed=JSON.stringify(incoming)!==JSON.stringify(S.messages);
  if(changed)S.messages=incoming;
  if((changed||forceRender)&&(S.view==='messages'||S.view==='admin'))render();
 }catch(e){if(!quiet)notice(e.message);}
}
async function refreshCall(){if(!S.actor||S.actor.role==='visitor')return;try{const incoming=await api('/calls');const changed=JSON.stringify(incoming)!==JSON.stringify(S.call);S.call=incoming;if(changed&&(S.view==='calls'||S.view==='admin'))render();}catch(e){if(S.view==='calls')notice(e.message);}}
function connectRealtime(){if(!S.actor||S.ws)return;
 try{if(location.origin==='null')return;const url=new URL('/api/events',location.href);url.protocol=url.protocol==='https:'?'wss:':'ws:';const ws=new WebSocket(url);S.ws=ws;ws.onmessage=async ev=>{let d;try{d=JSON.parse(ev.data);}catch{return;}if(d.type==='message'){refreshConversations();}if(d.type==='calls'){refreshCall();}if(d.type==='signal'){handleSignal(d);}};ws.onclose=()=>{S.ws=null;setTimeout(()=>{if(S.actor)connectRealtime();},5000)};ws.onerror=()=>{};}catch{} }
async function mutate(fn){
 if(S.loading)return;
 S.loading=true;
 let visible=false;
 const timer=setTimeout(()=>{visible=true;document.getElementById('request-progress')?.classList.add('is-busy');app.setAttribute('aria-busy','true');},180);
 try{await fn();}catch(e){notice(e.message);}finally{
  clearTimeout(timer);S.loading=false;
  if(visible){document.getElementById('request-progress')?.classList.remove('is-busy');app.removeAttribute('aria-busy');}
 }
}
async function attachTurnstile(){
 const slot=document.getElementById('turnstileSlot')||document.getElementById('guestTurnstileSlot');if(!slot||!S.siteKey||slot.dataset.turnstileRendered==='true')return;
 const scriptId='cfTurnstile';if(!document.getElementById(scriptId)){const s=document.createElement('script');s.id=scriptId;s.src='https://challenges.cloudflare.com/turnstile/v0/api.js';s.async=true;document.head.appendChild(s);}
 const interval=setInterval(()=>{if(!slot.isConnected){clearInterval(interval);return;}if(window.turnstile){clearInterval(interval);try{window.turnstile.render(slot,{sitekey:S.siteKey,callback:t=>{slot.dataset.token=t;},'error-callback':()=>notice('Security verification could not load. Please try again.')});slot.dataset.turnstileRendered='true';}catch{notice('Security verification could not load. Please try again.');}}},200);
 setTimeout(()=>clearInterval(interval),10000);
}
async function submitAuth(form){const d=Object.fromEntries(new FormData(form));d.turnstileToken=document.querySelector('#turnstileSlot')?.dataset.token||'';const mode=form.dataset.mode;
 await mutate(async()=>{await post(`/auth/${mode}`,d);const me=await api('/me');S.actor=me.actor;S.siteKey=me.turnstileSiteKey;S.view=S.actor.role==='admin'?'admin':'home';connectRealtime();await refreshConversations();await refreshCall();render();window.scrollTo({top:0,behavior:'instant'});notice(`Welcome${S.actor.name?', '+first(S.actor.name):''}!`);});}
async function logout(){await mutate(async()=>{if(S.rtc)stopAudio();await post('/auth/logout');await post('/guest/end');if(S.ws){S.ws.close();S.ws=null;}S.actor=null;S.selected=null;S.conversations=[];S.messages=[];S.call=null;S.drafts={};S.conversationSearch='';S.view='welcome';render();});}
async function endGuest(){await mutate(async()=>{await post('/guest/end');if(S.ws){S.ws.close();S.ws=null;}S.actor=null;S.selected=null;S.conversations=[];S.messages=[];S.view='welcome';render();notice('Website support chat ended.');});}
async function startGuest(verified=false){if(S.actor?.role==='visitor'){view('messages');return;}if(S.siteKey&&!verified){S.view='guest-verify';render();return;}const turnstileToken=document.getElementById('guestTurnstileSlot')?.dataset.token||'';if(S.siteKey&&!turnstileToken){notice('Complete the security check before starting website support.');return;}await mutate(async()=>{await post('/guest/start',{turnstileToken});const me=await api('/me');S.actor=me.actor;S.view='messages';S.mobileThreadOpen=true;await refreshConversations();connectRealtime();render();});}
async function sendMessage(form){
 const content=form.elements.content.value.trim();if(!content)return;
 const conversationId=form.dataset.conversationId;
 form.querySelector('button[type=submit]').disabled=true;
 await mutate(async()=>{
   await post(`/conversations/${conversationId}/messages`,{content});
   S.drafts[conversationId]='';form.elements.content.value='';
   await refreshConversations();
 });
 if(form.isConnected)form.querySelector('button[type=submit]').disabled=false;
}
async function uploadImage(file){if(!file)return;if(file.size>5*1024*1024){notice('Please choose an image smaller than 5 MB');return;}if(!['image/jpeg','image/png','image/webp'].includes(file.type)){notice('Choose a JPEG, PNG, or WebP photo');return;}
 await mutate(async()=>{const res=await fetch(`/api/conversations/${S.selected}/attachments`,{method:'POST',headers:{'content-type':file.type},body:file,credentials:'same-origin'});const d=await res.json();if(!res.ok)throw new Error(d.error||'Upload failed');await refreshConversations();notice('Image sent privately');});}
async function call(action){await mutate(async()=>{await post(`/calls/${action}`);if(action==='end'||action==='cancel')stopAudio();await refreshCall();});}
function stopAudio(){if(S.rtc){try{S.rtc.close();}catch{}S.rtc=null;}if(S.stream){for(const t of S.stream.getTracks())t.stop();S.stream=null;}S.localAccepted=false;document.querySelector('#remoteAudio')?.remove();document.body.classList.remove('in-call');}
async function ensurePeer(){if(S.rtc)return S.rtc;
 if(!navigator.mediaDevices?.getUserMedia||!window.RTCPeerConnection)throw new Error('Voice calls require a supported browser and microphone permission');
 S.stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
 const ice=[{urls:'stun:stun.l.google.com:19302'}]; // Add short-lived TURN credentials before clinical production use.
 const peer=new RTCPeerConnection({iceServers:ice});S.rtc=peer;
 for(const track of S.stream.getTracks())peer.addTrack(track,S.stream);
 peer.onicecandidate=e=>{if(e.candidate)signal('candidate',e.candidate.toJSON());};
 peer.ontrack=e=>{let audio=document.querySelector('#remoteAudio');if(!audio){audio=document.createElement('audio');audio.id='remoteAudio';audio.autoplay=true;audio.controls=true;audio.setAttribute('aria-label','Voice call audio');document.body.append(audio);}audio.srcObject=e.streams[0];audio.play().catch(()=>{});document.body.classList.add('in-call');};
 peer.onconnectionstatechange=()=>{if(peer.connectionState==='failed')notice('Audio connection failed. Please try again or continue by message.');};
 return peer;
}
function signal(kind,data){const callId=S.call?.active?.callId;if(callId&&S.ws?.readyState===WebSocket.OPEN)S.ws.send(JSON.stringify({type:'signal',kind,data,callId}));}
async function readyAudio(){await mutate(async()=>{
 const active=S.call?.active;if(!active||active.state!=='active')throw new Error('Wait for the call to be accepted');
 const peer=await ensurePeer();S.localAccepted=true;
 if(S.actor.role==='patient'){const offer=await peer.createOffer();await peer.setLocalDescription(offer);signal('offer',{type:offer.type,sdp:offer.sdp});}
 else notice('Microphone ready. Waiting for patient to connect.');
 for(const d of S.signalQueue.splice(0))await applySignal(d);
 });}
async function applySignal(d){const active=S.call?.active;if(!active||active.callId!==d.callId)return;
 if(!S.rtc){S.signalQueue.push(d);return;}
 const pc=S.rtc;
 try{
  if(d.kind==='offer'&&S.actor.role==='admin'){
   await pc.setRemoteDescription(d.data);
   const answer=await pc.createAnswer();await pc.setLocalDescription(answer);signal('answer',{type:answer.type,sdp:answer.sdp});
  }else if(d.kind==='answer'&&S.actor.role==='patient')await pc.setRemoteDescription(d.data);
  else if(d.kind==='candidate'){
   if(!pc.remoteDescription){S.signalQueue.push(d);return;}
   await pc.addIceCandidate(d.data);
  }
 }catch{notice('Could not establish audio. Try ending the call and requesting again.');}
}
function handleSignal(d){applySignal(d);}
app.addEventListener('click',async e=>{
 const v=e.target.closest('[data-view]');if(v){const next=v.dataset.view;view(next);return;}
 const s=e.target.closest('[data-select]');if(s){
  const old=document.getElementById('messageForm');if(old)S.drafts[old.dataset.conversationId]=old.elements.content.value;
  S.selected=s.dataset.select;S.messages=[];S.mobileThreadOpen=true;if(S.view==='admin'&&window.innerWidth<=760)S.view='messages';render();await refreshMessages(false);return;
 }
 const filter=e.target.closest('[data-filter]');if(filter){S.conversationFilter=filter.dataset.filter;render();return;}
 const b=e.target.closest('[data-action]');if(!b)return;
 const a=b.dataset.action;
 if(a==='thread-back'){S.mobileThreadOpen=false;render();return;}
 if(a==='pick-image'){document.getElementById('imageUpload')?.click();return;}
 if(a==='logout')return logout();if(a==='start-guest')return startGuest();if(a==='confirm-guest')return startGuest(true);if(a==='return-guest')return view('messages');if(a==='end-guest')return endGuest();
 if(a==='request-call')return call('request');if(a==='cancel-call')return call('cancel');if(a==='end-call')return call('end');
 if(a==='accept-call')return mutate(async()=>{await post('/calls/accept');await refreshCall();await ensurePeer();S.localAccepted=true;notice('Call accepted. Waiting for patient to join audio.');});
 if(a==='ready-audio')return readyAudio();
});
app.addEventListener('submit',e=>{e.preventDefault();if(e.target.id==='authForm')submitAuth(e.target);if(e.target.id==='messageForm')sendMessage(e.target);});
app.addEventListener('input',e=>{
 if(e.target.id==='messageText'){
  const convo=document.getElementById('messageForm')?.dataset.conversationId;
  if(convo)S.drafts[convo]=e.target.value;
  const count=document.getElementById('draftCount');if(count)count.textContent=e.target.value.length+'/3000';
 }
 if(e.target.id==='conversationSearch'){
  S.conversationSearch=e.target.value;
  render();
 }
});
app.addEventListener('change',e=>{if(e.target.id==='imageUpload')uploadImage(e.target.files?.[0]);});
async function initialize(){try{const me=await api('/me');S.actor=me.actor;S.siteKey=me.turnstileSiteKey;S.view=S.actor?(S.actor.role==='admin'?'admin':S.actor.role==='visitor'?'messages':'home'):'welcome';S.mobileThreadOpen=S.actor?.role==='visitor';render();if(S.actor){await refreshConversations();await refreshCall();connectRealtime();}}catch(e){render();notice('The service is temporarily unavailable. Please try again.');}}
// State is refreshed even when WebSocket notifications are interrupted.
setInterval(()=>{if(S.actor){if(S.view==='messages'||S.view==='admin')refreshConversations();if(S.view==='calls'||S.view==='admin')refreshCall();}},9000);
initialize();
