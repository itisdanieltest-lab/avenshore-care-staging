export async function callIceConfig(env,fetcher=fetch){
 const fallback={iceServers:[{urls:'stun:stun.cloudflare.com:3478'}],relayConfigured:false,expiresIn:3600};
 if(!env.CF_TURN_KEY_ID||!env.CF_TURN_API_TOKEN)return fallback;
 if(!/^[a-zA-Z0-9_-]+$/.test(env.CF_TURN_KEY_ID))throw new Error('Call relay configuration is invalid');
 const response=await fetcher(`https://rtc.live.cloudflare.com/v1/turn/keys/${env.CF_TURN_KEY_ID}/credentials/generate-ice-servers`,{method:'POST',headers:{authorization:`Bearer ${env.CF_TURN_API_TOKEN}`,'content-type':'application/json'},body:JSON.stringify({ttl:3600}),signal:AbortSignal.timeout(8000)});
 if(!response.ok)throw new Error('Call relay is temporarily unavailable. Please try again.');
 const data=await response.json();
 const servers=(Array.isArray(data.iceServers)?data.iceServers:[]).slice(0,12).map(s=>({urls:(Array.isArray(s.urls)?s.urls:[s.urls]).filter(u=>typeof u==='string'&&/^(stun:|turn:|turns:)/.test(u)&&!/:53(?:\?|$)/.test(u)),...(typeof s.username==='string'?{username:s.username}:{}),...(typeof s.credential==='string'?{credential:s.credential}:{})})).filter(s=>s.urls.length);
 if(!servers.some(s=>s.urls.some(u=>/^turns?:/.test(u))&&s.username&&s.credential))throw new Error('Call relay did not provide usable credentials');
 return {iceServers:servers,relayConfigured:true,expiresIn:3600};
}
