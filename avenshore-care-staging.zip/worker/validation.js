export const safeEmail = s => typeof s==='string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s) && s.length<=254;
// Cloudflare Workers currently rejects PBKDF2 iteration counts above 100,000.
// This setting is for synthetic staging accounts; production auth needs a reviewed design.
export const PASSWORD_HASH_ITERATIONS = 100_000;

// Patient sign-in contacts share the existing unique email column for backward compatibility.
// Email addresses are lower-cased; phone numbers are stored in a normalized form.
export function normalizePatientContact(value) {
 if(typeof value!=='string')return null;
 const input=value.trim();
 if(safeEmail(input))return input.toLowerCase();
 let phone=input.replace(/[\s().-]/g,'');
 if(phone.startsWith('00'))phone='+'+phone.slice(2);
 if(!/^\+?\d{7,15}$/.test(phone))return null;
 return phone;
}
