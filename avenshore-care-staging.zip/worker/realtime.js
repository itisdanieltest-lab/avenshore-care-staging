import { DurableObject } from 'cloudflare:workers';
const RING_MS=90000, CONNECT_MS=90000, LOST_MS=60000;
export class RealtimeHub extends DurableObject {
 constructor(ctx,env){super(ctx,env);this.ctx=ctx;}
 async state(){const st=(await this.ctx.storage.get('callState'))||{active:null,queue:[],lastCall:null};if(st.active){st.active.direction=st.active.direction||'inbound';st.active.ringExpiresAt=st.active.ringExpiresAt||(st.active.requestedAt||Date.now())+RING_MS;st.active.ready=st.active.ready||{patient:false,admin:false};st.active.lastSeen=st.active.lastSeen||{};st.active.acceptedAt=st.active.acceptedAt||(st.active.state==='active'?Date.now():null);}return st;}
 async sendEvent(event){for(const socket of this.ctx.getWebSockets()){const c=socket.deserializeAttachment()||{};if(event.type==='message'&&c.role!=='admin'&&!((c.role==='patient'&&c.id===event.patientId)||(c.role==='visitor'&&c.id===event.visitorId)))continue;try{socket.send(JSON.stringify(event));}catch{}}}
 view(st,id,role){const a=st.active;const visible=role==='admin'||a?.patientId===id;const active=visible&&a?{patientId:a.patientId,patientName:a.patientName||'Patient',adminId:a.adminId||null,callId:a.callId,direction:a.direction||'inbound',state:a.state,requestedAt:a.requestedAt,acceptedAt:a.acceptedAt||null,ringExpiresAt:a.ringExpiresAt,ready:{patient:!!a.ready?.patient,admin:!!a.ready?.admin}}:null;const last=st.lastCall;return {active,position:role==='admin'?undefined:(st.queue.findIndex(q=>q.patientId===id)<0?null:st.queue.findIndex(q=>q.patientId===id)+1),busy:!!a,queue:role==='admin'?st.queue.map(q=>({patientId:q.patientId,patientName:q.patientName||'Patient',callId:q.callId,requestedAt:q.requestedAt})):undefined,lastCall:last&&(role==='admin'||last.patientId===id)?last:null};}
 async broadcastCalls(st){st=st||await this.state();for(const socket of this.ctx.getWebSockets()){const c=socket.deserializeAttachment()||{};if(!['admin','patient'].includes(c.role))continue;try{socket.send(JSON.stringify({type:'calls',...this.view(st,c.id,c.role)}));}catch{}}}
 promote(st,reason){if(st.active)st.lastCall={callId:st.active.callId,patientId:st.active.patientId,reason,endedAt:Date.now()};st.active=st.queue.shift()||null;if(st.active){st.active.state='ringing';st.active.direction='inbound';st.active.ringExpiresAt=Date.now()+RING_MS;st.active.ready={patient:false,admin:false};st.active.lastSeen={};}}
 async persist(st,broadcast=true){await this.ctx.storage.put('callState',st);if(st.active){const a=st.active;const deadline=a.state==='ringing'?a.ringExpiresAt:!(a.ready?.patient&&a.ready?.admin)?a.acceptedAt+CONNECT_MS:Math.min(a.lastSeen?.patient||Date.now(),a.lastSeen?.admin||Date.now())+LOST_MS;await this.ctx.storage.setAlarm(Math.max(Date.now()+1000,deadline));}else await this.ctx.storage.deleteAlarm();if(broadcast)await this.broadcastCalls(st);}
 async alarm(){await this.ctx.blockConcurrencyWhile(async()=>{const st=await this.state(),a=st.active;if(!a)return;const n=Date.now();if(a.state==='ringing'&&n>=a.ringExpiresAt)this.promote(st,'unanswered');else if(a.state==='active'&&(!(a.ready?.patient&&a.ready?.admin)?n>=a.acceptedAt+CONNECT_MS:n-Math.min(a.lastSeen?.patient||a.acceptedAt,a.lastSeen?.admin||a.acceptedAt)>=LOST_MS))this.promote(st,'disconnected');await this.persist(st);});}
 async fetch(request){const p=new URL(request.url).pathname;
  if(p==='/events'){if((request.headers.get('upgrade')||'').toLowerCase()!=='websocket')return new Response('Upgrade required',{status:426});const id=request.headers.get('x-actor-id'),role=request.headers.get('x-actor-role');if(!id||!['patient','admin','visitor'].includes(role))return this.respond({error:'Forbidden'},403);const pair=new WebSocketPair(),[client,server]=Object.values(pair);this.ctx.acceptWebSocket(server);server.serializeAttachment({id,role});server.send(JSON.stringify({type:'connected'}));return new Response(null,{status:101,webSocket:client});}
  if(p==='/notify'&&request.method==='POST'){const event=await request.json();if(event.type==='message')await this.sendEvent(event);return this.respond({});}
  const id=request.headers.get('x-actor-id'),role=request.headers.get('x-actor-role');if(!id||!['patient','admin'].includes(role))return this.respond({error:'Forbidden'},403);
  if(p==='/calls'&&request.method==='GET')return this.ctx.blockConcurrencyWhile(async()=>{const st=await this.state();if(st.active)await this.persist(st,false);return this.respond(this.view(st,id,role));});
  if(request.method!=='POST'||!['request','dial','cancel','accept','decline','ready','heartbeat','end'].some(x=>p==='/calls/'+x))return this.respond({error:'Not found'},404);
  let d;try{d=await request.json();}catch{d={};}
  return this.ctx.blockConcurrencyWhile(async()=>{const st=await this.state(),a=st.active;const recipient=a&&((a.direction||'inbound')==='outbound'?role==='patient'&&id===a.patientId:role==='admin');
   if(p==='/calls/request'){
    if(role!=='patient')return this.respond({error:'Only patients may join the queue'},403);
    if(a?.patientId===id||st.queue.some(q=>q.patientId===id))return this.respond({ok:true,...this.view(st,id,role)});
    if(st.queue.length>=100)return this.respond({error:'The queue is full. Please send a message.'},429);
    const q={patientId:id,patientName:d.patientName||'Patient',callId:crypto.randomUUID(),direction:'inbound',state:'ringing',requestedAt:Date.now(),ringExpiresAt:Date.now()+RING_MS,ready:{patient:false,admin:false},lastSeen:{}};
    if(a)st.queue.push(q);else st.active=q;
   }else if(p==='/calls/dial'){
    if(role!=='admin')return this.respond({error:'Administrator only'},403);
    if(a||st.queue.length)return this.respond({error:'Finish the current call and waiting queue first'},409);
    if(typeof d.patientId!=='string'||!d.patientId)return this.respond({error:'Select a patient'},400);
    st.active={patientId:d.patientId,patientName:d.patientName||'Patient',adminId:id,callId:crypto.randomUUID(),direction:'outbound',state:'ringing',requestedAt:Date.now(),ringExpiresAt:Date.now()+RING_MS,ready:{patient:false,admin:false},lastSeen:{}};
   }else if(p==='/calls/cancel'&&role==='patient'&&a?.patientId!==id){st.queue=st.queue.filter(q=>q.patientId!==id);
   }else{
    if(!a||a.callId!==d.callId)return this.respond({error:'This call has ended. Refresh the call controls.'},409);
    if(role!=='admin'&&a.patientId!==id)return this.respond({error:'Forbidden'},403);
    if(role==='admin'&&a.adminId&&a.adminId!==id)return this.respond({error:'Forbidden'},403);
    if(p==='/calls/accept'){if(!recipient||a.state!=='ringing')return this.respond({error:'Only the receiving person can accept this call'},403);a.adminId=role==='admin'?id:a.adminId;a.state='active';a.acceptedAt=Date.now();a.lastSeen={};}
    else if(p==='/calls/decline'){if(!recipient||a.state!=='ringing')return this.respond({error:'Only the receiving person can decline'},403);this.promote(st,'declined');}
    else if(p==='/calls/ready'||p==='/calls/heartbeat'){if(a.state!=='active')return this.respond({error:'Accept the call first'},409);a.ready=a.ready||{};a.lastSeen=a.lastSeen||{};if(p==='/calls/ready'){a.ready[role]=true;if(role==='admin'&&!a.adminId)a.adminId=id;}a.lastSeen[role]=Date.now();}
    else if(p==='/calls/cancel'){if(role!=='patient')return this.respond({error:'Patient only'},403);this.promote(st,'cancelled');}
    else if(p==='/calls/end')this.promote(st,'ended');
   }
   await this.persist(st,p!=='/calls/heartbeat');return this.respond({ok:true,...this.view(st,id,role)});
  });
 }
 respond(body,status=200){return new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});}
 async webSocketMessage(ws,message){if(typeof message!=='string'||message.length>16000)return;let obj;try{obj=JSON.parse(message);}catch{return;}if(obj.type!=='signal'||!['offer','answer','candidate','restart'].includes(obj.kind)||typeof obj.data!=='object'||obj.data===null||JSON.stringify(obj.data).length>12000)return;const sender=ws.deserializeAttachment()||{},a=(await this.state()).active;if(!a||a.state!=='active'||obj.callId!==a.callId||!a.ready?.patient||!a.ready?.admin)return;if(sender.role==='admin'?sender.id!==a.adminId:sender.role!=='patient'||sender.id!==a.patientId)return;if(sender.role==='admin'&&obj.kind==='offer'||sender.role==='patient'&&['answer','restart'].includes(obj.kind))return;for(const socket of this.ctx.getWebSockets()){const other=socket.deserializeAttachment()||{};if(other.role===sender.role)continue;if(!(other.role==='admin'&&other.id===a.adminId||other.role==='patient'&&other.id===a.patientId))continue;try{socket.send(JSON.stringify({type:'signal',kind:obj.kind,callId:a.callId,data:obj.data}));}catch{}}}
 async webSocketClose(ws,code,reason){try{ws.close(code,reason);}catch{}}
}
