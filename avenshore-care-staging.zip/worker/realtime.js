import { DurableObject } from 'cloudflare:workers';

// Single Durable Object per clinic: serializes the single-admin call queue.
// Durable Object storage persists queue, while WebSockets provide live signaling.
export class RealtimeHub extends DurableObject {
  constructor(ctx,env) { super(ctx,env); this.ctx=ctx; }
  async state(){return (await this.ctx.storage.get('callState'))||{active:null,queue:[]};}
  async sendEvent(event){
   const text=JSON.stringify(event);
   for(const socket of this.ctx.getWebSockets()){
    const c=socket.deserializeAttachment()||{};
    if(event.type==='message' && c.role!=='admin' && !((c.role==='patient'&&c.id===event.patientId)||(c.role==='visitor'&&c.id===event.visitorId)))continue;
    if(event.type==='calls' && c.role!=='admin' && c.id!==event.patientId)continue;
    try{socket.send(text);}catch{}
   }
  }
  async broadcastCalls(){
   const st=await this.state();
   for(const socket of this.ctx.getWebSockets()){
    const c=socket.deserializeAttachment()||{};
    if(c.role==='visitor')continue;
    const personal=this.view(st,c.id,c.role);
    try{socket.send(JSON.stringify({type:'calls',...personal}));}catch{}
   }
  }
  view(st,id,role){
   if(role==='admin')return {active:st.active,queue:st.queue};
   const q=st.queue.findIndex(x=>x.patientId===id);
   return {active:st.active?.patientId===id?st.active:null,position:q<0?null:q+1,busy:!!st.active};
  }
  async fetch(request){
   const url=new URL(request.url), p=url.pathname;
   if(p==='/events'){
    if((request.headers.get('upgrade')||'').toLowerCase()!=='websocket')return new Response('Upgrade required',{status:426});
    const id=request.headers.get('x-actor-id'),role=request.headers.get('x-actor-role');
    if(!id||!['admin','patient','visitor'].includes(role))return new Response('Forbidden',{status:403});
    const pair=new WebSocketPair(), [client,server]=Object.values(pair);
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({id,role});
    server.send(JSON.stringify({type:'connected'}));
    return new Response(null,{status:101,webSocket:client});
   }
   if(p==='/notify'&&request.method==='POST'){
    const event=await request.json();
    if(event.type==='message')await this.sendEvent(event);
    return new Response('{}',{headers:{'content-type':'application/json'}});
   }
   const id=request.headers.get('x-actor-id'),role=request.headers.get('x-actor-role');
   if(!id||!['patient','admin'].includes(role))return this.respond({error:'Forbidden'},403);
   if(p==='/calls'&&request.method==='GET')return this.respond(this.view(await this.state(),id,role));
   if(!['/calls/request','/calls/cancel','/calls/accept','/calls/end'].includes(p)||request.method!=='POST')return this.respond({error:'Not found'},404);
   // Ensure storage read, mutation, and write are serialized even with concurrent requests.
   return await this.ctx.blockConcurrencyWhile(async()=>{
    const st=await this.state();let res={ok:true};
    if(p==='/calls/request'){
     if(role!=='patient')return this.respond({error:'Only patients may request calls'},403);
     if(st.active?.patientId===id)res={ok:true,already:true};
     else if(st.queue.some(x=>x.patientId===id))res={ok:true,already:true};
     else {
      const req={patientId:id,callId:crypto.randomUUID(),requestedAt:Date.now(),state:'ringing'};
      if(st.active)st.queue.push(req);else st.active=req;
     }
    }
    if(p==='/calls/cancel'){
     if(role!=='patient')return this.respond({error:'Only patients can cancel their own requests'},403);
     if(st.active?.patientId===id){st.active=st.queue.shift()||null;}
     else st.queue=st.queue.filter(x=>x.patientId!==id);
    }
    if(p==='/calls/accept'){
     if(role!=='admin')return this.respond({error:'Administrator only'},403);
     if(!st.active||st.active.state!=='ringing')return this.respond({error:'No waiting incoming call'},409);
     st.active.state='active';st.active.acceptedAt=Date.now();
    }
    if(p==='/calls/end'){
     if(!st.active)return this.respond({error:'No active call'},409);
     if(role!=='admin'&&st.active.patientId!==id)return this.respond({error:'Forbidden'},403);
     st.active=st.queue.shift()||null;
    }
    await this.ctx.storage.put('callState',st);
    await this.broadcastCalls();
    return this.respond({...res,...this.view(st,id,role)});
   });
  }
  respond(body,status=200){return new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});}
  async webSocketMessage(ws,message){
   if(typeof message!=='string'||message.length>16000)return;
   let obj;try{obj=JSON.parse(message);}catch{return;}
   if(!obj||obj.type!=='signal'||!['offer','answer','candidate'].includes(obj.kind))return;
   const sender=ws.deserializeAttachment()||{},st=await this.state();
   const active=st.active;
   if(!active||active.state!=='active'||obj.callId!==active.callId)return;
   if(sender.role!=='admin'&&sender.id!==active.patientId)return;
   if(sender.role==='admin'&&obj.kind==='offer')return;
   if(sender.role==='patient'&&obj.kind==='answer')return;
   if(typeof obj.data!=='object'||obj.data===null||JSON.stringify(obj.data).length>12000)return;
   for(const socket of this.ctx.getWebSockets()){
    const other=socket.deserializeAttachment()||{};
    if(other.role===sender.role)continue;
    if(!(other.role==='admin'||(other.role==='patient'&&other.id===active.patientId)))continue;
    try{socket.send(JSON.stringify({type:'signal',kind:obj.kind,callId:active.callId,data:obj.data}));}catch{}
   }
  }
  async webSocketClose(ws,code,reason){try{ws.close(code,reason);}catch{}}
}
