export const MAX_PROFILE_BYTES=96*1024;
export const profilePhotoUrl=(id,version)=>version?`/api/profile-photos/${encodeURIComponent(id)}?v=${encodeURIComponent(version)}`:null;
// Keep only JPEG image segments. Strip application metadata (EXIF/GPS/etc.) and comments.
export function cleanProfileJpeg(input){
 const b=new Uint8Array(input);if(b.length>MAX_PROFILE_BYTES)throw new Error('Profile photo is too large');
 if(b.length<20||b[0]!==255||b[1]!==216||b.at(-2)!==255||b.at(-1)!==217)throw new Error('Choose a valid JPEG photo');
 const parts=[b.slice(0,2)];let offset=2,dimensions=false,scan=false;
 while(offset<b.length-2){
  const start=offset;if(b[offset++]!==255)throw new Error('Choose a valid JPEG photo');
  while(b[offset]===255)offset++;const marker=b[offset++];
  if(marker===0||marker===216||marker===217||offset+2>b.length)throw new Error('Choose a valid JPEG photo');
  const length=(b[offset]<<8)|b[offset+1];if(length<2||offset+length>b.length)throw new Error('Choose a valid JPEG photo');
  if([192,193,194].includes(marker)){
   if(length<8)throw new Error('Choose a valid JPEG photo');
   const height=(b[offset+3]<<8)|b[offset+4],width=(b[offset+5]<<8)|b[offset+6];
   if(!height||!width||height>256||width>256)throw new Error('Profile photos must be 256 pixels or smaller');dimensions=true;
  }
  if(marker===218){if(!dimensions)throw new Error('Choose a valid JPEG photo');parts.push(b.slice(start));scan=true;break;}
  if(!(marker>=224&&marker<=239)&&marker!==254)parts.push(b.slice(start,offset+length));
  offset+=length;
 }
 if(!scan)throw new Error('Choose a valid JPEG photo');
 const out=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let pos=0;for(const p of parts){out.set(p,pos);pos+=p.length;}return out;
}
export async function readProfileBody(request){
 if(Number(request.headers.get('content-length'))>MAX_PROFILE_BYTES)throw new Error('Profile photo is too large');
 if(!request.body)throw new Error('Choose a photo');
 const reader=request.body.getReader(),parts=[];let total=0;
 try{for(;;){const {value,done}=await reader.read();if(done)break;total+=value.length;if(total>MAX_PROFILE_BYTES){await reader.cancel();throw new Error('Profile photo is too large');}parts.push(value);}}finally{reader.releaseLock();}
 const body=new Uint8Array(total);let offset=0;for(const p of parts){body.set(p,offset);offset+=p.length;}return body;
}
