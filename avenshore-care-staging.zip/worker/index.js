import { RealtimeHub } from './realtime.js';
export { RealtimeHub };

const now = () => Date.now();
const json = (value, status=200, headers={}) => new Response(JSON.stringify(value), {
  status, headers: { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'x-content-type-options':'nosniff', 'referrer-policy':'no-referrer', ...headers }
});
const error = (message, status=400) => json({error:message},status);
const bytesHex = b => Array.from(new Uint8Array(b)).map(v=>v.toString(16).padStart(2,'0')).join('');
const bytesFromHex = s => Uint8Array.from(s.match(/.{2}/g) ?? [], n=>parseInt(n,16));
const digest = async s => bytesHex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
const randomToken = () => bytesHex(crypto.getRandomValues(new Uint8Array(32)));
export const safeName = s => typeof s==='string' && s.trim().length>=2 && s.trim().length<=90 && !/[<>]/.test(s);
export const safeEmail = s => typeof s==='string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s) && s.length<=254;
export function fixedTimeEqual(a,b) { if(typeof a!=='string'||typeof b!=='string')return false; const x=new TextEncoder().encode(a),y=new TextEncoder().encode(b);let v=x.length^y.length;for(let i=0;i<Math.max(x.length,y.length);i++)v|=(x[i]||0)^(y[i]||0);return v===0; }
export async function hashPassword(pass,saltHex) {
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(pass),'PBKDF2',false,['deriveBits']);
  return bytesHex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',iterations:600000,salt:bytesFromHex(saltHex)},key,256));
}
const parseCookies = h => Object.fromEntries((h||'').split(';').map(x=>x.trim().split(/=(.*)/s).slice(0,2)).filter(([k])=>k));
const sessionName = url => url.protocol==='https:'?'__Host-av_session':'av_session';
const guestName = url => url.protocol==='https:'?'__Host-av_guest':'av_guest';
const cookie = (key,val,url,age) => `${key}=${val}; Path=/; Max-Age=${age}; HttpOnly; SameSite=Strict${url.protocol==='https:'?'; Secure':''}`;
const clearCookie = (key,url) => cookie(key,'',url,0);
export function imageMimeMatches(bytes,mime) {
 const b=new Uint8Array(bytes);
 if(mime==='image/png')return b.length>=8&&[137,80,78,71,13,10,26,10].every((v,i)=>b[i]===v);
 if(mime==='image/jpeg')return b.length>=4&&b[0]===255&&b[1]===216&&b[2]===255;
 if(mime==='image/webp')return b.length>=12&&String.fromCharCode(...b.slice(0,4))==='RIFF'&&String.fromCharCode(...b.slice(8,12))==='WEBP';
 return false;
}
async function requestJson(request,limit=16000){const t=await request.text();if(t.length>limit)throw new Error('Request too large');try{return JSON.parse(t);}catch{throw new Error('Invalid JSON');}}
function sameOrigin(request){const origin=request.headers.get('origin');const url=new URL(request.url);return !!origin&&origin===url.origin;}
async function checkChallenge(data,request,env){
 // Public authentication and visitor entry must fail closed in deployed environments.
 // The isolated test harness opts into its local-only bypass explicitly.
 if(env.LOCAL_QA===true&&!env.TURNSTILE_SECRET&&!env.TURNSTILE_SITE_KEY)return true;
 if(!env.TURNSTILE_SECRET||!env.TURNSTILE_SITE_KEY)return null;
 if(!data.turnstileToken)return false;
 const fd=new FormData();fd.append('secret',env.TURNSTILE_SECRET);fd.append('response',data.turnstileToken);
 const ip=request.headers.get('cf-connecting-ip');if(ip)fd.append('remoteip',ip);
 const r=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body:fd});
 return r.ok&&(await r.json()).success===true;
}
async function throttle(env,scope,request,limit,windowMs){
 const ip=request.headers.get('cf-connecting-ip') || 'local';
 const key=await digest(scope+':'+ip);
 const n=now(), end=n+windowMs;
 await env.DB.prepare(`INSERT INTO throttles (key,count,window_ends_at) VALUES(?,1,?)
   ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window_ends_at<? THEN 1 ELSE count+1 END,
   window_ends_at=CASE WHEN window_ends_at<? THEN ? ELSE window_ends_at END`).bind(key,end,n,n,end).run();
 const row=await env.DB.prepare('SELECT count FROM throttles WHERE key=?').bind(key).first();
 return row.count<=limit;
}
async function getActor(request,env,url){
 const c=parseCookies(request.headers.get('cookie'));
 for(const n of ['__Host-av_session','av_session'])if(c[n]){
  const tokenHash=await digest(c[n]);
  const u=await env.DB.prepare(`SELECT u.id,u.email,u.full_name,u.role FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=? AND s.expires_at>? AND u.disabled_at IS NULL`).bind(tokenHash,now()).first();
  if(u)return {id:u.id,role:u.role,name:u.full_name,email:u.email};
 }
 for(const n of ['__Host-av_guest','av_guest'])if(c[n]){
  const visitor=await env.DB.prepare('SELECT id FROM visitors WHERE token_hash=? AND expires_at>?').bind(await digest(c[n]),now()).first();
  if(visitor)return {id:visitor.id,role:'visitor',name:'Website visitor'};
 }
 return null;
}
const actorRequired = a => !a?error('Sign in is required',401):null;
const isAdmin = a => a?.role==='admin';
function authorized(a,c) {return isAdmin(a)||(a?.role==='patient'&&c.patient_id===a.id)||(a?.role==='visitor'&&c.visitor_id===a.id);}
async function getConversation(env,id){return await env.DB.prepare('SELECT * FROM conversations WHERE id=?').bind(id).first();}
async function pubEvent(env,msg){try{await env.REALTIME.getByName('global').fetch('https://internal/notify',{method:'POST',body:JSON.stringify(msg)});}catch{/* client polling is fallback */}}
async function callEndpoint(env,a,path,method){
 const res=await env.REALTIME.getByName('global').fetch('https://internal'+path,{method,
 headers:{'x-actor-id':a.id,'x-actor-role':a.role}});
 return json(await res.json(),res.status);
}
async function handleApi(request,env,ctx,url){
 const p=url.pathname, method=request.method;
 if(['POST','PUT','PATCH','DELETE'].includes(method)&&!sameOrigin(request))return error('Same-origin request required',403);
 if(p==='/api/status'&&method==='GET')return json({status:'ok',service:'Avenshore Care',version:'0.9.0'});
 let a;
 if(p==='/api/auth/register'&&method==='POST'){
  if(!await throttle(env,'register',request,7,3600000))return error('Please try again later',429);
  const d=await requestJson(request),challenge=await checkChallenge(d,request,env);if(challenge===null)return error('Account protection is not configured',503);if(!challenge)return error('Verification required',403);
  if(!safeName(d.name)||!safeEmail(d.email)||typeof d.password!=='string'||d.password.length<12||d.password.length>128)return error('Provide your full name, valid email, and a password of at least 12 characters');
  const id=crypto.randomUUID(),salt=bytesHex(crypto.getRandomValues(new Uint8Array(16))),ph=await hashPassword(d.password,salt);
  try {await env.DB.prepare('INSERT INTO users(id,email,full_name,password_salt,password_hash,role,created_at) VALUES(?,?,?,?,?,?,?)').bind(id,d.email.trim().toLowerCase(),d.name.trim(),salt,ph,'patient',now()).run();}
  catch{return error('Unable to register with these details',409);}
  await env.DB.prepare('INSERT INTO conversations(id,patient_id,kind,created_at,updated_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),id,'care',now(),now()).run();
  const t=randomToken();await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').bind(await digest(t),id,now()+604800000,now()).run();
  return json({ok:true,actor:{id,role:'patient',name:d.name.trim()}},201,{'set-cookie':cookie(sessionName(url),t,url,604800)});
 }
 if(p==='/api/setup/admin'&&method==='POST'){
  if(!env.ADMIN_SETUP_TOKEN||env.ADMIN_SETUP_TOKEN.length<32)return error('Admin bootstrap is disabled or not configured',503);
  if(!await throttle(env,'setup',request,5,3600000))return error('Too many attempts',429);
  if(!fixedTimeEqual(request.headers.get('x-admin-setup-token')||'',env.ADMIN_SETUP_TOKEN))return error('Forbidden',403);
  const d=await requestJson(request);if(!safeName(d.name)||!safeEmail(d.email)||typeof d.password!=='string'||d.password.length<16||d.password.length>128)return error('Admin requires full name, valid email and a password of at least 16 characters');
  const existing=await env.DB.prepare("SELECT id FROM users WHERE role='admin'").first();if(existing)return error('Administrator already exists',409);
  const id=crypto.randomUUID(),salt=bytesHex(crypto.getRandomValues(new Uint8Array(16))),ph=await hashPassword(d.password,salt);
  try{await env.DB.prepare('INSERT INTO users(id,email,full_name,password_salt,password_hash,role,created_at) VALUES(?,?,?,?,?,?,?)').bind(id,d.email.trim().toLowerCase(),d.name.trim(),salt,ph,'admin',now()).run();}
  catch{return error('Unable to create administrator',409);}
  return json({ok:true,notice:'Remove ADMIN_SETUP_TOKEN from the Worker secrets after creating the administrator'},201);
 }
 if(p==='/api/auth/login'&&method==='POST'){
  if(!await throttle(env,'login',request,12,900000))return error('Too many attempts. Try again later',429);
  const d=await requestJson(request),challenge=await checkChallenge(d,request,env);if(challenge===null)return error('Account protection is not configured',503);if(!challenge)return error('Verification required',403);
  if(!safeEmail(d.email)||typeof d.password!=='string')return error('Invalid credentials',401);
  const u=await env.DB.prepare('SELECT * FROM users WHERE email=? AND disabled_at IS NULL').bind(d.email.toLowerCase().trim()).first();
  if(!u)return error('Invalid credentials',401);
  const actual=await hashPassword(d.password,u.password_salt);if(!fixedTimeEqual(actual,u.password_hash))return error('Invalid credentials',401);
  const t=randomToken();await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').bind(await digest(t),u.id,now()+604800000,now()).run();
  return json({ok:true,actor:{id:u.id,role:u.role,name:u.full_name}},200,{'set-cookie':cookie(sessionName(url),t,url,604800)});
 }
 if(p==='/api/auth/logout'&&method==='POST'){
  const c=parseCookies(request.headers.get('cookie'));const t=c.__Host-av_session||c.av_session;
  if(t)await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await digest(t)).run();
  return json({ok:true},200,{'set-cookie':clearCookie(sessionName(url),url)});
 }
 if(p==='/api/guest/end'&&method==='POST')return json({ok:true},200,{'set-cookie':clearCookie(guestName(url),url)});
 if(p==='/api/guest/start'&&method==='POST'){
  if(!await throttle(env,'guest',request,10,3600000))return error('Too many requests',429);
  const d=await requestJson(request),challenge=await checkChallenge(d,request,env);if(challenge===null)return error('Account protection is not configured',503);if(!challenge)return error('Verification required',403);
  const token=randomToken(),id=crypto.randomUUID(),convo=crypto.randomUUID(),time=now();
  await env.DB.prepare('INSERT INTO visitors(id,token_hash,created_at,expires_at) VALUES(?,?,?,?)').bind(id,await digest(token),time,time+86400000).run();
  await env.DB.prepare('INSERT INTO conversations(id,visitor_id,kind,created_at,updated_at) VALUES(?,?,?,?,?)').bind(convo,id,'site-help',time,time).run();
  return json({id:convo,kind:'site-help'},201,{'set-cookie':cookie(guestName(url),token,url,86400)});
 }
 a=await getActor(request,env,url);
 if(p==='/api/me'&&method==='GET')return json({actor:a?{id:a.id,role:a.role,name:a.name,email:a.email}:null,turnstileSiteKey:env.TURNSTILE_SITE_KEY||null});
 if(!a)return actorRequired(a);
 if(p==='/api/conversations'&&method==='GET'){
  let rows;
  if(isAdmin(a))rows=await env.DB.prepare(`SELECT c.*,COALESCE(u.full_name,'Website visitor') AS display_name,
   (SELECT content FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) AS last_message
   FROM conversations c LEFT JOIN users u ON c.patient_id=u.id ORDER BY c.updated_at DESC LIMIT 100`).all();
  else rows=await env.DB.prepare(`SELECT c.*,? AS display_name,
   (SELECT content FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) AS last_message
   FROM conversations c WHERE ${a.role==='patient'?'c.patient_id':'c.visitor_id'}=?`).bind(a.name,a.id).all();
  return json({conversations:rows.results});
 }
 const match=p.match(/^\/api\/conversations\/([a-z0-9-]+)\/(messages|attachments)$/);
 if(match){
  const conv=await getConversation(env,match[1]);if(!conv||!authorized(a,conv))return error('Conversation not found',404);
  if(match[2]==='messages'&&method==='GET'){
   const msgs=await env.DB.prepare(`SELECT id,sender_type,content,attachment_id,created_at FROM messages WHERE conversation_id=? ORDER BY created_at DESC,id DESC LIMIT 100`).bind(conv.id).all();
   return json({messages:msgs.results.reverse(),kind:conv.kind});
  }
  if(match[2]==='messages'&&method==='POST'){
   if(!await throttle(env,`msg:${a.id}`,request,180,3600000))return error('Too many messages',429);
   const d=await requestJson(request,9000);if(typeof d.content!=='string'||d.content.trim().length<1||d.content.length>3000)return error('Message must contain 1 to 3000 characters');
   const id=crypto.randomUUID(),time=now(), sender=a.role;
   await env.DB.prepare('INSERT INTO messages(id,conversation_id,sender_type,sender_id,content,created_at) VALUES(?,?,?,?,?,?)').bind(id,conv.id,sender,a.id,d.content.trim(),time).run();
   await env.DB.prepare('UPDATE conversations SET updated_at=? WHERE id=?').bind(time,conv.id).run();
   await pubEvent(env,{type:'message',conversationId:conv.id,patientId:conv.patient_id,visitorId:conv.visitor_id});
   return json({id,created_at:time},201);
  }
  if(match[2]==='attachments'&&method==='POST'){
   if(conv.kind==='site-help')return error('Image sharing is only available in signed-in patient conversations',403);
   if(a.role==='visitor')return error('Sign in to share medical images',403);
   if(!env.UPLOADS)return error('Photo uploads are not enabled on this staging site yet',503);
   if(!await throttle(env,`upload:${a.id}`,request,30,3600000))return error('Upload limit reached',429);
   const len=Number(request.headers.get('content-length')||0);if(len>5*1024*1024)return error('File must be at most 5 MB',413);
   const mime=(request.headers.get('content-type')||'').split(';')[0].toLowerCase();
   if(!['image/png','image/jpeg','image/webp'].includes(mime))return error('Only PNG, JPEG and WebP images are accepted',415);
   const buffer=await request.arrayBuffer();if(!buffer.byteLength||buffer.byteLength>5*1024*1024)return error('File must be 1 byte to 5 MB',413);
   if(!imageMimeMatches(buffer,mime))return error('Image content did not match file type',415);
   const id=crypto.randomUUID(),key=`private/${conv.id}/${id}`,time=now();
   await env.UPLOADS.put(key,buffer,{httpMetadata:{contentType:mime}});
   await env.DB.prepare('INSERT INTO attachments(id,conversation_id,uploader_id,key,mime,size,created_at) VALUES(?,?,?,?,?,?,?)').bind(id,conv.id,a.id,key,mime,buffer.byteLength,time).run();
   await env.DB.prepare('INSERT INTO messages(id,conversation_id,sender_type,sender_id,attachment_id,created_at) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),conv.id,a.role,a.id,id,time).run();
   await env.DB.prepare('UPDATE conversations SET updated_at=? WHERE id=?').bind(time,conv.id).run();
   await pubEvent(env,{type:'message',conversationId:conv.id,patientId:conv.patient_id,visitorId:conv.visitor_id});
   return json({id,created_at:time},201);
  }
 }
 const fileMatch=p.match(/^\/api\/attachments\/([a-z0-9-]+)$/);
 if(fileMatch&&method==='GET'){
  const att=await env.DB.prepare('SELECT * FROM attachments WHERE id=?').bind(fileMatch[1]).first();
  if(!att)return error('Not found',404);
  const conv=await getConversation(env,att.conversation_id);if(!conv||!authorized(a,conv))return error('Not found',404);
  if(!env.UPLOADS)return error('Photo uploads are not enabled on this staging site yet',503);
  const object=await env.UPLOADS.get(att.key);if(!object)return error('Not found',404);
  return new Response(object.body,{headers:{'content-type':att.mime,'content-disposition':'inline','cache-control':'private, no-store','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'; sandbox"}});
 }
 if(p==='/api/events'&&method==='GET'){
  if((request.headers.get('upgrade')||'').toLowerCase()!=='websocket')return error('WebSocket upgrade required',426);
  const h=new Headers(request.headers);h.set('x-actor-id',a.id);h.set('x-actor-role',a.role);
  return env.REALTIME.getByName('global').fetch(new Request('https://internal/events',{headers:h}));
 }
 if(p.startsWith('/api/calls')){
  if(a.role==='visitor')return error('Voice calls require a patient account',403);
  const kind=p.replace('/api/calls','');
  if(kind===''&&method==='GET')return await callEndpoint(env,a,'/calls','GET');
  if(['/request','/cancel','/accept','/end'].includes(kind)&&method==='POST')return await callEndpoint(env,a,'/calls'+kind,'POST');
 }
 return error('Unknown endpoint',404);
}
export default {
 async fetch(request,env,ctx){
  try{
   const url=new URL(request.url);
   if(url.pathname.startsWith('/api/')){
    if(!env.DB||!env.REALTIME)return error('Backend bindings are not configured',503);
    return await handleApi(request,env,ctx,url);
   }
   return env.ASSETS.fetch(request);
  }catch(e){
   if(env?.LOCAL_QA)console.error('LOCAL QA worker exception:',e);
   // Never expose stack traces, credentials, or patient data.
   const msg=e instanceof Error?e.message:'';
   if(['Invalid JSON','Request too large'].includes(msg))return error(msg,400);
   return error('Request could not be completed. Please try again.',500);
  }
 }
};
