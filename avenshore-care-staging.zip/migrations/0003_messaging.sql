ALTER TABLE messages ADD COLUMN client_message_id TEXT;
ALTER TABLE messages ADD COLUMN edited_at INTEGER;
CREATE UNIQUE INDEX messages_retry_idx ON messages(conversation_id,sender_id,client_message_id);
CREATE TABLE message_edits(id TEXT PRIMARY KEY,message_id TEXT NOT NULL REFERENCES messages(id),previous_content TEXT NOT NULL,edited_at INTEGER NOT NULL);
CREATE TABLE conversation_reads(conversation_id TEXT NOT NULL REFERENCES conversations(id),actor_id TEXT NOT NULL,read_at INTEGER NOT NULL,PRIMARY KEY(conversation_id,actor_id));
ALTER TABLE messages ADD COLUMN reply_to TEXT REFERENCES messages(id);
