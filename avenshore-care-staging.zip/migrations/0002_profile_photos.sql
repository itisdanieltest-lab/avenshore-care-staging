-- Small private account thumbnails, independent of optional R2 chat attachments.
CREATE TABLE IF NOT EXISTS profile_photos (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 content BLOB NOT NULL CHECK(length(content) <= 98304),
 version TEXT NOT NULL,
 updated_at INTEGER NOT NULL
);
