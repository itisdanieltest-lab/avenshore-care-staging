-- Avenshore Care; private patient/visitor conversations; no sample PHI.
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 full_name TEXT NOT NULL,
 password_salt TEXT NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK (role IN ('patient','admin')),
 created_at INTEGER NOT NULL,
 disabled_at INTEGER
);
CREATE UNIQUE INDEX IF NOT EXISTS only_one_admin ON users(role) WHERE role='admin';
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at INTEGER NOT NULL,
 created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS session_user_idx ON sessions(user_id);
CREATE TABLE IF NOT EXISTS visitors (
 id TEXT PRIMARY KEY,
 token_hash TEXT NOT NULL UNIQUE,
 created_at INTEGER NOT NULL,
 expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS conversations (
 id TEXT PRIMARY KEY,
 patient_id TEXT UNIQUE REFERENCES users(id),
 visitor_id TEXT UNIQUE REFERENCES visitors(id),
 kind TEXT NOT NULL CHECK (kind IN ('care','site-help')),
 created_at INTEGER NOT NULL,
 updated_at INTEGER NOT NULL,
 CHECK ((patient_id IS NULL) != (visitor_id IS NULL))
);
CREATE INDEX IF NOT EXISTS conversations_updated_idx ON conversations(updated_at DESC);
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY,
 conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
 sender_type TEXT NOT NULL CHECK (sender_type IN ('patient','admin','visitor')),
 sender_id TEXT NOT NULL,
 content TEXT,
 attachment_id TEXT,
 created_at INTEGER NOT NULL,
 CHECK (content IS NOT NULL OR attachment_id IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS messages_conv_idx ON messages(conversation_id,created_at,id);
CREATE TABLE IF NOT EXISTS attachments (
 id TEXT PRIMARY KEY,
 conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
 uploader_id TEXT NOT NULL,
 key TEXT NOT NULL UNIQUE,
 mime TEXT NOT NULL,
 size INTEGER NOT NULL,
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS throttles (
 key TEXT PRIMARY KEY,
 count INTEGER NOT NULL,
 window_ends_at INTEGER NOT NULL
);
