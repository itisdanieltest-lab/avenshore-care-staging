# Avenshore Care — ChatGPT Work handoff

**Status:** design-refined working front-end with Cloudflare Worker API implementation in this repository. **Not certified or deployed for production use.** Use fictional records for testing.

## Brand

Working name: **Avenshore Care**. Promise: **Care That Stays Close.** Brand colors: deep teal, aqua teal, warm gold, soft ivory. Approved concept board: `docs/approved-brand-board.png`. Operational brand icon: `public/assets/mark.svg`. Trademark/domain clearance is outstanding.

## User journeys

1. Public visitor browses services and can ask registration help without creating a patient account.
2. A patient creates their own account; caregiver proxy accounts are out of scope for v1.
3. Patient views a personal dashboard and sends secure messages/attachments and requests an audio call.
4. A single administrator has a unified conversation inbox and manages one active call with a queued request flow; multiple chats are permitted.
5. Medical emergencies require emergency services; the website must never imply it is an emergency response line.

## Repository

- `public/` — browser interface, visual assets, app logic, core styles, motion styles, and responsive refinement styles.
- `worker/` — Cloudflare Worker API and real-time service.
- `migrations/` — D1 schema.
- `wrangler.jsonc` — starter Cloudflare configuration; replace placeholder resource IDs.
- `tests/render_actual_ui.py` and `tests/visual_qa.py` — actual Chromium rendering with fictional API fixtures.
- `docs/qa/` — captured screenshots and layout results.
- `docs/DESIGN_REVIEW_AFTER.md` — fixes and remaining release blockers.
- `docs/TYPOGRAPHY_AUDIT.md` — original pre-fix review (historical evidence).

## For ChatGPT Work

1. Extract this ZIP and inspect `README.md`, `docs/DESIGN_REVIEW_AFTER.md`, `public/`, `worker/`, and `wrangler.jsonc`.
2. Run source checks (`npm run check`) and the Chromium tests if supported. The present `npm run check` validates JavaScript syntax and runs five Node contract checks; live backend integration is tested separately.
3. Create Cloudflare D1, private R2 bucket, and Durable Object resources and update Wrangler bindings. Establish required environment secrets; never hard-code real passwords or API keys.
4. Exercise the worker locally with a real browser against fake accounts and fake conversations; test registration, login, image authorization, chat, call queue, call-media negotiation, reconnects, and administrator permissions. Repair failures.
5. Perform healthcare-specific security/privacy reviews before connecting real patients, and ensure clinical escalation/privacy policies are approved. Do not declare production readiness based solely on successful UI screenshots.
6. Once the owner approves, deploy via their own Cloudflare account using Wrangler and share the resulting preview URL for acceptance testing. Avoid claiming a temporary preview is suitable for medical records.

Reference inspiration (not copied): https://www.teladochealth.com/individuals/adults. Emphasize unique Avenshore identity and easy access for older adults. No official relationship with Teladoc.

## Latest chat interaction and design review

See **`docs/CHAT_INBOX_DEEP_REVIEW.md`** and the actual Chromium images in `docs/qa/chat-admin-1440.png`, `chat-admin-390.png`, `chat-patient-390.png`.

This revision restores the missing `chat-premium.css`, corrects composer obstruction on mobile, preserves unsent drafts during refresh, prevents stale-thread responses, makes the image picker keyboard accessible, and repairs the admin mobile handoff and patient message preview. The browser screenshots use fictional API responses; they do not certify live backend security or production readiness.

Quick checks:

```sh
npm run check
python tests/chat_deep_qa.py
python tests/visual_qa.py
```


## November 2026 whole-platform design refinement
All public, registration, patient, messaging, calls, account and staff screens now share `public/design-system-v2.css`. See `docs/WHOLE_PLATFORM_DESIGN_V2.md`, the 70-screen browser matrix `docs/qa/full-surface-v2/results.json` and the separate 42-check local Worker/SQLite integration report in `docs/qa/real-integration/results.json`. The project remains staging-only until Cloudflare and security verification is complete.

## V3 premium product and visitor-support audit (current)

Read `docs/PREMIUM_PRODUCT_AUDIT_V3.md` **before deployment**. This revision adds immediate, nonclinical support chat on public pages; corrects the visitor chat's mobile thread, copy, and composer; removes patient-only functions in website-help conversations; and makes the Worker reject site-help photo uploads. The redesigned visitor/staff exchange passed **24/24** local original-Worker/SQLite/Chromium checks. The registered-patient suite separately passed **42/42** and Node contracts passed **5/5**. These are staging-candidate results, not production safety certification.

Latest screenshots: `docs/qa/premium-audit-v3/`.

## Current staging security update

See `docs/SECURITY_STAGING_REVIEW.md` for the latest local checks and release blockers. Patient registration and login accept an email address or phone number plus a password; no email or SMS code is sent. Patient contact details are not ownership-verified in staging, so use fictional test details and do not enter real health information. The staging Turnstile test keys are public dummy credentials that always pass and are for staging only; never copy them to production. The test harness's bypass is local-only; never set `LOCAL_QA` in Cloudflare. R2 is optional for the first deploy; photo upload and retrieval remain disabled until the private staging bucket is added.

## Cloudflare staging configuration

`wrangler.jsonc` includes an isolated `staging` environment (`avenshore-care-staging`) with a separate D1 database and Durable Object binding. See `docs/CLOUDFLARE_STAGING_DEPLOYMENT.md` for deployment steps and how to add the optional private R2 bucket later. The staging D1 ID is configured. `npx wrangler deploy --env staging --dry-run` validates the build and bindings without publishing. A successful Cloudflare staging deployment and live tests are still pending.
