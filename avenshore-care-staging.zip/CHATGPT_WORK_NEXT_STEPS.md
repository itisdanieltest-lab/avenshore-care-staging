# ChatGPT Work handoff — Avenshore Care v2

You are continuing a source-based healthcare web app build, not starting a new site. The owner works primarily from an Android phone. Unpack this archive and preserve the approved Avenshore Care visual identity (teal-gold stylized A, tagline "Care That Stays Close."). The brand name is a working name pending legal clearance.

## Ground truth

1. Read `README.md` and `docs/WHOLE_PLATFORM_DESIGN_V2.md` first.
2. See the completed browser visuals in `docs/qa/full-surface-v2/` and real local backend screenshots under `docs/qa/real-integration/`. Screenshots include fictitious patient test accounts only.
3. `npm run check` passes five Node contracts; `python tests/full_surface_design_qa.py` passes 70 layout cases; `python tests/bridged_real_backend_e2e.py` passes 42 real local Worker+SQLite checks in this environment (browser fetch bridged to localhost).
4. The API is designed for Cloudflare Worker + D1 + optional R2 + Durable Object. The staging D1 ID is now configured. Without the optional staging R2 binding, photo uploads remain unavailable. Do not assume Cloudflare or actual WebRTC has been validated.

## Next engineering steps

- Run and review checks; review desktop and Android screenshots personally before changing styles.
- Finish the *staging-only* Cloudflare deployment in the owner's account, using fictional test accounts only. D1 is provisioned. R2 can be added later for photo tests. Configure environment secrets, authorized site URL, CORS, throttling and any bot protection.
- Verify native browser chat from two separate patient accounts to the single administrator and ensure no patient can access another patient's messages, photos or sessions.
- Test call signaling, queue concurrency, failed/abandoned calls, WebRTC audio, microphone permissions, reconnects, and TURN fallback between two genuinely separate browsers and networks.
- Run accessibility and security reviews before handling real patient information. Include keyboard testing, screen readers, zoom, WCAG 2.2 AA contrast audit, privacy/consent policies, retention/deletion workflows, account recovery, and staff verification.
- Save real staging browser screenshots of public, sign-up, login, patient home, health info, care, patient messaging, voice calls, account, admin overview, inbox, and active/queued calls at mobile and desktop widths.
- Report functional gaps explicitly, fix them, retest, and ask the owner for acceptance before any production rollout. Do not declare production-safe based only on styling and local tests.

Reference inspiration: https://www.teladochealth.com/individuals/adults and the owner's screenshots of Teladoc's signed-in portal. Copy neither proprietary design nor identity.

## Current V3 changes and preferred work order

Start with `docs/PREMIUM_PRODUCT_AUDIT_V3.md`. Run `npm run check`, `python tests/public_support_v3_qa.py` and `python tests/bridged_real_backend_e2e.py`. Latest homepage-refresh regression: `npm run check` passed 15/15. The bridged backend check passed 11 API/SQLite assertions before Chromium failed to launch because this executor blocks the required socket syscall; see `docs/qa/FINAL_REGRESSION_RESULTS.md`. Browser-driven screenshots and Cloudflare deployment are not certified by these local checks. Review `docs/qa/premium-audit-v3/visitor-chat-replied-390.png` and `admin-guest-support-1440.png`—the text exchange was sent by separate real Chromium browser sessions through locally persisted Worker API records.

**Never upload real patient records to a temporary staging or preview deployment.** Build and test the missing account-security, privacy, WebRTC, clinical policy and accessibility requirements before any public patient use. Keep the Care brand pending name/trademark/domain clearance. Only deploy with the owner's explicit authorization and account permission.
